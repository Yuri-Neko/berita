import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

import moment from 'moment-timezone'

/*============= WAKTU =============*/
let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
    
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })


global.htki = "⫹⫺"
global.htka = "⫹⫺"

global.pmenus = pickRandom(["乂", "◈", "➭", "ଓ", "⟆•", "⳻", "•", "↬", "◈", "⭑", "ᯬ", "◉", "᭻", "»", "〆", "々", "⛥", "✗", "⚜", "⚚", "♪"])
global.htjava = pickRandom(["乂", "⛶", "❏", "⫹⫺", "☰", "⎔", "✦", "⭔", "⬟", "⛊", "⚝"])
global.dmenut = htjava + "───『"
global.dmenub = "│" + pmenus
global.dmenub2 = "│" + pmenus
global.dmenuf = "╰──────────⳹"
global.dashmenu = "☰ *D A S B O A R D* ☰"
global.htki = htjava + "───『"
global.htka = "』───" + htjava


global.botdate = `⫹⫺ 𝗗𝗮𝘁𝗲: ${week} ${date}`
global.botdate = `${htjava} Date :  ${moment.tz("Asia/Makassar").format("DD/MM/YY")}`
global.bottime = `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`
global.nomorown = "6282112080081"
global.owner = [
  ['6282112080081', 'Kyouka', true],
  ['6282112080081'], 
  ['6282112080081'], 
  ['6285813087161']
] //Numeros de owner 
global.apikyo = "kyouka_admin"
global.mods = ['6282112080081'] 
global.prems = ['6282112080081']
global.APIs = { // API Prefix
  // name: 'https://website'
  xteam: 'https://api.xteam.xyz', 
  nrtm: 'https://fg-nrtm.ddns.net',
  bg: 'http://bochil.ddns.net',
  fgmods: 'https://api-fgmods.ddns.net',
  kyochin: 'https://web.api-kyouka.my.id/',
  kyoch: 'https://rest.api-kyouka.my.id/'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.xteam.xyz': 'd90a9e986e18778b',
  'https://zenzapis.xyz': '675e34de8a', 
  'https://api-fgmods.ddns.net': 'fMrnay7g',
  'https://web.api-kyouka.my.id/': 'kyouka_admin',
  'https://rest.api-kyouka.my.id/': 'KyoukaDesu'
}
global.fakes = Fakes()
global.flaaa = ImgLogoDynamic()

// Sticker WM
global.packname = 'Yuika┃ᴮᴼᵀ' 
global.sgc = 'https://chat.whatsapp.com/LFMNo3M6WtnHieYnhhhn9H'
global.author = '@KyoukaHashiba' 
global.fgig = '▢ Instagram\nhttps://www.instagram.com/admin_kyouka\n' 
global.dygp = 'https://chat.whatsapp.com/'
global.fgsc = 'https://github.com/' 
global.fgyt = 'https://youtube.com/'
global.fgpyp = 'https://paypal.me/'
global.fglog = 'https://i.imgur.com/Owmb93c.png' 
global.logo = ImgMountain()
global.wait = '*⌛ _Cargando..._*\n*▰▰▰▱▱▱▱▱*'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 
global.thumb = pickRandom(["https://minimalistic-wallpaper.demolab.com/?random", "https://picsum.photos/2560/1600", ImgEstetik()])
global.thumbdoc = pickRandom(["https://minimalistic-wallpaper.demolab.com/?random", "https://picsum.photos/2560/1600", ImgEstetik()])
global.sgh = 'https://github.com/Yuri-Neko'
global.fsizedoc = SizeDoc()
global.fpagedoc = PageDoc()
global.multiplier = 69 
global.maxwarn = '2' // máxima advertencias


global.dpptx = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
global.ddocx = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
global.dxlsx = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
global.dpdf = "application/pdf"
global.drtf = "text/rtf"


   global.rpgicon = {
        emoticon(string) {
            string = string.toLowerCase()
            let emot = {
                Fox: "🦊",
                agility: "🤸‍♂️",
                anggur: "🍇",
                apel: "🍎",
                aqua: "🥤",
                arc: "🏹",
                armor: "🥼",
                bank: "🏦",
                batu: "🧱",
                berlian: "💎",
                bibitanggur: "🍇",
                bibitapel: "🍎",
                bibitjeruk: "🍊",
                bibitmangga: "🥭",
                bibitpisang: "🍌",
                botol: "🍾",
                bow: "🏹",
                bull: "🐃",
                cat: "🐈",
                centaur: "🎠",
                chicken: "🐓",
                coal: "⚱️",
                common: "📦",
                cow: "🐄",
                crystal: "🔮",
                darkcrystal: "♠️",
                diamond: "💎",
                dog: "🐕",
                dragon: "🐉",
                eleksirb: "🧪",
                elephant: "🐘",
                emasbatang: "🪙",
                emasbiasa: "🥇",
                emerald: "💚",
                exp: "✉️",
                fishingrod: "🎣",
                foodpet: "🍱",
                fox: "🦊",
                gardenboc: "🗳️",
                gardenboxs: "📦",
                gems: "🍀",
                giraffe: "🦒",
                gold: "👑",
                griffin: "🦒",
                health: "❤️",
                healtmonster: "❤‍🔥",
                horse: "🐎",
                intelligence: "🧠",
                iron: "⛓️",
                jeruk: "🍊",
                kaleng: "🥫",
                kardus: "📦",
                kayu: "🪵",
                ketake: "💿",
                keygold: "🔑",
                keyiron: "🗝️",
                knife: "🔪",
                koinexpg: "👛",
                kucing: "🐈",
                kuda: "🐎",
                kyubi: "🦊",
                legendary: "🗃️",
                level: "🧬",
                limit: "🌌",
                lion: "🦁",
                magicwand: "⚕️",
                makanancentaur: "🥗",
                makanangriffin: "🥙",
                makanankyubi: "🍗",
                makanannaga: "🍖",
                makananpet: "🥩",
                makananphonix: "🧀",
                mana: "🪄",
                mangga: "🥭",
                money: "💵",
                mythic: "🗳️",
                mythic: "🪄",
                naga: "🐉",
                pancingan: "🎣",
                pet: "🎁",
                petFood: "🍖",
                phonix: "🦅",
                pickaxe: "⛏️",
                pisang: "🍌",
                pointxp: "📧",
                potion: "🥤",
                rock: "🪨",
                robo: "🤖",
                rubah: "🦊",
                sampah: "🗑️",
                serigala: "🐺",
                snake: "🐍",
                stamina: "⚡",
                strength: "🦹‍♀️",
                string: "🕸️",
                superior: "💼",
                sword: "⚔️",
                tiger: "🐅",
                tiketcoin: "🎟️",
                trash: "🗑",
                umpan: "🪱",
                uncommon: "🎁",
                upgrader: "🧰",
                wood: "🪵"
            }
            let results = Object.keys(emot).map(v => [v, new RegExp(v, "gi")]).filter(v => v[1].test(string))
            if (!results.length) return ""
            else return emot[results[0][0]]
        }
    }


function ThumbUrl() {
    let Turl = pickRandom([
'/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAcACADASIAAhEBAxEB/8QAGAABAQEBAQAAAAAAAAAAAAAABAUGAQP/xAAoEAACAQQCAQMDBQAAAAAAAAABAgMABBEhBRIxBkFRInGxE1JhwdH/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAZEQACAwEAAAAAAAAAAAAAAAAAAQIRITH/2gAMAwEAAhEDEQA/ANNFd9Uml65ZBkDIGdZxWcmbkORVpooCIzvWvzXlytxKbRew6r1zkeCc/wCCn+mL2C44oqBmeMYdTv7H7VqTrhuOkMXtzYylGPVZNOMDYqpeSme6tDFvvhCc6bBoXqSaKa5PUALEMN1+TXLxWt4lWMMYCRJGzbZcgaNFwSxljnYJoePgT9JXnRSA37c+Sfk/FA4xIuMsZJr1Y42VAqiPTOffPyabzlzK98kRb6c7xUq4UXk1qJfDq2QP4OP6qR1B5wJb2V1zLMsKiNCS2/FXOUiVOCIByUEa5A0SNHBp0kCWVkVt8oCuz77pfIW8UvFvCy/QIyBj2wNfiq3QUb0//9k=',
'/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAgACADASIAAhEBAxEB/8QAGAABAQEBAQAAAAAAAAAAAAAABAUDAQL/xAAmEAACAQMDAwQDAAAAAAAAAAABAgMAESEEEjEFEyIVQVFhcZHw/8QAFwEAAwEAAAAAAAAAAAAAAAAAAAEDAv/EABwRAAICAwEBAAAAAAAAAAAAAAECAAMREiExIv/aAAwDAQACEQMRAD8AlGEA5kU/NYSad4nQqwcMcW9q1k6TOG8ZBb7JFO0iDRIVSXa5A3EnP9mk2o8hWNjJUpMepQtcC3Nc1B3OBGcng/FI1SrtJGVB9/ipyxnvMl88/mmnRmFyatzwxPrUpGWcj7ApMbNIO67XZheof6qhoeojSL5xdy3AJxas2AkfIlKWVDkxuCDf3NT9Rui1IEZN+QDXqPqC+ZkG3N1AHP1QJXeZy7tuJpICDKXOrqMT/9k=',
'/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAgACADASIAAhEBAxEB/8QAGgABAAEFAAAAAAAAAAAAAAAABQMBAgQGB//EACoQAAICAgEDAQcFAAAAAAAAAAECAwQAERIFITETBhQiMkFx8DOBkaHR/8QAGAEAAgMAAAAAAAAAAAAAAAAAAwQAAQX/xAAcEQACAgMBAQAAAAAAAAAAAAABAgADERIhQRP/2gAMAwEAAhEDEQA/AD/Q5UqyjjGHChpCu9AjCZoeF5Y6jCU7HEjR+L6j+cWCSTdOhhA/UVR3OJ9K6BFVf3u07MiKWTQ1vX52yO2OewVQ4ZiCFhD6npKzD5kCg6+2TVZKrwFxGvPRABT64hYNazWrz0lKq7MC2yD2HjIb1FVhMqluI7kb/vEvu1baOYU0qRssIroRVhZQ3IKpHjHLUs12WGSFzBGi6Kkggn9s5+bD8eDSMdAAfF4xb2YtrHbljlccHjJHI9tg4xeWxssqtAOGbeCFiVSSdaViT4B/3LeoziKFVKgpJtW+2shS1XJLNPHsnfzL+DKW7FWxWZGmjGhsEMO2ZDDLA9Mb8n//2Q==',
'/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAgACADASIAAhEBAxEB/8QAGAAAAwEBAAAAAAAAAAAAAAAABAUGBwP/xAApEAACAgEDAwMDBQAAAAAAAAABAgMRBAAFIRJBUQYTMRQicUJhgaHx/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAGBEAAwEBAAAAAAAAAAAAAAAAAAERAkH/2gAMAwEAAhEDEQA/AJjFEXu9U5+xf0jvov6+NUZUhoMeaoceNDYUH1OVHDz9x7CyaF8DzxqmwvTuLOjCVclAaZS1Ke+qnBKJTnY8pT3oj8ENwDoXJjh6Fkgax8MPB043PYFgLmETlUFCk6gTXFkaQEEGiKN1WraJDvt8og3HHkLlAsi2wNEdr/vWhRxyQAjr6rPHA1J5nptMbbZ8lsos0QqglAtY/mtOfT24vPtimVSVVii2bNCqsn51hm8vgflCZA05kCpGpfgX8DWeAqVXi5C1k+B/uq/1PmONqZVJjV2Cmu/5/bUg0LwZPtyCmBH4I8jRE0f/2Q=='
])
    return Turl
}

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

global.hwaifu = [
    'https://i.pinimg.com/originals/ed/34/f8/ed34f88af161e6278993e1598c29a621.jpg',
    'https://i.pinimg.com/originals/85/4d/bb/854dbbd30304cd69f305352f0183fad0.jpg',
    'https://i.pinimg.com/originals/32/2c/a4/322ca456fa2cdec4b717895a65adfa8d.jpg',
    'https://i.pinimg.com/originals/f2/dd/cc/f2ddccd5a1b89d2302cf75c6520c58dd.png',
    'https://i.pinimg.com/originals/aa/6b/df/aa6bdf98cbc9e1fc741c36682fa3e838.jpg',
    'https://i.pinimg.com/originals/88/46/88/884688def830c43648f88154836a8b05.jpg',
    'https://i.pinimg.com/originals/57/d9/20/57d920d58533915850b431bd0b8e1f1d.jpg',
    'https://i.pinimg.com/originals/46/ad/05/46ad0505d33a2c2359f84ed9b867a58c.jpg',
    'https://i.pinimg.com/originals/23/b7/fb/23b7fb922770e139a2a57b1a443a2180.jpg',
    'https://i.pinimg.com/originals/46/79/25/467925d52634fd098ab6890a23c33f30.jpg',
    'https://i.pinimg.com/originals/a4/a1/74/a4a1740e565f4205eb3f700e1936e064.jpg',
    'https://i.pinimg.com/originals/f9/8d/2c/f98d2c3f64e50ba6c8efd9fdc7cf0093.png',
    'https://i.pinimg.com/originals/29/a4/b4/29a4b4573f993d7d6abb45843f529892.jpg',
    'https://i.pinimg.com/originals/40/de/84/40de84ce2ee376d8fae8ff5863d6edb0.jpg',
    'https://i.pinimg.com/originals/b6/f5/b7/b6f5b7d59fd4f332b3820db38612a5a0.jpg',
    'https://i.pinimg.com/originals/94/38/6d/94386d3c23f509dbc30341fed0363a07.jpg',
    'https://i.pinimg.com/originals/b5/94/ef/b594ef0774d29f5a05cd182994aa354e.jpg',
    'https://i.pinimg.com/originals/0f/ed/3f/0fed3f4c456158c506d88f5867ca93d2.jpg',
    'https://i.pinimg.com/originals/1b/7a/a8/1b7aa80191b83b888e9ea6042f090763.jpg',
    'https://i.pinimg.com/originals/72/7a/08/727a08cdf67b62c2ba49e7308c09a1cd.jpg',
    'https://i.pinimg.com/originals/86/93/75/8693757390b9d5b83fb8e40ff9ea876f.jpg',
    'https://i.pinimg.com/originals/5f/79/71/5f79713647b3e99a787ee7483715c1eb.jpg',
    'https://i.pinimg.com/originals/b8/b3/f3/b8b3f397fead38a988174df75d481202.png',
    'https://i.pinimg.com/originals/7a/e0/55/7ae055891f8200cd62ec76a40d47118d.jpg',
    'https://i.pinimg.com/originals/bc/9b/81/bc9b81c63b4844fd1a434d462bdfbd80.png',
    'https://i.pinimg.com/originals/22/8b/ca/228bca60a07d72cac953a9c3be542bab.jpg',
    'https://i.pinimg.com/originals/41/10/c6/4110c64fc91a1c85de02166f67aff7ad.jpg',
    'https://i.pinimg.com/originals/45/11/41/451141522a9086f56efc0da3fdac1957.jpg',
    'https://i.pinimg.com/originals/c1/4e/c7/c14ec7dffbc682f78c52ad8a295b8831.jpg',
    'https://i.pinimg.com/originals/25/5d/d9/255dd9dde5f44673092a4f15e917759f.jpg',
    'https://i.pinimg.com/originals/1f/95/15/1f95156c3d8e2b339a22b3bad2f69a8a.png',
    'https://i.pinimg.com/originals/bb/1a/12/bb1a1249dbc73736ab534fdd52bdc74c.jpg',
    'https://i.pinimg.com/originals/d5/58/a7/d558a745f2452d851d480025ab341537.jpg',
    'https://i.pinimg.com/originals/e7/00/0e/e7000e7e72c1b37ea7a4c780182d05d8.jpg',
    'https://i.pinimg.com/originals/9e/53/a9/9e53a92ee711d979b9bdbb6212115fe0.jpg',
    'https://i.pinimg.com/originals/c6/16/d9/c616d9a871ed3cd9fb6a46efb7f92d95.jpg',
    'https://i.pinimg.com/originals/ac/f0/29/acf029047efffe57999fa876554cbf1d.jpg',
    'https://i.pinimg.com/originals/ae/86/3b/ae863b64ca579f05008dbf027b04988f.jpg',
    'https://i.pinimg.com/originals/d5/65/43/d56543a959da518e08012b4db93747bb.jpg',
    'https://i.pinimg.com/originals/ed/3c/e2/ed3ce276ca71e5bfec1cf2fbfc5561e1.jpg',
    'https://i.pinimg.com/originals/66/30/37/663037f00539f3bc1dbd3efeae0d700b.jpg',
    'https://i.pinimg.com/originals/63/6b/7b/636b7bd0e1df03f0bf72c494cedd6f07.png',
    'https://i.pinimg.com/originals/db/a4/13/dba413518c0a470a5e81cafa431281da.jpg',
    'https://i.pinimg.com/originals/3b/d9/aa/3bd9aa880d23dc3262e119ca09345e99.jpg',
    'https://i.pinimg.com/originals/ef/90/4e/ef904eda01a996e5a9d557a55db6da0f.png',
    'https://i.pinimg.com/originals/fb/f7/a9/fbf7a92af75577e33a564ce490154c8f.jpg',
    'https://i.pinimg.com/originals/16/92/89/1692897136ac3688ab9ccdbb0e54fb21.jpg',
    'https://i.pinimg.com/originals/fc/51/4e/fc514e2f4c23eb96721611b483edc28c.jpg',
    'https://i.pinimg.com/originals/bb/a4/98/bba49848bc4369333f4128b62fc64258.jpg',
    'https://i.pinimg.com/originals/67/a7/54/67a754077a1ffc75c25b3c7bb04d2258.png',
    'https://i.pinimg.com/originals/57/d9/20/57d920d58533915850b431bd0b8e1f1d.jpg',
    'https://i.pinimg.com/originals/83/e5/71/83e5710c42b9e8b9e1a4b6381c4535fe.jpg',
    'https://i.pinimg.com/originals/88/46/88/884688def830c43648f88154836a8b05.jpg',
    'https://i.pinimg.com/originals/32/2c/a4/322ca456fa2cdec4b717895a65adfa8d.jpg',
    'https://i.pinimg.com/originals/42/88/f1/4288f17ee25b909430fb7e707d961d0b.jpg',
    'https://i.pinimg.com/originals/16/14/9c/16149c94a7c0f753230b1edbd03ab3e6.jpg',
    'https://i.pinimg.com/originals/7f/f5/46/7ff546b38e2969e578e697c44944b74f.jpg',
    'https://i.pinimg.com/originals/6d/bc/61/6dbc616311268a25b0ee0e1bd4de13b6.jpg',
    'https://i.pinimg.com/originals/60/34/18/603418ea5c35839914a1071e134add8b.jpg',
    'https://i.pinimg.com/originals/5f/79/71/5f79713647b3e99a787ee7483715c1eb.jpg',
    'https://i.pinimg.com/originals/ed/ea/37/edea37b6f876bfc8f59bbae4d43e26d7.jpg',
    'https://i.pinimg.com/originals/94/38/6d/94386d3c23f509dbc30341fed0363a07.jpg',
    'https://i.pinimg.com/originals/f6/20/b4/f620b4b1c2aaf096455952465db8a980.jpg',
    'https://i.pinimg.com/originals/97/50/73/9750731b4b004da61d44fe01dbe93d85.jpg',
    'https://i.pinimg.com/originals/a0/55/41/a055419e96bc61a5990c575af10ba99e.png',
    'https://i.pinimg.com/originals/aa/6b/df/aa6bdf98cbc9e1fc741c36682fa3e838.jpg',
    'https://i.pinimg.com/originals/c2/4f/75/c24f7518e17faba4bf8908a39be604a6.jpg',
    'https://i.pinimg.com/originals/95/bb/2e/95bb2e7c8b71754003d063f39feb232a.jpg',
    'https://i.pinimg.com/originals/c4/e4/1d/c4e41d096e7585a7e6245e852ece25c2.jpg',
    'https://i.pinimg.com/originals/87/cf/bc/87cfbc189e773ed9294bccfd50a4fbc7.jpg',
    'https://i.pinimg.com/originals/7a/3b/e6/7a3be6cf1595fe6764b5b18b46ca576d.jpg',
    'https://i.pinimg.com/originals/c5/42/f8/c542f83b992e51c6d2519f07489b1dec.jpg',
    'https://i.pinimg.com/originals/96/29/1e/96291e9abbf311b8fc6c8c3f9f8ae059.jpg',
    'https://i.pinimg.com/originals/e5/1a/8d/e51a8d35d2b717fa757fa2abf053a2c7.jpg',
    'https://i.pinimg.com/originals/47/18/af/4718afcd517c8e7e07cc9dba48b3b770.jpg',
    'https://i.pinimg.com/originals/39/2c/cb/392ccb1793c5a23783869994b1ec24b7.jpg',
    'https://i.pinimg.com/originals/0f/98/5f/0f985ffbfff2650d6e3ecf8ba0eb574e.jpg',
    'https://i.pinimg.com/originals/ab/f9/50/abf950c9aa1c4710437d9acc83078f87.jpg',
    'https://i.pinimg.com/originals/f2/dd/cc/f2ddccd5a1b89d2302cf75c6520c58dd.png',
    'https://i.pinimg.com/originals/f1/f7/fc/f1f7fca39eba7d64e50749da5406247c.jpg',
    'https://i.pinimg.com/originals/71/18/96/711896c067c28814ec9ec9c25d4a3ba9.jpg',
    'https://i.pinimg.com/originals/67/a7/54/67a754077a1ffc75c25b3c7bb04d2258.png',
    'https://i.pinimg.com/originals/8f/fe/d4/8ffed485ed8b6db07067e452f8399fff.jpg',
    'https://i.pinimg.com/originals/db/b6/46/dbb6463c9134591aa79369f325877e03.jpg',
    'https://i.pinimg.com/originals/9f/23/1a/9f231a6acc906f95ff3f917211b9abda.png',
    'https://i.pinimg.com/originals/b9/a9/66/b9a9669f0fbbe75e780adad301601b43.jpg',
    'https://i.pinimg.com/originals/86/ed/26/86ed265f2dbb22a48bbc612f59303508.png',
    'https://i.pinimg.com/originals/da/ae/25/daae25409adec418a9b6f6c5dcdecd47.jpg',
    'https://i.pinimg.com/originals/a4/6d/fa/a46dfad749d0577366e9ea2db6cc305e.jpg',
    'https://i.pinimg.com/originals/09/5b/4d/095b4d0ce48f40eca7ad23e43e85ab9a.jpg',
    'https://i.pinimg.com/originals/d9/e1/30/d9e1307a5fbbeb2a267562eab8abc063.jpg',
    'https://i.pinimg.com/originals/db/cf/dc/dbcfdc263095906eabf7e06099ebaef0.png',
    'https://i.pinimg.com/originals/89/14/0d/89140d3ef976904013f672fea0157b7e.png',
    'https://i.pinimg.com/originals/cf/4f/cf/cf4fcf2036f0b5b974f146f2c0ba81db.jpg',
    'https://i.pinimg.com/originals/93/62/9e/93629ee9ab27043076bce2b1f22f9193.jpg',
    'https://i.pinimg.com/originals/99/6b/c4/996bc4049d632bdbf7d9bc24dc8081f0.png',
    'https://i.pinimg.com/originals/f2/6d/35/f26d354b1421546ae993c83f5c7bcfb0.jpg',
    'https://i.pinimg.com/originals/25/5d/d9/255dd9dde5f44673092a4f15e917759f.jpg',
    'https://i.pinimg.com/originals/08/8f/1d/088f1dc58092b60652e05cc941ee0fbd.jpg',
    'https://i.pinimg.com/originals/14/17/dd/1417dd63009eea0b63252076f3b405e6.jpg',
    'https://i.pinimg.com/originals/35/04/d5/3504d53c5850b3bddaa6e0e0714ccacb.jpg',
    'https://i.pinimg.com/originals/88/46/88/884688def830c43648f88154836a8b05.jpg',
    'https://i.pinimg.com/originals/57/d9/20/57d920d58533915850b431bd0b8e1f1d.jpg',
    'https://i.pinimg.com/originals/44/39/17/443917c07ffd65caa7d7cd4065fb8571.jpg',
    'https://i.pinimg.com/originals/bc/9b/81/bc9b81c63b4844fd1a434d462bdfbd80.png',
    'https://i.pinimg.com/originals/4a/e2/74/4ae274c828a2c719bcf9f644106d26cf.jpg',
    'https://i.pinimg.com/originals/d0/cb/da/d0cbdaa334fa92f8b09d1c4d1ddc9cd2.jpg',
    'https://i.pinimg.com/originals/71/16/31/711631ac52f7809f530e40f230b371a4.jpg',
    'https://i.pinimg.com/originals/af/f1/1b/aff11bcfdf946a7bba1687c80515f902.jpg',
    'https://i.pinimg.com/originals/46/79/25/467925d52634fd098ab6890a23c33f30.jpg',
    'https://i.pinimg.com/originals/ef/90/4e/ef904eda01a996e5a9d557a55db6da0f.png',
    'https://i.pinimg.com/originals/a2/e7/73/a2e773fdb7ce0fc99eb123d8a81764ec.jpg',
    'https://i.pinimg.com/originals/79/92/ed/7992ed0c9b272654938ea186cc2e3f4a.jpg',
    'https://i.pinimg.com/originals/7a/08/c8/7a08c8c22066a142f22928662d9d70aa.jpg',
    'https://i.pinimg.com/originals/20/b0/96/20b0962b8c62584fbcd6e7675b4782a4.jpg',
    'https://i.pinimg.com/originals/51/0f/8c/510f8cb8f28b8666d560f89e2006d4b1.jpg',
    'https://i.pinimg.com/originals/c2/4f/75/c24f7518e17faba4bf8908a39be604a6.jpg',
    'https://i.pinimg.com/originals/4e/43/7b/4e437b1bbdee605d833155a97d35bef1.png',
    'https://i.pinimg.com/originals/d5/a2/c9/d5a2c9cdfac835518e45b13cfc39819d.jpg',
    'https://i.pinimg.com/originals/95/bb/2e/95bb2e7c8b71754003d063f39feb232a.jpg',
    'https://i.pinimg.com/originals/16/92/89/1692897136ac3688ab9ccdbb0e54fb21.jpg',
    'https://i.pinimg.com/originals/6f/9a/86/6f9a86eb31e7c5bc34cf0d1d130574e0.png',
    'https://i.pinimg.com/originals/f0/67/f0/f067f00a885fab47d76d4e5423d54c35.jpg',
    'https://i.pinimg.com/originals/4e/9a/7a/4e9a7a196cea58427163313b7db6363e.jpg',
    'https://i.pinimg.com/originals/53/4c/6a/534c6a2e65fdb4c52824f94acc5e2195.jpg',
    'https://i.pinimg.com/originals/8d/04/9a/8d049a1e6951491b24ea4c364f2459bc.jpg',
    'https://i.pinimg.com/originals/22/dc/94/22dc941e60b0ace15d796a94f07d8ba7.jpg',
    'https://i.pinimg.com/originals/80/bc/96/80bc968b4dcd939b60ffe2c8b0c54d75.png',
    'https://i.pinimg.com/originals/ed/34/f8/ed34f88af161e6278993e1598c29a621.jpg',
    'https://i.pinimg.com/originals/9b/36/24/9b36241f4a3b782c05eadb0805ef0dda.png',
    'https://i.pinimg.com/originals/22/8b/ca/228bca60a07d72cac953a9c3be542bab.jpg',
    'https://i.pinimg.com/originals/57/0e/9b/570e9b1288f1189a22b39c8e24ec957f.jpg',
    'https://i.pinimg.com/originals/68/af/17/68af1781a9120a59629d0f774555185f.jpg',
    'https://i.pinimg.com/originals/42/88/f1/4288f17ee25b909430fb7e707d961d0b.jpg',
    'https://i.pinimg.com/originals/c8/0e/ee/c80eeea7a37d732d5a1b0e60464f9e18.jpg',
    'https://i.pinimg.com/originals/1d/08/cb/1d08cbb9d42812984bed54e8291edaec.jpg',
    'https://i.pinimg.com/originals/4e/37/02/4e37020a3e69f16cd04b246c2937b979.jpg',
    'https://i.pinimg.com/originals/59/8e/bf/598ebf206f5ec366e2e32e8c6e8cffb4.jpg',
    'https://i.pinimg.com/originals/cb/ef/94/cbef94975cfed070027c2175a730155d.jpg',
    'https://i.pinimg.com/originals/e0/74/f8/e074f8dc647066a9f112533c789c0e42.png',
    'https://i.pinimg.com/originals/60/ac/9e/60ac9edf63fcb43e3f00555cb71ae6f2.jpg',
    'https://i.pinimg.com/originals/17/16/76/1716760d93dcbf7664380fd81f3133f5.jpg',
    'https://i.pinimg.com/originals/a3/70/e1/a370e1f592136a385ac6cb15918d25f1.jpg',
    'https://i.pinimg.com/originals/89/ee/ab/89eeabd90e54b2951459f81f51e2c791.jpg',
    'https://i.pinimg.com/originals/77/0d/23/770d235d3f6dcd021bda5efdf53cca36.png',
    'https://i.pinimg.com/originals/67/a7/54/67a754077a1ffc75c25b3c7bb04d2258.png',
    'https://i.pinimg.com/originals/c3/1e/58/c31e58fae7f58af4d643c5a2facd49d7.jpg',
    'https://i.pinimg.com/originals/0f/98/5f/0f985ffbfff2650d6e3ecf8ba0eb574e.jpg',
    'https://i.pinimg.com/originals/93/0a/5f/930a5fc6f8f6e64e87ac2cc30b8430ac.jpg',
    'https://i.pinimg.com/originals/1e/14/22/1e14229be49534cbf3d43b71b1738b80.jpg',
    'https://i.pinimg.com/originals/35/04/d5/3504d53c5850b3bddaa6e0e0714ccacb.jpg',
    'https://i.pinimg.com/originals/57/d9/20/57d920d58533915850b431bd0b8e1f1d.jpg',
    'https://i.pinimg.com/originals/c2/4f/75/c24f7518e17faba4bf8908a39be604a6.jpg',
    'https://i.pinimg.com/originals/7f/f5/46/7ff546b38e2969e578e697c44944b74f.jpg',
    'https://i.pinimg.com/originals/bc/9b/81/bc9b81c63b4844fd1a434d462bdfbd80.png',
    'https://i.pinimg.com/originals/d5/a2/c9/d5a2c9cdfac835518e45b13cfc39819d.jpg',
    'https://i.pinimg.com/originals/d7/02/54/d7025401aec66a4baf0fbcbc1054b499.jpg',
    'https://i.pinimg.com/originals/95/bb/2e/95bb2e7c8b71754003d063f39feb232a.jpg',
    'https://i.pinimg.com/originals/ee/ee/fd/eeeefda1774a2d5dced265c1a2d398d5.jpg',
    'https://i.pinimg.com/originals/c3/1e/58/c31e58fae7f58af4d643c5a2facd49d7.jpg',
    'https://i.pinimg.com/originals/1f/9c/1d/1f9c1d5f4d2de0b74e81f190ab4f1792.jpg',
    'https://i.pinimg.com/originals/7a/3b/e6/7a3be6cf1595fe6764b5b18b46ca576d.jpg',
    'https://i.pinimg.com/originals/51/08/53/5108536a4826d3354ac3fe9c3c867cb1.png',
    'https://i.pinimg.com/originals/77/cc/bc/77ccbcd52758458669ed5eadf4437111.jpg',
    'https://i.pinimg.com/originals/51/0f/8c/510f8cb8f28b8666d560f89e2006d4b1.jpg',
    'https://i.pinimg.com/originals/6f/9a/86/6f9a86eb31e7c5bc34cf0d1d130574e0.png',
    'https://i.pinimg.com/originals/79/92/ed/7992ed0c9b272654938ea186cc2e3f4a.jpg',
    'https://i.pinimg.com/originals/39/2c/cb/392ccb1793c5a23783869994b1ec24b7.jpg',
    'https://i.pinimg.com/originals/3b/2c/02/3b2c020665f835b0dfdd74b8cc9ca22d.jpg',
    'https://i.pinimg.com/originals/ee/cf/7c/eecf7cc7f65e5d503399cc88f0e6ef6c.jpg',
    'https://i.pinimg.com/originals/4e/9a/7a/4e9a7a196cea58427163313b7db6363e.jpg',
    'https://i.pinimg.com/originals/8b/f8/46/8bf8468935d529c6383771097381196a.jpg',
    'https://i.pinimg.com/originals/f3/5d/ce/f35dce5f6742bd4f30033fe7b51335cc.jpg',
    'https://i.pinimg.com/originals/94/a6/69/94a6692d5bd9ba0bbd80ba1e4122b2f9.jpg',
    'https://i.pinimg.com/originals/8f/55/04/8f55043dfd9d244f172077bdc0304c6a.png',
    'https://i.pinimg.com/originals/89/ee/ab/89eeabd90e54b2951459f81f51e2c791.jpg',
    'https://i.pinimg.com/originals/83/5a/2e/835a2e582d1f803f03ab3a3c3e58b694.jpg',
    'https://i.pinimg.com/originals/25/5d/d9/255dd9dde5f44673092a4f15e917759f.jpg',
    'https://i.pinimg.com/originals/e2/f1/0e/e2f10ead12c9a2d7c0bb29442604f43d.jpg',
    'https://i.pinimg.com/originals/f5/2a/09/f52a09910f1cad9b5b01d79a620870dc.jpg',
    'https://i.pinimg.com/originals/d9/e1/30/d9e1307a5fbbeb2a267562eab8abc063.jpg',
    'https://i.pinimg.com/originals/6a/4d/11/6a4d11cb5bab1466cf1ccb8c6c4f9eb6.jpg',
    'https://i.pinimg.com/originals/f3/b7/37/f3b7376c2a574b8619c197bce72d1f63.png',
    'https://i.pinimg.com/originals/93/0a/5f/930a5fc6f8f6e64e87ac2cc30b8430ac.jpg',
    'https://i.pinimg.com/originals/30/78/75/307875a9132c6e704eec94bc31fd4f71.jpg',
    'https://i.pinimg.com/originals/12/fa/7d/12fa7df7ba74ac00d846d8d490f7c8a4.jpg',
    'https://i.pinimg.com/originals/68/f6/f3/68f6f37335624f89cda17ab928f51138.jpg',
    'https://i.pinimg.com/originals/de/f6/e7/def6e7ce26ad6a1096e8b1ef395a1904.jpg',
    'https://i.pinimg.com/originals/cc/17/be/cc17be94cd520baa4722e0ca2329c2e9.jpg',
    'https://i.pinimg.com/originals/b3/c5/d1/b3c5d1076a9a48c075c8a92987b03bf3.jpg',
    'https://i.pinimg.com/originals/2c/e6/02/2ce6025d9d1736cf3e67db1fd2bdaf35.jpg',
    'https://i.pinimg.com/originals/31/07/53/310753699042b254fdfa0472a2675158.jpg',
    'https://i.pinimg.com/originals/6b/87/9c/6b879cc29b5df23941dab4f4aafabcbd.jpg',
    'https://i.pinimg.com/originals/52/90/0b/52900bab0f969d9d68207f6ad8510882.jpg',
    'https://i.pinimg.com/originals/25/7e/db/257edb1b91a127bcf91cc2ea6b29edaf.jpg',
    'https://i.pinimg.com/originals/63/6b/7b/636b7bd0e1df03f0bf72c494cedd6f07.png',
    'https://i.pinimg.com/originals/8d/ad/58/8dad58f3b258b3d7f2e913cb4561d99f.jpg',
    'https://i.pinimg.com/originals/8d/04/9a/8d049a1e6951491b24ea4c364f2459bc.jpg',
    'https://i.pinimg.com/originals/fd/21/41/fd21419275236bb153de3c8dcbbf3bf9.jpg',
    'https://i.pinimg.com/originals/80/4f/1a/804f1a05f9996c96a2d492b4854b7fd5.jpg'
]



global.thumbnailUrl = [
  'https://telegra.ph/file/81260a8b9e8cff26d2b48.jpg', 'https://telegra.ph/file/ac4928f0824a2a0492737.jpg',
  'https://telegra.ph/file/6359b013bc7e52c3b346f.jpg', 'https://telegra.ph/file/d43c89a5d2da72875ec05.jpg',
  'https://telegra.ph/file/7d6c0e35f9c8f52715541.jpg', 'https://telegra.ph/file/ef4b742d47e6a9115e2ff.jpg',
  'https://telegra.ph/file/55e5af5f33fbd57104187.jpg', 'https://telegra.ph/file/af236598456b95884bd15.jpg',
  'https://telegra.ph/file/de92ed4a729887ffc974c.jpg', 'https://telegra.ph/file/00ce42a193b1dbbf907d4.jpg'
 ]


function SizeDoc() {
    return Math.pow(10, 15)
}
function PageDoc() {
    return Math.pow(10, 10)
}

/* Img Array */
function ImgEstetik() {
    let DocImg = pickRandom([
        "https://i.pinimg.com/originals/b4/2c/9c/b42c9c0244e1d940f40006f528274fcb.png",
        "https://i.pinimg.com/originals/61/f1/bf/61f1bf6bb91dd1dc445cdf6815b916fc.png",
        "https://i.pinimg.com/originals/ab/f8/8c/abf88c2f5f5e5d16875cefb354eac264.jpg",
        "https://i.pinimg.com/originals/74/64/61/746461deb35bfc0e902302a0f48de4d4.jpg",
        "https://i.pinimg.com/originals/b8/ca/b5/b8cab5d9b26ab27e227c1e9332a88ef4.jpg",
        "https://i.pinimg.com/originals/63/57/66/635766e0012b1043b417569045677466.png",
        "https://i.pinimg.com/originals/59/42/cf/5942cfd3ee4c1e2e69d1a5c6a21932de.jpg",
        "https://i.pinimg.com/originals/1a/d0/0c/1ad00c60485c3775da0653b5bdf25789.jpg",
        "https://i.pinimg.com/originals/65/31/f2/6531f220db24f3f5cf5f2e2e1207b862.jpg",
        "https://i.pinimg.com/originals/36/db/eb/36dbeb4e00922f31283562034c3077c2.jpg",
        "https://i.pinimg.com/originals/cf/ec/e5/cfece519673571566c22298a0320f99f.jpg",
        "https://i.pinimg.com/originals/12/ee/98/12ee982b710e5a73b26fc4952927c20c.jpg",
        "https://i.pinimg.com/originals/bd/6c/3b/bd6c3b4e7166172bc1f27c59bd9c7e76.jpg",
        "https://i.pinimg.com/originals/6c/d1/51/6cd151fb83df27d4e06f81d8633d3d94.jpg",
        "https://i.pinimg.com/originals/16/1c/22/161c221d96dcc1123f5fe191e0142727.jpg",
        "https://i.pinimg.com/originals/97/30/8c/97308ce90040f1605538bb01bd4fa7cf.jpg",
        "https://i.pinimg.com/originals/98/75/97/98759738d93608af57956545f5840daa.jpg",
        "https://i.pinimg.com/originals/41/f5/22/41f522c5a932ff7645d5941de3eaadda.jpg",
        "https://i.pinimg.com/originals/6c/1c/36/6c1c369cd3e3f3e5cc766a3d003e5ecb.jpg",
        "https://i.pinimg.com/originals/ce/00/24/ce002453879ef6c5eda3db249946d372.jpg",
        "https://i.pinimg.com/originals/aa/fd/23/aafd2371e249bbbcc6d84a981c45e6bb.jpg",
        "https://i.pinimg.com/originals/11/5a/69/115a6980e8008379f65f4e34f92bda72.png",
        "https://i.pinimg.com/originals/8b/70/11/8b701118b341c8f3f160089dd9b8a310.jpg",
        "https://i.pinimg.com/originals/29/7a/da/297ada3515d92c5155ca04aa494782cb.jpg",
        "https://i.pinimg.com/originals/d6/d3/df/d6d3dfecf10a7d9746666c38be44d925.jpg",
        "https://i.pinimg.com/originals/78/e2/bd/78e2bdcb305f788ec67e7cb324d531fe.jpg",
        "https://i.pinimg.com/originals/77/2f/20/772f209b453a0a5a6ae1b7d3cf70a908.jpg",
        "https://i.pinimg.com/originals/ff/36/a7/ff36a77caf23babe715cfe97bbc181da.jpg",
        "https://i.pinimg.com/originals/f5/5e/c1/f55ec1a2f4f7070efde70df5a37def1e.jpg",
        "https://i.pinimg.com/originals/c5/eb/81/c5eb8140be713edb9d6afd5094a53bca.jpg",
        "https://i.pinimg.com/originals/bf/9c/7f/bf9c7f37bc6e385406ed8fc59b9d600b.jpg",
        "https://i.pinimg.com/originals/a7/b1/c2/a7b1c21bbcaf286fe028c4f602ff67b2.jpg",
        "https://i.pinimg.com/originals/37/f5/01/37f501efe423c2b006bd96efd0ddce45.jpg",
        "https://i.pinimg.com/originals/88/26/55/88265549afbaeaaf11f27a03136b45d4.jpg",
        "https://i.pinimg.com/originals/ae/9e/8b/ae9e8baabd4a5e8ce236760824bfc996.png",
        "https://i.pinimg.com/originals/95/26/83/9526835e2f8a122a7c9b02301d0e1c3d.jpg",
        "https://i.pinimg.com/originals/2d/7b/5b/2d7b5b2f57ea965fd5e89581bb53f07e.jpg",
        "https://i.pinimg.com/originals/d4/2f/db/d42fdbf73868af1f844b88a30617f9d7.jpg",
        "https://i.pinimg.com/originals/1a/c9/a0/1ac9a0bec6c2c1e586d50b5374c1e4ca.jpg",
        "https://i.pinimg.com/originals/9a/70/65/9a7065bd0d0df7a84773ce2dfa150dcf.jpg",
        "https://i.pinimg.com/originals/bc/39/7a/bc397aad9b28519643729f36c6d334fa.jpg",
        "https://i.pinimg.com/originals/ac/c5/2c/acc52ca4eb1d0ab7e0ba2970344ee50e.jpg",
        "https://i.pinimg.com/originals/95/3b/9c/953b9cebee45c063573beef9586e742e.jpg",
        "https://i.pinimg.com/originals/8f/9b/0c/8f9b0cc4aa5175b3ce7f5f6f8ebf7f23.jpg",
        "https://i.pinimg.com/originals/03/dc/e5/03dce5c7e6aaa7143871f225698d89c6.png",
        "https://i.pinimg.com/originals/b2/13/ea/b213ea1876a17df3eadfcc1f1f80971c.jpg",
        "https://i.pinimg.com/originals/52/d3/ca/52d3cac214995290d41547ebd4b753eb.jpg",
        "https://i.pinimg.com/originals/0b/ab/f6/0babf697809c528116557d060d7c95f5.jpg",
        "https://i.pinimg.com/originals/7f/b2/d2/7fb2d2f65bfbb19881b0b0d4c2f33ca1.jpg",
        "https://i.pinimg.com/originals/df/11/46/df114607f50aa300edd5cd7d404000f5.jpg",
        "https://i.pinimg.com/originals/88/e8/1c/88e81c0463870b4750ba7ec74fecae0e.jpg",
        "https://i.pinimg.com/originals/89/09/86/890986ea900da0b40826607ec261f676.png",
        "https://i.pinimg.com/originals/1d/6a/4b/1d6a4bbf4dad8db5aa5d44851be9ef78.jpg",
        "https://i.pinimg.com/originals/01/72/67/017267a53c9e9693d20520608690e8e7.jpg",
        "https://i.pinimg.com/originals/58/aa/79/58aa799cd9edefe88d7e97dc76f63799.jpg",
        "https://i.pinimg.com/originals/be/07/1c/be071c20203ee0c03f4cf2cd5356c063.jpg",
        "https://i.pinimg.com/originals/46/4b/16/464b16e19604dc08be77a8f03ebdb742.jpg",
        "https://i.pinimg.com/originals/32/a0/97/32a0978d7d1d73e237a39f90ea5af978.jpg",
        "https://i.pinimg.com/originals/a6/1a/bc/a61abc36e144e2d3557255a645f5c400.jpg",
        "https://i.pinimg.com/originals/33/02/a4/3302a4186c602c8f5b4a2f69ffe7de32.jpg",
        "https://i.pinimg.com/originals/77/a8/f5/77a8f566c318e738067ee65434b69feb.jpg",
        "https://i.pinimg.com/originals/18/89/01/188901b38e9b0905bbbd8adb889a03a9.jpg",
        "https://i.ytimg.com/vi/JQzFR1UicoE/maxresdefault.jpg",
        "https://i.pinimg.com/originals/13/62/09/136209df5e48abadc9b376a1fa9a1aef.jpg",
        "https://i.pinimg.com/originals/4e/7e/91/4e7e912a0772b29e0070a23e413813cb.jpg",
        "https://i.pinimg.com/originals/fc/e0/f6/fce0f6027d2fcbbd232fddcd71873f03.jpg",
        "https://i.pinimg.com/originals/9f/cc/9e/9fcc9eedadd9b840692e1b2cc3bd2625.jpg",
        "https://i.pinimg.com/originals/be/5b/d1/be5bd16d6cfda3aa06925d8eb8860392.jpg",
        "https://i.pinimg.com/originals/eb/79/54/eb79544a0e10df58d40133c429bc518c.jpg",
        "https://i.pinimg.com/originals/23/58/cb/2358cbf776160115076d14abefe1eec5.jpg",
        "https://i.pinimg.com/originals/26/46/c6/2646c6ddb3cfcee91e0e4bc29dcf6c7c.jpg",
        "https://i.pinimg.com/originals/46/f4/d6/46f4d67909a573b109fc3e0a60de3e06.jpg",
        "https://i.pinimg.com/originals/e7/52/b5/e752b54516024ed00255332b3766599e.jpg",
        "https://i.pinimg.com/originals/20/c8/63/20c863c5656cf1f925b478525f597956.jpg",
        "https://i.pinimg.com/originals/e6/f9/41/e6f941881ca71fd20335d7c8b6a98cfc.jpg",
        "https://i.pinimg.com/originals/28/16/73/281673cb50ae9a8d19b00d6244ea965a.jpg",
        "https://i.ytimg.com/vi/5JwKzi-SYHc/maxresdefault.jpg",
        "https://i.pinimg.com/originals/b7/57/91/b75791bf212506b883770b3f9768aabe--night-quotes-book-quotes.jpg",
        "https://i.pinimg.com/originals/0e/e8/b5/0ee8b58e1be009e6139bd76d6db169c1.jpg",
        "https://i.pinimg.com/originals/81/fd/10/81fd109472314c6a8c2e3dba4535857d.jpg",
        "https://i.pinimg.com/originals/a7/fd/5f/a7fd5fe72a0094172cb1bf6386fbd8eb.jpg",
        "https://i.pinimg.com/videos/thumbnails/originals/2a/a2/95/2aa295b0fa86e91e7fd73a36fc825fe9.0000001.jpg",
        "https://i.pinimg.com/originals/0c/5f/af/0c5faf951d787aedfc877a5f0a34cf21.jpg",
        "https://i.pinimg.com/originals/d2/43/12/d243124a31b9a7640744c62e4d0348ad.jpg",
        "https://i.pinimg.com/originals/8b/ee/4b/8bee4b745cbc80ab18441bba51256b16.jpg",
        "https://i.pinimg.com/originals/cd/6c/30/cd6c309030864871fda4ac57f285bc8d.jpg",
        "https://i.pinimg.com/originals/fc/65/d1/fc65d165e9ab2a277675f5cf2482a22c.jpg",
        "https://i.pinimg.com/originals/11/b5/46/11b54649fd9552e9e38bb01927a1c792.jpg",
        "https://i.pinimg.com/originals/15/cb/c6/15cbc6e5bb539063b4fe2973a821deff.jpg",
        "https://i.pinimg.com/originals/58/3f/99/583f99990d7efde7ecebfb91b05966e2.jpg",
        "https://i.pinimg.com/originals/cd/29/14/cd29147b7dce91ca1089cddf0c066e8e--instagram-white-feed-white-aesthetic-instagram.jpg",
        "https://i.pinimg.com/originals/81/11/96/8111963fc49348f368b75cce97d63aac.jpg",
        "https://i.pinimg.com/originals/93/25/ee/9325eebbc15afb24def63dacab4f606e.jpg",
        "https://i.pinimg.com/originals/db/25/f1/db25f119383fa0bcb12cb07519f8c6ae.jpg",
        "https://i.pinimg.com/originals/35/ff/92/35ff9221f136285da7ca62ec2ea1c695.jpg",
        "https://i.pinimg.com/originals/d9/79/a4/d979a46728585c9bc8db8d38717908f8.jpg",
        "https://i.pinimg.com/originals/b6/1b/7d/b61b7d4ea4c3170c969a28d501081ec1.jpg",
        "https://i.pinimg.com/originals/51/7e/a1/517ea1599477e67d67a6793f8c4decf1.jpg",
        "https://i.pinimg.com/originals/df/65/2a/df652af3f2ba4ecde1124189586eb8ac.jpg",
        "https://i.pinimg.com/originals/37/7c/8b/377c8b4d1428ad52fc32bb1b4b759c56.jpg"
    ])
    return DocImg
}
function ImgLogoDynamic() {
    let Dynamic = [
"https://dynamic.brandcrowd.com/asset/logo/04ca85c5-a4c1-4582-8296-7fb8cbdf7df1/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/063a3d53-d7bb-4abb-8b20-3e45ae7c61ac/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/065b4535-d123-4261-accb-2f21e3eac3cf/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/09699c93-f687-4c58-b6dc-cb8010de7df9/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/097b9969-5019-433a-9a3f-d2e097b50e99/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/0c963355-e735-4cdd-bec8-1373ba2a222e/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/0cd45dda-e1e6-46bc-9f0d-b49a5d3c3667/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/10cd8160-2b8d-41c5-87cc-f683a853d5d9/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/163db786-9e2a-494a-a996-de565ae52f83/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/1e47fc81-0c56-45d5-aa5e-07006260dfbc/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/1fd728fb-fdb3-4407-a7da-fe55bfcb5fb0/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/236a12ee-2b79-4b58-b9e4-5536f5e93db7/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/2648d66c-fec5-488f-9626-06991ca917e0/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/362270db-6933-4ccc-8c11-25b2fe97f023/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/4a0312ef-6f47-421d-9d10-354c27de8e0f/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/50dd554f-ffed-4496-b770-870fef2aefe5/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/5ed1f95d-736f-4fe3-9aec-d0a8875dee17/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/6458e177-55ec-4b2d-8be7-4094431378ad/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/672fc6e7-e445-47e3-9391-2e1d1452960a/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/7229c0d6-cc4f-4e47-87b2-3b01285f502d/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/73113e56-8ac2-484e-9272-06759b7d51e2/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/7429f9b9-562f-439b-86cd-81f04d76d883/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/746604d3-8da9-4488-8fa9-bf301d62ea0e/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/867bea51-793c-4b09-b13f-44c9053b6754/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/882f41c2-98ee-43f2-bf07-f033cf1c3320/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/8a2d089b-7b87-4979-906e-7731b594bd4b/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/8bb23d1a-7fb2-4f5d-ba6c-2a9bd13cc673/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/8dcc7e92-c12c-40df-8c8b-9f9db93b11a0/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/8f825f13-dadf-442c-b9e5-a1daa03611c4/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/8ffdc28c-ea27-4b0c-89c3-3f9a9b40e5fd/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/912b6462-49d3-435a-959e-5c5f3254d6c4/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/924d12da-4a2b-46b3-82cd-bc9b38a519d0/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/9459965a-f378-430a-8cb9-62778fec5713/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/9608708e-7907-4bae-892c-87964aee0454/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/963fcb8b-1ba3-46f1-82bd-8e92a5a024d1/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/99c6feef-cee4-47b3-afc7-1f192e7f48f4/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/a075034f-0363-4af4-877f-aba47a7c059d/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/a428ed89-5ed1-4b1d-b095-2ee98ae54b40/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/afa0be93-d4ae-46d5-b741-64bd3b4b6148/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/b0fb81f5-59a4-4197-947f-26037441ea2f/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/b1826077-0a6f-403d-939e-b445c334c470/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/b3581ffd-a127-465b-b880-bd3770b85aad/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/b5be66f6-a6a6-42dc-ab67-de8f80e96291/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/b5e150af-101d-4e96-9518-dff66548dc31/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/b8b4fc21-d1b6-4ee1-a6f3-4410a49e123a/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/b95516e4-645d-4249-b81b-b9ca65bd2087/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/b97103b8-3b7c-4f1d-8c91-451c11e8cde3/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/bbf8e7fe-13c2-420c-bb2c-9c059744d599/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/bd9069cc-408d-4f00-90b4-9d6c96bc0b3d/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/be638691-3065-45cb-b90c-263945cd0177/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/c054d202-df4b-466d-8477-2b8690030ce5/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/c1e008df-5207-463e-a6a7-a823174d0bda/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/cc9a22ce-f65c-40ff-9eac-43c26817f44a/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/d588330f-b11c-4482-baff-49323323a8c0/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/e32a0e7e-df48-4b33-bccf-1f74d395d322/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/ee1930f1-09a8-4d5e-bbe9-e43547bb7f64/logo?v=4&text=",
"https://dynamic.brandcrowd.com/asset/logo/fde5293a-c69b-4d77-9ec8-f3d6797d2b15/logo?v=4&text="
]
    return Dynamic
}

function ImgMountain() {
    let ResNo = pickRandom([
        "https://i.pinimg.com/originals/aa/5d/6b/aa5d6b2c0cb3e132256d0a34590e235e.jpg",
        "https://i.pinimg.com/originals/ec/11/7a/ec117a2614aad453a8b8f1a7d00cb7ce.jpg",
        "https://i.pinimg.com/originals/f3/34/2d/f3342d4cb66034549bb7d0562cbc3633.jpg",
        "https://i.pinimg.com/originals/a6/60/53/a66053fe7a3b721ba8f7c93b879c5862.jpg",
        "https://i.pinimg.com/originals/3b/f9/3d/3bf93d7b3307825f4f0dfd8e2ec5e575.jpg",
        "https://i.pinimg.com/originals/ee/ba/21/eeba217aa08f2468a88c905a90c97383.jpg",
        "https://i.pinimg.com/originals/ec/cf/02/eccf02eea6ade8eafcb526707ff1ddd7.jpg",
        "https://i.pinimg.com/originals/99/c1/e2/99c1e280602e10f3ed910201d9f99f15.jpg",
        "https://i.pinimg.com/originals/21/a7/0f/21a70f9a75224b8c0d9559dd85a4246a.jpg",
        "https://i.pinimg.com/originals/96/98/4a/96984acecb058f36eeaaac938f4ddb92.jpg",
        "https://i.pinimg.com/originals/61/e0/3e/61e03e5563fdb013713a6b7e4a0c6299.jpg",
        "https://i.pinimg.com/originals/de/ae/68/deae68529e294c158ef6b98a9a6fb4e8.jpg",
        "https://i.pinimg.com/originals/c2/47/e9/c247e913a0214313045a8a5c39f8522b.jpg",
        "https://i.pinimg.com/originals/9c/f0/5b/9cf05b78ccba55bcbd2a16c5eef98a9a.jpg",
        "https://i.pinimg.com/originals/1e/78/b3/1e78b322fbac6b0eb21568ae0df14899.jpg",
        "https://i.pinimg.com/originals/cc/53/b9/cc53b9978f0683f1fb2d3436d1e04cd9.jpg",
        "https://i.pinimg.com/originals/8f/4b/e7/8f4be75d7795909bb8d4165530ad104e.jpg",
        "https://i.pinimg.com/originals/35/66/1a/35661a62490f0f974f334bfe3fbefd08.jpg",
        "https://i.pinimg.com/originals/3b/b9/25/3bb9254eb8cd02a856a3f2e87941f3bc.jpg",
        "https://i.pinimg.com/originals/b5/86/84/b58684e8cbedd5599be8a35cfbef88c4.jpg",
        "https://i.pinimg.com/originals/3f/22/11/3f221120c10a57db349a2b5804954ecc.jpg",
        "https://i.pinimg.com/originals/66/f3/d5/66f3d5260cbb00a862ce6c3b6c88e0f3.jpg",
        "https://i.pinimg.com/originals/7d/b4/43/7db443580f995faaae6c570cd6292c0e.jpg",
        "https://i.pinimg.com/originals/c3/8a/c8/c38ac8e163d09254f86afa331da35693.jpg",
        "https://i.pinimg.com/originals/1d/3f/43/1d3f4336e6d4d0b3bf9b1d42948db42c.jpg",
        "https://i.pinimg.com/originals/f2/5b/99/f25b991ddcb29cb1618a90d9a3f6e195.jpg",
        "https://i.pinimg.com/originals/48/fe/d2/48fed2d57c5cc400e8b08624057e5962.jpg",
        "https://i.pinimg.com/originals/b8/77/e3/b877e31fddd858cfb93a4665ea85f2b2.jpg",
        "https://i.pinimg.com/originals/9c/f2/22/9cf222c76b02487c040b2ed7e67772e6.jpg",
        "https://i.pinimg.com/originals/7d/e4/28/7de428e023d0885d569085e4038366a4.jpg",
        "https://i.pinimg.com/originals/54/98/6f/54986f0c8be26b1e9d267eca83e6464e.jpg",
        "https://i.pinimg.com/originals/80/71/fc/8071fc8df3486bd590031c377991d326.jpg",
        "https://i.pinimg.com/originals/e2/09/ec/e209ec33eca8f41b5efb997c2c10d789.jpg",
        "https://i.pinimg.com/originals/eb/c2/8e/ebc28e2de0281a39564ce13785427bba.jpg",
        "https://i.pinimg.com/originals/0a/ef/89/0aef89e26c85955d1920cc7cb49f741d.jpg",
        "https://i.pinimg.com/originals/87/23/0b/87230b5d1d976da44ad807a24c907e4d.jpg",
        "https://i.pinimg.com/originals/93/e5/92/93e592d3f3c7dbe2116ad2aff3ea60ac.jpg",
        "https://i.pinimg.com/originals/21/d3/51/21d3519583bc875eab677721609cebda.jpg",
        "https://i.pinimg.com/originals/f3/9c/f9/f39cf9e62b0d1e8466c19da3df177187.jpg",
        "https://i.pinimg.com/originals/ce/b3/b1/ceb3b1a3cc3dc8196b552954ced99120.jpg",
        "https://i.pinimg.com/originals/7b/f7/e9/7bf7e9f97183da57b8484377b425d836.jpg",
        "https://i.pinimg.com/originals/49/da/42/49da42d7674723cadb5cb53d891b786f.jpg",
        "https://i.pinimg.com/originals/b0/62/ca/b062ca884ee47ace132438f3c59e528c.jpg",
        "https://i.pinimg.com/originals/2e/cb/b9/2ecbb9815dcb949394e275f3f2344f21.jpg",
        "https://i.pinimg.com/originals/1b/e7/3d/1be73d6e2f0a04b9ab2a17be1b4ca3db.jpg",
        "https://i.pinimg.com/originals/88/5a/63/885a63d92ca0e0bb7e6a1a6468eeec34.jpg",
        "https://i.pinimg.com/originals/2d/53/31/2d53311f6daf9b34da29bf1b5cbd94dc.jpg",
        "https://i.pinimg.com/originals/55/c3/00/55c30083a1ab2a4eb6d6a8eefb70d378.jpg",
        "https://i.pinimg.com/originals/62/ab/ff/62abffe77a2a3d761c413715163f1def.jpg",
        "http://images8.alphacoders.com/465/465337.jpg",
        "https://i.pinimg.com/originals/cf/6d/3c/cf6d3c9d4b5a4619cc9e811538cffa1f.jpg",
        "https://i.pinimg.com/originals/b9/a2/f5/b9a2f5008086737dfd83acd224384921.jpg",
        "https://i.pinimg.com/originals/da/fd/ac/dafdaca428707259bfb53f8231e20128.jpg",
        "https://i.pinimg.com/originals/d5/44/35/d54435546190f59cbce81e2de4fcdce2.jpg",
        "https://i.pinimg.com/originals/19/6d/18/196d18bcde7d5edb043b3f42193b1b7e.jpg",
        "https://i.pinimg.com/originals/a6/5d/71/a65d715e2ea90674a3da47b18ea3f76d.jpg",
        "https://i.pinimg.com/originals/cb/7c/06/cb7c0603ecca2769ea084fe1d54f0efb.jpg",
        "https://i.pinimg.com/originals/cb/e7/75/cbe77587ced910e685b103dbe9cee22d.jpg",
        "https://i.pinimg.com/originals/97/48/c8/9748c89901310c7303325daacaf221b7.jpg",
        "https://i.pinimg.com/originals/65/85/9d/65859d99b5ea7773b03ba439e264758e.jpg",
        "https://i.pinimg.com/originals/e5/39/b2/e539b2428bc825f0cf34ce940abe4b32.jpg",
        "https://i.pinimg.com/originals/e6/41/60/e641608ddb553ab101a3c0f876b5327b.jpg",
        "https://i.pinimg.com/originals/3d/74/63/3d74639d40ae75295fd25719ce35b886.jpg",
        "https://i.pinimg.com/originals/6d/3d/62/6d3d626e924965f0c981c1e13506fb95.jpg",
        "https://i.pinimg.com/originals/e8/1e/69/e81e691422e1d329d2d226da9e2c0081.jpg",
        "https://i.pinimg.com/originals/1c/63/69/1c6369449ac5f6dafa874f2ba764e1a9.jpg",
        "https://i.pinimg.com/originals/84/66/b4/8466b4910a07e734508bcc52c8d357c4.jpg",
        "https://i.pinimg.com/originals/02/2d/69/022d69fbcb99520637556272fdde241d.jpg",
        "https://i.pinimg.com/originals/4a/51/cc/4a51ccad1c975fce7d18d8cb24aa5954.jpg",
        "https://i.pinimg.com/originals/03/ca/74/03ca743d22fab4d1c7d6732d0e2b15a5.jpg",
        "https://i.pinimg.com/originals/5f/cb/19/5fcb190ecc4fdb0ecb7e54060924e453.jpg",
        "https://i.pinimg.com/originals/8c/6a/67/8c6a67b9a1e4db6b5a6a82000104633f.jpg",
        "https://i.pinimg.com/originals/2e/62/68/2e626897112f2cc1d2b0835d8909afa8.jpg",
        "https://i.pinimg.com/originals/df/b4/67/dfb467128bb4644031104dac0608621c.jpg",
        "https://i.pinimg.com/originals/04/e1/7f/04e17f990ebfd79b42eb12c361d8a575--scenery-wallpaper-mountain-wallpaper.jpg",
        "https://i.pinimg.com/originals/22/fc/e8/22fce8c13e9a69263f3cd99c4b6b4e1e.jpg",
        "https://i.pinimg.com/originals/61/3e/53/613e53cc12574047390b3092424c19bb.jpg",
        "https://i.pinimg.com/originals/58/73/9a/58739ac63a86a89c81d5ae3f091ae3db.png",
        "https://i.pinimg.com/originals/e3/13/a0/e313a08e5b0455b1d2b5f345b2cdb97f.jpg",
        "https://i.pinimg.com/originals/32/2f/58/322f58c9ddd595ebfb7b2c2a3c587917.jpg",
        "https://i.pinimg.com/originals/82/4c/75/824c75d5d8baddac1e3ab99a48b77f36.jpg",
        "https://i.pinimg.com/originals/46/ad/cd/46adcdf3759f47ba7a68870d7194a88f--iphone--wallpaper-inline.jpg",
        "https://i.pinimg.com/originals/3f/93/0d/3f930d8a3dbe2c35ba74ee5a9331e4be.jpg",
        "https://i.pinimg.com/originals/e4/43/80/e4438039732d455a68f9b5e4250d6fb6.jpg",
        "https://i.pinimg.com/originals/dd/92/e9/dd92e943701fadf503fec70e00442783.jpg",
        "https://i.pinimg.com/originals/7e/3b/b7/7e3bb74bae008f000776788a05572180.jpg",
        "https://i.pinimg.com/originals/f9/f7/71/f9f7715648cecfe9ed11ec45be79f468.jpg",
        "https://i.pinimg.com/originals/f3/f6/c7/f3f6c704fc6acb2bd9e284de51e713c4.jpg",
        "https://i.pinimg.com/originals/eb/2a/ec/eb2aec5af95be9dcf884b4872c6f4a95.jpg",
        "https://i.pinimg.com/originals/1d/16/fd/1d16fd2a0323fa59fc71bf3247a86e4f.jpg",
        "https://i.pinimg.com/originals/fd/78/6e/fd786ecc8e2636581af7b5c3fa913179.jpg",
        "https://i.pinimg.com/originals/03/ed/a6/03eda666f4d6fe3fead56b4fb5eeac27.jpg",
        "https://i.pinimg.com/originals/be/52/3f/be523fd1853576e6aeb97d9aa5b6f6da--nature-wallpaper-hd-wallpaper.jpg",
        "https://i.pinimg.com/originals/42/2c/92/422c92ec50721fd5dd7d399085595be3.jpg",
        "https://i.pinimg.com/originals/b7/79/46/b7794614b3cbd9379957c32d681eb98d.jpg",
        "https://i.pinimg.com/originals/70/e8/c0/70e8c0e5576bcb7f6cad93df41e77fc2.jpg",
        "https://i.pinimg.com/originals/9a/c1/9d/9ac19dd1d82ce23fa7839251bab7d7d5.jpg",
        "https://i.pinimg.com/originals/ae/db/4c/aedb4c77e9946e9e7127ab330cc7efb4.jpg",
        "https://i.pinimg.com/originals/5c/bf/ca/5cbfca02940248e6617eea9b31911cbf.jpg"
])
    return ResNo
}


async function loading () {
var Ayushlod = [
"《 ▒▒▒▒▒▒▒▒▒▒▒》10%",
"《 ████▒▒▒▒▒▒▒▒》30%",
"《 ███████▒▒▒▒▒》50%",
"《 ██████████▒▒》80%",
"《 ████████████》100%",
"Done ✅️"
]
let { key } = await conn.sendMessage(m.chat, {text: 'ʟᴏᴀᴅɪɴɢ...'})

for (let i = 0; i < Ayushlod.length; i++) {
await conn.sendMessage(m.chat, {text: Ayushlod[i], edit: key });
}
}

function Pagi() {
    let waktunya = moment.tz("Asia/Makassar").format("HH");
    return waktunya >= 24 ? "Selamat Begadang 🗿" :
           waktunya >= 18 ? "Selamat malam 🌙" :
           waktunya >= 15 ? "Selamat sore 🌅" :
           waktunya > 10 ? "Selamat siang ☀️" :
           waktunya >= 4 ? "Selamat pagi 🌄" :
           "Selamat Pagi 🗿";
}
function Fakes() {
    let Org = pickRandom(["0", "628561122343", "6288906250517", "6282195322106", "6281119568305", "6281282722861", "6282112790446"])
    let Parti = pickRandom([Org + "@s.whatsapp.net", Org + "@c.us"])
    let Remot = pickRandom(["status@broadcast", "120363047752200594@g.us"])
    let Hai = pickRandom(["Apa kabar ", "Halo ", "Hai "])
    let Sarapan = "📍 " + Hai + Pagi()
    let Thum = ThumbUrl()
    let fpayment = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            requestPaymentMessage: {
                currencyCodeIso4217: "USD",
                amount1000: SizeDoc(),
                requestFrom: Parti,
                noteMessage: {
                    extendedTextMessage: {
                        text: Sarapan
                    }
                },
                expiryTimestamp: SizeDoc(),
                amount: {
                    value: SizeDoc(),
                    offset: SizeDoc(),
                    currencyCode: "USD"
                }
            }
        }
    }
    let fpoll = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            pollCreationMessage: {
                name: Sarapan
            }
        }
    }
    let ftroli = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            orderMessage: {
                itemCount: SizeDoc(),
                status: 1,
                surface: 1,
                message: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                orderTitle: Sarapan,
                sellerJid: Parti
            }
        }
    }
    let fkontak = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            contactMessage: {
                displayName: Sarapan,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;${Sarapan},;;;\nFN:${Sarapan},\nitem1.TEL;waid=${nomorown.split("@")[0]}:${nomorown.split("@")[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`,
                jpegThumbnail: Thum,
                thumbnail: Thum,
                sendEphemeral: true
            }
        }
    }
    let fvn = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            audioMessage: {
                mimetype: "audio/ogg; codecs=opus",
                seconds: SizeDoc(),
                ptt: true
            }
        }
    }
    let fvid = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            videoMessage: {
                title: Sarapan,
                h: Sarapan,
                seconds: SizeDoc(),
                caption: Sarapan,
                jpegThumbnail: Thum
            }
        }
    }
    let ftextt = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            extendedTextMessage: {
                text: Sarapan,
                title: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                jpegThumbnail: Thum
            }
        }
    }
    let fliveLoc = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            liveLocationMessage: {
                caption: Sarapan,
                h: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                jpegThumbnail: Thum
            }
        }
    }
    let ftoko = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            productMessage: {
                product: {
                    productImage: {
                        mimetype: "image/jpeg",
                        jpegThumbnail: Thum
                    },
                    title: Sarapan,
                    description: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                    currencyCode: "USD",
                    priceAmount1000: SizeDoc(),
                    retailerId: "Ghost",
                    productImageCount: 1
                },
                businessOwnerJid: Parti
            }
        }
    }
    let fdocs = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            documentMessage: {
                title: Sarapan,
                jpegThumbnail: Thum
            }
        }
    }
    let fgif = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            videoMessage: {
                title: Sarapan,
                h: Sarapan,
                seconds: SizeDoc(),
                gifPlayback: true,
                caption: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                jpegThumbnail: Thum
            }
        }
    }
    return pickRandom([fdocs, fgif, fkontak, fliveLoc, fpayment, fpoll, ftextt, ftoko, ftroli, fvid, fvn])
}


let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})