let handler = async function (m, { conn, args, usedPrefix }) {
  let user = global.db.data.users[m.sender];
  user.ltoken = '';
  user.reghoyo = false
  m.reply(`✅ Token dihapus`);
}
handler.help = ['unregtoken'];
handler.tags = ['hoyolab'];
handler.command = ['unregtoken'];
handler.reghoyo = true
export default handler;