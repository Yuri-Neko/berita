import { promises } from 'fs'
import { join } from 'path'
import fetch from 'node-fetch'
import jimp from 'jimp'
import { xpRange } from '../lib/levelling.js'
import PhoneNumber from 'awesome-phonenumber'
let tags = {
'main': 'TENTANG',
'game': 'GAME',
'econ': 'LEVEL & EKONOMI',
'rg': 'REGISTRASI',
'sticker': 'STIKER',
'img': 'GAMBAR',
'maker': 'PEMBUAT',
'prem': 'PREMIUM',
'group': 'GRUP',
'nable': 'ENABLE/DISABLE',
'nime': 'ANIME',
'rnime': 'REAKSI ANIME',
'dl': 'UNDUHAN',
'tools': 'TOOLS',
'fun': 'FUN',
'cmd': 'DATABASE',
'nsfw': 'NSFW FUCK YOU',
'ansfw': 'NSFW ANIME',
'owner': 'DEVELOPER',
'advanced': 'ADVANCED'
}
const defaultMenu = {
  before: `
◈ ━━━━ Kinako ━━━━ ◈ 
    ◈ ━━━━ BOT ━━━━ ◈

👋🏻 Halo %name
🧿 Level : %level
👥 Pengguna : %totalreg
📈 Waktu Aktif : %muptime
─────────────
▢ Email Admin Jika\nAda Bug
• admin@kyoukanime.my.id
─────────────
%readmore
Ⓟ = Premium
ⓓ = Berlian
-----  -----  -----  -----  -----
  ≡ *DAFTAR MENU*
`.trimStart(),
  header: '┌─⊷ *%category*',
  body: '▢ %cmd %isdiamond %isPremium',
  footer: '└───────────\n',
  after: `
`,
}
let handler = async (m, { conn, usedPrefix: _p, __dirname }) => {
   if (m.isGroup && !global.db.data.chats[m.chat].menu) {
    throw `Admin telah mematikan menu`;
  }
  try {
    let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
    let { exp, diamond, level, role } = global.db.data.users[m.sender]
    let { min, xp, max } = xpRange(level, global.multiplier)
    let name = await conn.getName(m.sender)
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d)
    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
    let _uptime = process.uptime() * 1000
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        diamond: plugin.diamond,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      }
    })
    for (let plugin of help)
      if (plugin && 'tags' in plugin)
        for (let tag of plugin.tags)
          if (!(tag in tags) && tag) tags[tag] = tag
    conn.menu = conn.menu ? conn.menu : {}
    let before = conn.menu.before || defaultMenu.before
    let header = conn.menu.header || defaultMenu.header
    let body = conn.menu.body || defaultMenu.body
    let footer = conn.menu.footer || defaultMenu.footer
    let after = conn.menu.after || (conn.user.jid == conn.user.jid ? '' : `Powered by https://wa.me/${conn.user.jid.split`@`[0]}`) + defaultMenu.after
    let _text = [
      before,
      ...Object.keys(tags).map(tag => {
        return header.replace(/%category/g, tags[tag]) + '\n' + [
          ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
            return menu.help.map(help => {
              return body.replace(/%cmd/g, menu.prefix ? help : '%p' + help)
                .replace(/%isdiamond/g, menu.diamond ? '(ⓓ)' : '')
                .replace(/%isPremium/g, menu.premium ? '(Ⓟ)' : '')
                .trim()
            }).join('\n')
          }),
          footer
        ].join('\n')
      }),
      after
    ].join('\n')
    let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
    let replace = {
      '%': '%',
      p: _p, uptime, muptime,
      me: conn.getName(conn.user.jid),
      npmname: _package.name,
      npmdesc: _package.description,
      version: _package.version,
      exp: exp - min,
      maxexp: xp,
      totalexp: exp,
      xp4levelup: max - exp,
      github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
      level, diamond, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role,
      readmore: readMore
    }
    text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
    
    let pp = './src/fg_logo.jpg'
     
    //conn.sendFile(m.chat, pp, 'menu.jpg', text.trim(), m, null, rpl)
    //m.react('📚')
   /* conn.sendMessage(m.chat, {
      text: text,
      contextInfo: {
        externalAdReply: {
          title: date,
          body: 'bodynya',
          thumbnailUrl: "https://telegra.ph/file/4b0047376a4cf2d8d8b3d.jpg",
          sourceUrl: "https://chat.whatsapp.com/Gqh0DeHyphrES4izhvYnMP",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });*/
    let ftroli = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'
    },
    message: {
    orderMessage: {
    itemCount : 999999,
    status: 404,
    surface : 404,
    message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`, 
    orderTitle: ``,
    thumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(), //Gambarnye
    sellerJid: '0@s.whatsapp.net' 
    }
    }
    }
    
    let fkontak = {
  key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast'
  },
  message: {
    contactMessage: {
      displayName: 'мα∂є ωнιтє куσυкα',
      vcard: 'BEGIN:VCARD\n' +
        'VERSION:3.0\n' +
        'N:XL;мα∂є ωнιтє куσυкα,;;;\n' +
        'FN:мα∂є ωнιтє куσυкα,\n' +
        'item1.TEL;waid=6282112080081:6282112080081\n' +
        'item1.X-ABLabell:Ponsel\n' +
        'END:VCARD',
      jpegThumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
      thumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
      sendEphemeral: true
    }
  }
}
   /* await conn.sendMessage(m.chat, {
  video: {
    url: 'https://telegra.ph/file/c82d5c358495e8ef15916.mp4',
  },
  gifPlayback: true,
  gifAttribution: ~~(Math.random() * 2),
  caption: text,
  contextInfo: {
    externalAdReply: {
      title: date,
      body: 'bodynya',
      thumbnailUrl: 'https://telegra.ph/file/2e139f91d75bf10a08eaa.jpg',
      sourceUrl: "https://chat.whatsapp.com/Gqh0DeHyphrES4izhvYnMP",
      mediaType: 1,
      renderLargerThumbnail: true
    }
  }
}, { quoted: m });*/
      
      
      let sound = [
 "aha.mp3",
  "antabaka.mp3",
  "ara-ara.mp3",
  "arigatou.mp3",
  "baka-kawai.mp3",
  "baka.mp3",
  "beep.mp3",
  "cokoton.mp3",
  "conglaturation.mp3",
  "dattebayo.mp3",
  "deppresion.mp3",
  "fuckyou.mp3",
  "goku.mp3",
  "gomenasai.mp3",
  "good-job.mp3",
  "hunggry.mp3",
  "iyyah.mp3",
  "jutsu.mp3",
  "kawaii.mp3",
  "kimoe.mp3",
  "kirang.mp3",
  "kyaa.mp3",
  "mati.mp3",
  "movment.mp3",
  "nani.mp3",
  "nee-san.mp3",
  "nyaa.mp3",
  "nyaaa.mp3",
  "ohohoho.mp3",
  "okawaicotto.mp3",
  "omaygod.mp3",
  "onii-chan.mp3",
  "onii-san.mp3",
  "owari-da.mp3",
  "rawr.mp3",
  "scared-animegirl.mp3",
  "senpai.mp3",
  "smash-punch.mp3",
  "sugoii.mp3",
  "tehepero.mp3",
  "teleport.mp3",
  "urusai.mp3",
  "yarre-yarre.mp3",
  "yooooooooooo.mp3",
  "yowaiimo-ori.mp3",
  "yowaimo.mp3",
  "zawarudo.mp3"
];

let randomIndex = Math.floor(Math.random() * sound.length);
let randomSound = sound[randomIndex];
  
let audio = `https://github.com/Yuri-Neko/SoundAnime-Api/raw/master/soundanime/${randomSound}`

/*await conn.sendFile(m.chat, audio, 'error.mp3', null, ftroli, true, {
type: 'audioMessage', 
ptt: false, seconds: 0,contextInfo: {
         externalAdReply: { showAdAttribution: true,
 mediaUrl: 'www.instagram.com/admin_kyouka',
    mediaType: 2, 
    description: 'www.instagram.com/admin_kyouka',
    title: "Now Playing...",
    body: wm,
    thumbnail: await (await fetch('https://i.top4top.io/p_2473iqt431.jpg')).buffer(),
    sourceUrl: 'www.instagram.com/admin_kyouka'
 	  }
     }
    })*/
      //////////////////////////////////LOADING TEST
      const pesan = await conn.sendMessage(m.chat, { text: '[□□□□□□□□□□] 0%',  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'This Loading',
       }}},{ quoted: fkontak })
      //const pesan = await conn.sendMessage(m.chat, { text: '[□□□□□□□□□□] 0%',  contextInfo: { forwardingScore: 999, isForwarded:true }}, { quoted: m });
  const animation = [
    '[□□□□□□□□□□] 0%',
    '[■□□□□□□□□□] 10%',
    '[■■□□□□□□□□] 20%',
    '[■■■□□□□□□□] 30%',
    '[■■■■□□□□□□] 40%',
    '[■■■■■□□□□□] 50%',
    '[■■■■■■□□□□] 60%',
    '[■■■■■■■□□□] 70%',
    '[■■■■■■■■□□] 80%',
    '[■■■■■■■■■□] 90%',
    '[■■■■■■■■■■] 100%',
  ];

  let progressAnim = 0;

  function animate() {
    let saveAnim = animation[progressAnim % animation.length];

    conn.relayMessage(m.chat, {
      protocolMessage: {
        key: pesan.key,
        type: 14,
        editedMessage: {
          conversation: saveAnim
        }
      }
    }, {});

    progressAnim++;

    if (progressAnim <= 10) {
      setTimeout(animate, 500); // Timeout set to 500 milliseconds (0.5 seconds)
    } else {
      setTimeout(async () => {
          // Mengedit pesan menjadi "Berhasil Terkirim" setelah media berhasil dikirim
        conn.relayMessage(m.chat, {
          protocolMessage: {
            key: pesan.key,
            type: 14,
            editedMessage: {
              conversation: "Tunggu Menu Sedang Di kirim"
            }
          }
        }, {});
        // Kirim hasil
        const media = await conn.sendMessage(m.chat, {
  video: {
    url: 'https://telegra.ph/file/c82d5c358495e8ef15916.mp4',
  },
  gifPlayback: true,
  gifAttribution: ~~(Math.random() * 2),
  caption: text,
  contextInfo: {
    externalAdReply: {
      forwardingScore: 999, 
      isForwarded:true,
      title: date,
      body: 'Hallo Kawanku',
      thumbnailUrl: 'https://telegra.ph/file/14a7745f434cd21e900d6.jpg',
      sourceUrl: "https://whatsapp.com/channel/0029VaFKGXX77qVPAtZZbH1i",
      mediaType: 1,
      renderLargerThumbnail: true
    }
  }
}, { quoted: ftroli });
          
        //  conn.sendMessage(m.chat, { text: text,  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
          //  newsletterJid: '120363144038483540' + '@newsletter',
            //serverMessageId: '120363144038483540' + '@newsletter'
       // }}})
        
        /*let suara = await conn.sendFile(m.chat, audio, 'error.mp3', null, ftroli, true, {
type: 'audioMessage', 
ptt: false, seconds: 0,contextInfo: {
         externalAdReply: { showAdAttribution: true,
 mediaUrl: 'www.instagram.com/admin_kyouka',
    mediaType: 2, 
    description: 'www.instagram.com/admin_kyouka',
    title: "Now Playing...",
    body: wm,
    thumbnail: await (await fetch('https://telegra.ph/file/2e139f91d75bf10a08eaa.jpg')).buffer(),
    sourceUrl: 'www.instagram.com/admin_kyouka'
 	  }
     }
    })*/
          let notesuaraArray = [];
			for (let i = 0; i < 8; i++) {
  				  notesuaraArray.push(Math.floor(Math.random() * 100) + 1);
			}
          
          let suara = await conn.sendMessage(m.chat, {audio: {url: 'https://sf16-ies-music-sg.tiktokcdn.com/obj/tiktok-obj/7147262602870049538.mp3'}, ptt:true, waveform: notesuaraArray, mimetype: 'audio/mpeg', viewOnce : true, contextInfo: {
         externalAdReply: { showAdAttribution: true,
 mediaUrl: 'www.instagram.com/admin_kyouka',
    mediaType: 3, 
    description: 'www.instagram.com/admin_kyouka',
    title: "Memutar Voice Note...",
    body: "Owner Kyouka Hashiba",
    thumbnail: await (await fetch('https://telegra.ph/file/2e139f91d75bf10a08eaa.jpg')).buffer(),
    sourceUrl: 'www.instagram.com/admin_kyouka'
 	  }
     }} )
        

        // Jika media berhasil dikirim, edit pesan kembali menjadi "Berhasil Terkirim"
        if (media && suara) {
          conn.relayMessage(m.chat, {
            protocolMessage: {
              key: pesan.key,
              type: 14,
              contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'This Loading',
       }},
              editedMessage: {
                conversation: "Berhasil Terkirim"
              }
            }
          }, {});
        }
      }, 500); // Timeout set to 500 milliseconds (0.5 seconds)
    }
  }

  animate();
      
      
    
  } catch (e) {
    conn.reply(m.chat, '❎ Maaf, menu mengalami kesalahan', m)
    throw e
  }
}
handler.help = ['help']
handler.tags = ['main']
handler.command = ['menu', 'help','allmenu'] 
handler.register = false

handler.exp = 3

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [d, 'd ', h, 'h ', m, 'm '].map(v => v.toString().padStart(2, 0)).join('')
}

async function genProfile(conn, m) {
  let font = await jimp.loadFont('./names.fnt'),
    mask = await jimp.read('https://telegra.ph/file/4ef9a2c25234e6c36b1f7.png'),
    welcome = await jimp.read(thumbnailUrl.getRandom()),
    avatar = await jimp.read(await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://telegra.ph/file/24fa902ead26340f3df2c.png')),
    status = (await conn.fetchStatus(m.sender).catch(console.log) || {}).status?.slice(0, 30) || 'Not Detected'

    await avatar.resize(460, 460)
    await mask.resize(460, 460)
    await avatar.mask(mask)
    await welcome.resize(welcome.getWidth(), welcome.getHeight())

    await welcome.print(font, 550, 180, 'Name:')
    await welcome.print(font, 650, 255, m.pushName.slice(0, 25))
    await welcome.print(font, 550, 340, 'About:')
    await welcome.print(font, 650, 415, status)
    await welcome.print(font, 550, 500, 'Number:')
    await welcome.print(font, 650, 575, PhoneNumber('+' + m.sender.split('@')[0]).getNumber('international'))
    return await welcome.composite(avatar, 50, 170).getBufferAsync('image/png')
}
