import axios from "axios";
import PDFDocument from "pdfkit";
import { extractImageThumb } from "@adiwajshing/baileys";
import fetch from "node-fetch";

let handler = async(m, { conn, text }) => {
  try {
    if (!text) throw `Input Link\n contoh .pinattsukipdf 2023/05/gara-no-warui-josou-osu-o-saimin-mesu`;
    await m.reply('_In progress, please wait..._');
    let { data } = await axios.get(`https://api.kyoukastore.my.id/api/nsfw/pinattsuki/detail?apikey=kyouka_admin&url=https://www.pinattsuki.my.id/${encodeURIComponent(text)}.html?m=1`);
    let pages = data.result.chapterImageUrls;
    let thumb = data.result.thumbnail;
    let buffer = await (await fetch(thumb)).buffer();
    let jpegThumbnail = await extractImageThumb(buffer);
    let imagepdf = await toPDF(pages);
      const message = { 
            document: imagepdf,
            jpegThumbnail: await conn.resize(data.result.thumbnail, 280, 210),
            fileName: data.result.title + '.pdf',
            mimetype: "application/pdf",
            caption: data.result.title,
        }
       await conn.sendMessage(m.chat, message, m)
  } catch (error) {
    console.error(error);
    throw 'Something went wrong.';
  }
};

handler.command = /^(pinattsukipdf|pisukipdf)$/i;
handler.tags = ['nsfw'];
handler.help = ['pinattsukipdf <link>'];
handler.group = true
export default handler;

function toPDF(images, opt = {}) {
  return new Promise(async (resolve, reject) => {
    if (!Array.isArray(images)) images = [images];
    let buffs = [], doc = new PDFDocument({ margin: 0, size: 'A4' });
    for (let x = 0; x < images.length; x++) {
      if (/.webp|.gif/.test(images[x])) continue;
      try {
        let data = (await axios.get(images[x], { responseType: 'arraybuffer', ...opt })).data;
        doc.image(data, 0, 0, { fit: [595.28, 841.89], align: 'center', valign: 'center' });
        if (images.length != x + 1) doc.addPage();
      } catch (error) {
        console.error(error);
        reject('Failed to fetch image data.');
      }
    }
    doc.on('data', (chunk) => buffs.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(buffs)));
    doc.on('error', (err) => reject(err));
    doc.end();
  });
}
