//import db from '../lib/database.js'

let handler = async (m, { conn, text, usedPrefix, command }) => {
   let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false
    else who = m.chat
    let user = global.db.data.users[who]
    if (!who) throw `✳️ Etiqueta o menciona a alguien\n\n📌 Ejemplo : ${usedPrefix + command} @user`
    if (who === '6282112080081@s.whatsapp.net') {
        let text = `Maaf yah dia owner sekaligus developer saya , saya tidak dapat membanned dia okey? you fucking bitch`
        conn.sendMessage(m.chat, { text: text,  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
            newsletterJid: '120363144038483540' + '@newsletter',
            serverMessageId: '120363144038483540' + '@newsletter'
        }}})
        return;
    }
    let users = global.db.data.users
    users[who].banned = true
    conn.reply(m.chat, `
✅ BANEADO

───────────
@${who.split`@`[0]} ya  no podrá  usar  mis comandos `, m, { mentions: [who] })
}
handler.help = ['ban @user']
handler.tags = ['owner']
handler.command = /^ban$/i
handler.rowner = true

export default handler
