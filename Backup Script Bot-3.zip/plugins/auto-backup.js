import moment from 'moment-timezone'
import fs from 'fs'
import {execSync} from 'child_process'
import fetch from 'node-fetch'

export async function all(m) {
    let setting = global.db.data.settings[this.user.jid]
    if (setting.readsw) {
        if (new Date() * 1 - setting.backupDB > 3600000) {
            let f = {
  key : {
  remoteJid: 'status@broadcast',
  participant : '0@s.whatsapp.net'
  },
  message: {
  documentMessage: {
  title: 'B A C K U P - B O T', 
                            }
                          }
                        }
	let d = new Date
            let date = d.toLocaleDateString('id', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            })
            
             let nomorown = "6282112080081"
    await conn.reply(nomorown + '@s.whatsapp.net', `*🗓️ Auto Backup Bot:* ${date}`, null)
        const ls = (await execSync('ls')).toString().split('\n').filter(pe => pe != 'node_modules' && pe != 'package-lock.json' && pe != 'baileys_store.json' && pe != 'test.js' && pe != 'kanaeru.json' && pe != 'jadibot' && pe != 'Dockerfile' && pe != 'tmp' && pe != '')
        const exec = await execSync(`zip -r backup_bot.zip ${ls.join(' ')}`)
        await conn.sendMessage(nomorown + '@s.whatsapp.net', { document: await fs.readFileSync('./backup_bot.zip'), fileName: 'Backup Script Bot' + '.zip', mimetype: 'application/zip' }, { quoted: f })
        await execSync('rm -rf backup_bot.zip')
            setting.backupDB = new Date() * 1
        }
    }
    return !0
}