import { generateWAMessageFromContent } from "@adiwajshing/baileys";
let handler = async (m) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw '✳️ Replay video'
  const dataVideo = { ptvMessage: m.quoted };
return await sendMessageFromContent(m.chat, dataVideo);
}
handler.help = ['bulet']
handler.tags = ['tools']
handler.command = ['bulet']

export default handler

async function sendMessageFromContent(jid, message, options = {}) {
  var option = { contextInfo: {}, ...options };
  var prepare = await generateWAMessageFromContent(jid, message, option);
  await conn.relayMessage(jid, prepare.message, { messageId: prepare.key.id });
  return prepare;
}
