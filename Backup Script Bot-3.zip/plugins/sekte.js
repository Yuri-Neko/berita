import cheerio from 'cheerio';
import fetch from 'node-fetch';
import { PDFDocument } from 'pdf-lib';
import axios from 'axios';
import sharp from 'sharp';

async function fetchImage(url) {
  const response = await axios.get(url, { responseType: 'arraybuffer' });
  const imageBuffer = Buffer.from(response.data, 'binary');
  const image = await sharp(imageBuffer).png().toBuffer();
  return image;
}
async function createPdf(images) {
  const pdfDoc = await PDFDocument.create();

  for (const imageUrl of images) {
    const imageBytes = await fetchImage(imageUrl);
    const image = await pdfDoc.embedPng(imageBytes);
    const [imageWidth, imageHeight] = [image.width, image.height];

    const pageWidth = imageWidth;
    const pageHeight = imageHeight;
    const page = pdfDoc.addPage([pageWidth, pageHeight]);

    page.drawImage(image, {
      x: 0,
      y: 0,
      width: pageWidth,
      height: pageHeight,
    });
  }

  const pdfBytes = await pdfDoc.save();
  return pdfBytes;
}


let optionsData = {};

const getpdf = async (url) => {
  let { data } = await axios.get(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/chapter?apikey=kyouka_admin&url=${encodeURIComponent(url)}`);
  let pages = data.result.images;
  let imagepdf = await createPdf(pages);
  const pdfBuffer = Buffer.from(imagepdf);
  return pdfBuffer
};

const getHentaiList = async () => {
  let f = await fetch(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/latest?apikey=kyouka_admin`);
  let result = await f.json();

  const messages = result.map(item => {
    const title = item.title;
    const chapter = item.chapter;
    const date = item.date;
    const image = item.thumbnail;
    const link = item.url;

    const message = {
      title: title,
      chapter: chapter,
      date: date,
      image: image,
      link: link
    };

    return message;
  });

  return messages;
};
const getdetail = async (obj) => {
    let f = await fetch(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/detail?apikey=kyouka_admin&url=${encodeURIComponent(obj.link)}`);
      let result = await f.json();

      const thumb = result.thumb;
      const title = result.title;
      const genres = result.genres.join(', ');
      const rating = result.ratingValue;
      const status = result.status;
      const type = result.type;
      const released = result.released;
      const author = result.author;
      const artist = result.artist;
      const serialization = result.serialization;
      const synopsis = result.synopsis;
      const chapterList = result.chapterList.map(chapter => `Chapter ${chapter.chapterNum}: [Link](${chapter.chapterUrl})\n- ${chapter.chapterDate}`).join('\n\n');

      const message = `
            *DETAIL DOUJIN*\n\n
        Title: ${title}
        Genres: ${genres}
        Rating: ${rating}
        Status: ${status}
        Type: ${type}
        Released: ${released}
        Author: ${author}
        Artist: ${artist}
        Serialization: ${serialization}
        Synopsis: ${synopsis}
      `;
    return message 
};
const getdetails = async (obj) => {
    let f = await fetch(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/detail?apikey=kyouka_admin&url=${encodeURIComponent(obj.link)}`);
      let result = await f.json();
    return result
    };

const getCaption = (obj) => `
📝 *Title:* ${obj.title}
🔗 *Link:* ${obj.link}
🏷️ *Chapter:* ${obj.chapter || "data kosong"}
📢 *Date:* ${obj.date || "data kosong"}
`;



const handler = async (m, { conn }) => {
  const list = await getHentaiList();
  const teks = list.map((obj, index) => `*${index + 1}.* ${obj.title}`).join('\n');
  let { key } = await conn.reply(m.chat, `🔧 Daftar Hasil:\n\n${teks}\n\nBalas pesan ini dengan nomor untuk melihat detail doujin yang di inginkan.`, m);
  optionsData[m.chat] = { list, key, timeout: setTimeout(() => { /*conn.sendMessage(m.chat, { delete: key }); delete optionsData[m.chat];*/ }, 60 * 1000), pesan: conn };
};

handler.before = async m => {
  if (!optionsData[m.chat]) return;
  const { key, pesan } = optionsData[m.chat];
  const lists = optionsData[m.chat];
  const allinone = lists.list.chapterList || lists.list 
  const index = parseInt(m.text.trim());

  if (m.isBaileys || isNaN(index) || index < 1 || index > allinone ) return;
  
  const selectedObj = allinone[index - 1]
  try {
  const detailMessage = await getdetail(selectedObj);
  const list = await getdetails(selectedObj);
  //await pesan.sendMessage(m.chat, { delete: key });
  const teks = list.chapterList.map((obj, index) => `*${index + 1}.* ${obj.chapterNum}`).join('\n');
  let ke = await pesan.sendFile(m.chat,await fetchImage(selectedObj.image), '', detailMessage + `Daftar Hasil:\n\n${teks}\n\nBalas pesan ini dengan nomor untuk mendapatkan file pdf doujin yang di inginkan.`, m);
   let keys = ke.key
      optionsData[m.chat] = { list,keys, timeout: setTimeout(() => { /*conn.sendMessage(m.chat, { delete: key }); delete optionsData[m.chat];*/ }, 60 * 1000), pesan: pesan };
      } catch (error) { 
       const bang = optionsData[m.chat];
       let { data } = await axios.get(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/chapter?apikey=kyouka_admin&url=${encodeURIComponent(selectedObj.chapterUrl)}`);
  		let pages = data.result.images;
  		let imagepdf = await createPdf(pages);
		const pdfBuffer = Buffer.from(imagepdf);
        let fectimg = await fetchImage(data.result.images[0])
         const message = { 
            document: pdfBuffer,
            jpegThumbnail: await pesan.resize(fectimg, 280, 210),
            fileName: data.result.title + '.pdf',
            mimetype: "application/pdf",
            caption: data.result.title,
        }
      await pesan.sendMessage(m.chat, message, m)
     // await pesan.sendMessage(m.chat, { delete: bang.key });
   	  clearTimeout(optionsData[m.chat].timeout);
	  delete optionsData[m.chat];
      } 
}; 





handler.help = ["sekte"];
handler.tags = ["search"];
handler.command = /^(sekte|sek)$/i;
handler.premium = true;

export default handler;