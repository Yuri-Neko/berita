import fetch from "node-fetch"

const free = 5000;
const prem = 20000;
const cooldown = 86400000
let handler = async (m, { conn, isPrems }) => {
  let time = global.db.data.users[m.sender].lastclaim + cooldown;
  if (new Date() - global.db.data.users[m.sender].lastclaim < 86400000) throw `🎁 *Anda sudah mengklaim hadiah harian Anda*\n\n🕚 Silakan kembali dalam *${msToTime(time - new Date())}* `;
  
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;

  try {
    // Fetch API
    let url = `https://api.kyoukastore.my.id/api/hahahahaha?apikey=${apikey}`;
    let response = await fetch(url);
    let data = await response.json();

    if (data.limit) {
      global.db.data.users[m.sender].exp += isPrems ? prem : free;
      m.reply(`
🎁 *HADIAH HARIAN*

▢ *Anda telah menerima:*
▢ *Limit Api*: ${data.limit}
🆙 *XP* : +${isPrems ? prem : free}`);
      global.db.data.users[m.sender].lastclaim = new Date() * 1;
    } else {
      throw '⚠️ Gagal memverifikasi API key';
    }
  } catch (error) {
    throw '⚠️ Gagal melakukan claim. Silakan coba lagi.';
  }
};

handler.help = ['daily'];
handler.tags = ['econ'];
handler.command = ['daily', 'claim'];
handler.register = true

export default handler;

function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = (hours < 10) ? "0" + hours : hours;
  minutes = (minutes < 10) ? "0" + minutes : minutes;
  seconds = (seconds < 10) ? "0" + seconds : seconds;

  return hours + " Jam " + minutes + " Menit";
}
