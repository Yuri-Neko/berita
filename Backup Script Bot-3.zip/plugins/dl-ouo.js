import fetch from 'node-fetch';

let handler = async (m, { conn, text, command }) => {
  if (!text) throw 'URL mirrored.to'; // Memeriksa apakah ada argumen URL yang diberikan
  let res = await fetch(`https://api.lolhuman.xyz/api/ouo?apikey=IchanZX&url=${text}`);
  let data = await res.json();
  let results = data.result;

  await m.reply(data.result); // Mengirim pesan balasan melalui WhatsApp
};

handler.command = ['ouo', 'ouobypass','bpouo'];
handler.help = ['ouo'];
handler.tags = ['dl'];

export default handler;
