import fetch from 'node-fetch';

let handler = async (m, { conn, text }) => {
  let wm = "KyoukaHashiba";
  let fdoc = { quoted: { key: { participant: '0@s.whatsapp.net' }, message: { documentMessage: { title: wm } } } };

  try {
    let response = await fetch('https://api.waifu.im/search/?included_tags=hentai');
    let data = await response.json();

    let image = data.images[0]; // Ambil elemen pertama dari array images

    let tags = image.tags.map(tag => `*${tag.name}*: ${tag.description}`).join('\n'); // Mendapatkan semua deskripsi tags

    let description = image.tags[1].description; // Mendapatkan deskripsi dari tag kedua
    let isNsfw = image.tags[1].is_nsfw ? "NSFW" : "SFW"; // Menentukan status NSFW atau SFW

    let caption = `Source: ${image.source}\nFavorite: ${image.favorites}\n\nTags:\n${tags}\n\nType: ${isNsfw}`;

    conn.sendFile(m.chat, image.url, 'gambar.jpg', caption, m, fdoc);
  } catch (error) {
    console.log(error);
    m.reply('Terjadi kesalahan saat mengambil gambar hentai.');
  }
};

handler.help = ['hentai'];
handler.tags = ['img'];
handler.command = ['hentai'];
handler.premium = true;
handler.diamond = true;

export default handler;
