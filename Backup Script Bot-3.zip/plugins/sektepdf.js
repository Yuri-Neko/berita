import fetch from 'node-fetch';
import { PDFDocument } from 'pdf-lib';
import axios from 'axios';
import sharp from 'sharp';

async function fetchImage(url) {
  const response = await axios.get(url, { responseType: 'arraybuffer' });
  const imageBuffer = Buffer.from(response.data, 'binary');
  const image = await sharp(imageBuffer).png().toBuffer();
  return image;
}

async function createPdf(images) {
  const pdfDoc = await PDFDocument.create();

  for (const imageUrl of images) {
    const imageBytes = await fetchImage(imageUrl);
    const image = await pdfDoc.embedPng(imageBytes);
    const [imageWidth, imageHeight] = [image.width, image.height];

    const pageWidth = imageWidth;
    const pageHeight = imageHeight;
    const page = pdfDoc.addPage([pageWidth, pageHeight]);

    page.drawImage(image, {
      x: 0,
      y: 0,
      width: pageWidth,
      height: pageHeight,
    });
  }

  const pdfBytes = await pdfDoc.save();
  return pdfBytes;
}

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;

  if (!text) throw '.sekpdf https://sektedoujin.lol/boarding-diary-uncen-chapter-70/';

  await m.reply('_In progress, please wait..._');

  let { data } = await axios.get(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/chapter?apikey=${apikey}&url=${encodeURIComponent(text)}`);
  let pages = data.result.images;
  let imagepdf = await createPdf(pages);

  const pdfBuffer = Buffer.from(imagepdf);

  await conn.sendFile(m.chat, pdfBuffer, data.result.title + '.pdf', data.result.title, m);
};

handler.command = /^(sektepdf|sekpdf)$/i;
handler.tags = ['nsfw'];
handler.help = ['sektepdf <link>'];
handler.register = true

export default handler;
