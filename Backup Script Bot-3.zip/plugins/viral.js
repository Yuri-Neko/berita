import axios from 'axios';

async function makeRequests() {
  const latestUrl = 'https://web.api-kyouka.my.id/api/nsfw/igodesu/latest?apikey=kyouka_admin';

  try {
    // Permintaan pertama untuk mendapatkan data latest
    const response1 = await axios.get(latestUrl);
    const data1 = response1.data;

    if (data1 && data1.result && data1.result.length > 0) {
      // Mengambil URL dari latest
      const latestResult = data1.result[0];
      const detailUrl = `https://web.api-kyouka.my.id/api/nsfw/igodesu/detail?apikey=kyouka_admin&url=${encodeURIComponent(
        latestResult.link
      )}`;

      // Permintaan kedua untuk mendapatkan detail dengan menggunakan URL dari latest
      const response2 = await axios.get(detailUrl);
      const data2 = response2.data;

      if (data2 && data2.result && data2.result.url_download) {
        const uploadUrl = `https://doodapi.com/api/upload/url?key=244926i6hh6uzu6bzzo67a&url=${encodeURIComponent(
          data2.result.url_download
        )}`;

        // Permintaan ketiga untuk mengupload URL ke doodapi.com
        const response3 = await axios.get(uploadUrl);
        const data3 = response3.data;

        return data3; // Mengembalikan data3
      } else {
        return 'Tidak dapat memperoleh URL dari detail';
      }
    } else {
      return 'Tidak ada hasil latest yang ditemukan';
    }
  } catch (error) {
    throw new Error('Terjadi kesalahan: ' + error.message);
  }
}

let handler = async (m, { conn, text }) => {
  let ftroli = {
    key: {
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      orderMessage: {
        itemCount: 2023,
        status: 404,
        surface: 404,
        message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`,
        orderTitle: ``,
        thumbnail: (await axios.get('https://helper--startgrow.repl.co/buffer?url=https://telegra.ph/file/5f028205d010a090a21fb.jpg', { responseType: 'arraybuffer' })).data, // Gambarnya
        sellerJid: '0@s.whatsapp.net'
      }
    }
  };

  m.reply("Tunggu sebentar, sedang memuat... Mohon bersabar.");

  try {
    const result = await makeRequests();
    const files = result.files;

    const messages = files.map(item => {
      const uploaded = item.uploaded;
      const title = item.title;
      const views = item.views;
      const downloadUrl = item.download_url;
      const length = item.length;
      const fileCode = item.file_code;
      const publicStatus = item.public;
      const canPlay = item.canplay;
      const imageUrl = item.single_img;

      const message = `
        Uploaded: ${uploaded}
        Title: ${title}
        Views: ${views}
        Download URL: ${downloadUrl}
        Length: ${length}
        File Code: ${fileCode}
        Public: ${publicStatus}
        Can Play: ${canPlay}
        Image URL: ${imageUrl}
      `;

      return message;
    });

    // Menggabungkan semua pesan menjadi satu string
    const tet = messages.join('\n*----------------------------------*');

    conn.reply(m.chat, tet, ftroli);
  } catch (error) {
    console.log(error.message);
    conn.reply(m.chat, 'Terjadi kesalahan saat memproses permintaan', m);
  }
};

handler.command = ['viral'];
handler.help = ['viral'];
handler.tags = ['main'];
handler.register = true;

export default handler;
