import axios from 'axios'
import jimp from 'jimp'
import FormData from 'form-data'


let handler = async (m,{ conn, args,usedPrefix, command }) => {
  m.reply("Tunggu Yah Ga Lama Kok")
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || q.mediaType || ''
  if (!mime) throw '✳️ MANA GAMBAR NYA SAYANG'
  let media = await q.download?.()
  let proses = await remini(media, "enhance");
  conn.sendMessage(m.chat, { image: proses, caption: "Done"}, m)
}
handler.help = ['remini']
handler.tags = ['tools']
handler.command = ['remini']

export default handler

async function remini(imageData, operation) {
  return new Promise(async (resolve, reject) => {
    const availableOperations = ['enhance', 'recolor', 'dehaze'];
    const selectedOperation = availableOperations.includes(operation) ? operation : availableOperations[0];
    const url = 'https://inferenceengine.vyro.ai/' + selectedOperation;
    const formData = new FormData();

    formData.append('model_version', 1, {
      'Content-Transfer-Encoding': 'binary',
      contentType: 'multipart/form-data; charset=utf-8',
    });
    formData.append('image', Buffer.from(imageData), {
      filename: 'enhance_image_body.jpg',
      contentType: 'image/jpeg',
    });

    formData.submit(
      {
        url: url,
        host: 'inferenceengine.vyro.ai',
        path: '/' + selectedOperation,
        protocol: 'https:',
        headers: {
          'User-Agent': 'okhttp/4.9.3',
          Connection: 'Keep-Alive',
          'Accept-Encoding': 'gzip',
        },
      },
      function (error, response) {
        if (error) {
          reject();
        }
        let responseData = [];
        response
          .on('data', function (chunk) {
            responseData.push(chunk);
          })
          .on('end', () => {
            resolve(Buffer.concat(responseData));
          });
        response.on('error', (error) => {
          reject();
        });
      }
    );
  });
}
