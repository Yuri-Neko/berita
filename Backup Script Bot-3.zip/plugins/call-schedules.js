let handler = async (m, { conn,text , command, usedPrefix}) => {
 if (!text) throw `✳️ Masukkan judul panggilan\n\n📌 Contoh: ${usedPrefix + command} Kuy Join`
 await conn.relayMessage(m.chat, { scheduledCallCreationMessage: {
scheduledTimestampMs:Date.now(), 
callType:2,title: text}}, { messageId: m.id })
}
handler.help = ['call']
handler.tags = ['group']
handler.command = ['call']
handler.group = true
handler.admin = false
handler.botAdmin = false
handler.owner = true

export default handler

