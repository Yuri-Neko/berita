import fetch from 'node-fetch';
import uploadImage from '../lib/uploadImage.js';

const getAnilistInfo = async (id) => {
  try {
    const response = await fetch("https://graphql.anilist.co/", {
      method: "POST",
      body: JSON.stringify({
        query: `query($id: Int) {
          Media(id: $id, type: ANIME) {
            id
            idMal
            title {
              native
              romaji
              english
            }
            synonyms
            isAdult
          }
        }
        `,
        variables: { id },
      }),
      headers: { "Content-Type": "application/json" },
    });

    if (response.status >= 400) {
      console.error(response.status, await response.text());
      return { error: "Anilist API error, please try again later." };
    }

    const { data } = await response.json();
    return data.Media;
  } catch (error) {
    console.error(error);
    return { error: "An error occurred." };
  }
};

let handler = async(m, { conn, usedPrefix, text, args, command }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw 'Fotonya Mana?'
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Tipe ${mime} tidak didukung!`
  let img = await q.download?.()
  let url = await uploadImage(img)

  let json = await fetch(`https://api.trace.moe/search?url=${url}`)
  let jsons = await json.json()
  let x = jsons.result[0]
  
  // Mendapatkan informasi dari Anilist
  const { title: { chinese, english, native, romaji } = {}, isAdult } = await getAnilistInfo(
      x.anilist
    );

  let caption = `*⎔┉━「 ${command} 」━┉⎔*
*Title:* ${romaji}
*Japan Title:* ${native}
*Englise:* ${english}
*Episode:* ${x.episode}
*Anilist :* https://anilist.co/anime/${x.anilist}
*Kecocokan:* ${x.similarity}
`
let buffer = await fetch(`${x.video}&size=l`).then((r) => r.buffer());
  conn.sendFile(m.chat, x.image, 'gambar.mp4', caption, m)
}

handler.help = ['whatanime <pencarian>']
handler.tags = ['tools']
handler.command = ['whatanime', 'carianime']

export default handler
