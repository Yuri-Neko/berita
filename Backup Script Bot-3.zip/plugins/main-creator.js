import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
    const imageBuffer = await fetch('https://telegra.ph/file/4a93fea0b936f2f4e6fd6.jpg').then(response => response.buffer());
const thumbnailBase64 = imageBuffer.toString('base64');
  //const data = global.owner.filter(([id, isCreator]) => id && isCreator)
  //this.sendContact(m.chat, data.map(([id, name]) => [id, name]), m)
     let fkontak = {
  key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast'
  },
  message: {
    contactMessage: {
      displayName: 'мα∂є ωнιтє куσυкα',
      vcard: 'BEGIN:VCARD\n' +
        'VERSION:3.0\n' +
        'N:XL;мα∂є ωнιтє куσυкα,;;;\n' +
        'FN:мα∂є ωнιтє куσυкα,\n' +
        'item1.TEL;waid=6282112080081:6282112080081\n' +
        'item1.X-ABLabell:Ponsel\n' +
        'END:VCARD',
      jpegThumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
      thumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
      sendEphemeral: true
    }
  }
}
     
    await conn.sendContact(m.chat, [[`${nomorown}` + `@s.whatsapp.net`, "Owner KyoukaHashiba"]], fkontak, {
 contextInfo: { 
 forwardingScore: 999, 
 isForwarded:true ,
 externalAdReply: {  
 title: 'KyoukaHashiba', 
 body: bottime, 
 sourceUrl: 'http://kyoukanime.my.id/',
 thumbnail: thumbnailBase64,
 thumbnailUrl: " https://telegra.ph/file/4a93fea0b936f2f4e6fd6.jpg", 
 mediaType: 1,
 showAdAttribution: true, 
 renderLargerThumbnail: true
 },
 forwardedNewsletterMessageInfo: {
      newsletterJid: '120363185327469702' + '@newsletter',
      serverMessageId: '120363185327469702' + '@newsletter',
      newsletterName: "🃏KyoukaHashiba Official Channel",
      contentType: null,
      accessibilityText: null
    }
   }
     },
       {
         quoted: fkontak,
         ephemeralExpiration: 999999999
           }
             );
   await conn.sendMessage(m.chat, {
  text: "Itu Nomer Owner Bang, di save yah",
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    externalAdReply: {
      title: 'KyoukaHashiba',
      body: bottime,
      sourceUrl: 'http://kyoukanime.my.id/', //text jika di teruskan
      thumbnail: thumbnailBase64,
      thumbnailUrl: "https://telegra.ph/file/4a93fea0b936f2f4e6fd6.jpg",
      mediaType: 1,
      showAdAttribution: true,
      renderLargerThumbnail: true
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363185327469702' + '@newsletter',
      serverMessageId: '120363185327469702' + '@newsletter',
      newsletterName: "🃏KyoukaHashiba Official Channel",
      contentType: null,
      accessibilityText: null
    },
    businessMessageForwardInfo: {
      businessOwnerJid: conn.user.jid
    }
  }
}, { quoted: fkontak });


    //const pesan = await conn.sendMessage(m.chat, { text: 'Langsung DM IG @admin_kyouka ae klo mw request atau nemu bug',  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
         //  newsletterJid: '120363144038483540' + '@newsletter',
           //serverMessageId: '120363144038483540' + '@newsletter'
       //}}},{ quoted: fkontak })

}

handler.help = ['owner']
handler.tags = ['main']
handler.command = ['owner', 'creator'] 

export default handler
