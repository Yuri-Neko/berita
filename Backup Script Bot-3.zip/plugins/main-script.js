import { promises } from 'fs'
import { join } from 'path'
import moment from 'moment-timezone'
import fetch from 'node-fetch'


let handler = async function (m, { conn, __dirname }) {
    let res = await fetch('https://api.github.com/repos/Yuri-Neko/YAEMIKO-MD')
    let json = await res.json()
    let txt = `*乂  B O T  -  S C R I P T*\n\n`
    txt += `	◦  *Name* : ${json.name}\n`
    txt += `	◦  *Visitor* : ${json.watchers_count}\n`
    txt += `	◦  *Size* : ${(json.size / 1024).toFixed(2)} MB\n`
    txt += `	◦  *Updated* : ${moment(json.updated_at).format('DD/MM/YY - HH:mm:ss')}\n`
    txt += `	◦  *Url* : ${json.html_url}\n\n`
    txt += `	   ${json.forks_count} Forks · ${json.stargazers_count} Stars · ${json.open_issues_count} Issues\n\n`
    txt += author
  const imageBuffer = await fetch('https://telegra.ph/file/4a93fea0b936f2f4e6fd6.jpg').then(response => response.buffer());
const thumbnailBase64 = imageBuffer.toString('base64');
    
    let fkontak = {
  key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast'
  },
  message: {
    contactMessage: {
      displayName: 'мα∂є ωнιтє куσυкα',
      vcard: 'BEGIN:VCARD\n' +
        'VERSION:3.0\n' +
        'N:XL;мα∂є ωнιтє куσυкα,;;;\n' +
        'FN:мα∂є ωнιтє куσυкα,\n' +
        'item1.TEL;waid=6282112080081:6282112080081\n' +
        'item1.X-ABLabell:Ponsel\n' +
        'END:VCARD',
      jpegThumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
      thumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
      sendEphemeral: true
    }
  }
}
    
    await conn.sendMessage(m.chat, {
  text: txt,
  contextInfo: {
    mentionedJid: ["0@s.whatsapp.net"],
        groupMentions: [],
        isForwarded: true,
        expiration: global.ephemeral,
        ephemeralSettingTimestamp: {
            low: Date.now(),
            high: 0,
            unsigned: false
        },
        disappearingMode: {
            initiator: 0,
            trigger: 0
        },
    forwardingScore: 999,
    isForwarded: true,
    externalAdReply: {
      title: 'KyoukaHashiba',
      body: bottime,
      sourceUrl: 'http://kyoukanime.my.id/', //text jika di teruskan
      thumbnail: thumbnailBase64,
      thumbnailUrl: "https://telegra.ph/file/4a93fea0b936f2f4e6fd6.jpg",
      mediaType: 1,
      showAdAttribution: true,
      renderLargerThumbnail: true
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363185327469702' + '@newsletter',
      serverMessageId: '120363185327469702' + '@newsletter',
      newsletterName: "🃏KyoukaHashiba Official Channel",
      contentType: null,
      accessibilityText: null
    },
    businessMessageForwardInfo: {
      businessOwnerJid: conn.user.jid
    }
  }
}, { quoted: fkontak });
    
    
}


handler.help = ['script']
handler.tags = ['main']
handler.command = ['sc'] 

export default handler
