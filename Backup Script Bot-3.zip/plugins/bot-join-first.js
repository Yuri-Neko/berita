export async function before(m) {
  if (m.isBaileys || !m.text.startsWith('.')) return;
  const sgc = "https://chat.whatsapp.com/JvwXXZMS3koBIFfC3A3AP8";
  const groupCode = sgc.split('/').pop();
  const { id } = await this.groupGetInviteInfo(groupCode);
  const data = (await this.groupMetadata(id)) || (await this.chats[id].metadata) || null;
  if (!data) return;
  const isIdExist = data.participants.some(participant => participant.id === m.sender);
  global.db.data.chats[m.chat].isBanned = !isIdExist;
  if (!isIdExist) {
    const urls = "https://chat.whatsapp.com/";
    const inviteCode = await this.groupInviteCode(id);
    const caption = `🤖 Silakan bergabung terlebih dahulu ke grup bot untuk menggunakan layanannya.\n\nBergabung di sini: ${urls + inviteCode}`;
    await this.reply(m.chat, caption, m);
  }
}

export const disabled = false;
