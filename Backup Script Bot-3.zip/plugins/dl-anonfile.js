import axios from 'axios';

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `✳️ Masukkan link Anonfiles\n\n📌 Contoh: ${usedPrefix + command} https://anonfiles.com/adG1m705z9`;
  if (!args[0].match(/anonfiles.com/gi) && args[0] !== 'zippysha.re') {
    throw "❎ Pastikan link tersebut adalah link anonfiles.com";
  }

  let user = global.db.data.users[m.sender];
  let apikey = user.apis;
  m.react(rwait);
  
  try {
    let res = (await axios.get(`https://web.api-kyouka.my.id/api/download/anonfile?apikey=${apikey}&url=${encodeURIComponent(args[0])}`)).data;
    await m.reply('Sedang diproses...');
    await conn.sendFile(m.chat, res.result.downloadLink, res.result.fileName, `File Name: ${res.result.fileName}\nSize${res.result.sizeFile}`, m);
    m.react(done);
  } catch (error) {
    console.error('Error:', error);
    m.reply('Maaf, terjadi kesalahan saat memproses permintaan.');
  }
};

handler.help = ['anonfile'];
handler.tags = ['dl'];
handler.command = /^(anonfile|anon)$/i;
handler.register = true;

export default handler;
