import axios from 'axios';

export async function before(m, { conn }) {
  const chat = global.db.data.chats[m.chat];
  if (m.isBaileys || !m.text) {
    return false;
  }
  let text = m.text;
  if (chat.autochat) {
    try {
        const aiResponse = await getAssistantResponse(text);
      conn.sendMessage(m.chat, {
        text: `${aiResponse}`,
      });
    } catch (error) {
      console.error("Error during API request:", error);
    }
  }
}

export const disabled = false;

function getAssistantResponse(text) {
    const apiUrl = "https://api.azz.biz.id/api/gptlogic";
    const role = "pacar";
    const sifat = "ramah, santai, dan responsif";
    const nama = "Yuika";
    const respon = "text singkat dan tidak formal, Pemalu, gugup, tsundere, malu-malu";

    const params = {
        role: role,
        sifat: sifat,
        nama: nama,
        respon: respon,
        text: text
    };

    return axios.get(apiUrl, { params })
        .then(response => response.data)
        .then(data => {
            if (data.hasil && data.hasil.status === "OK") {
                return data.hasil.response;
            } else {
                throw new Error("Invalid response format");
            }
        })
        .catch(error => {
            console.error("Error:", error.message || error);
            return { error: `Request failed: ${error.message || error}` };
        });
}