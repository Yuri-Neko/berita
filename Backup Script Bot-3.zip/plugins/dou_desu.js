/*import fetch from 'node-fetch';

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;

  m.reply('Tunggu yah agak lama loading nya...ada cloudplare');

  let f = await fetch('https://helper.startgrow.repl.co/igstalk?username=dou_desu');
  let x = await f.json();

  let ftroli = {
    key: {
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      orderMessage: {
        itemCount: 2023,
        status: 404,
        surface: 404,
        message: `${x.fullName}`,
        orderTitle: '',
        thumbnail: await (await fetch(x.profilePhotoUrl)).buffer(), // Gambarnye
        sellerJid: '0@s.whatsapp.net'
      }
    }
  };

  let caption = x.posts.map(post => {
    return {
      title: post.title,
      time: post.time,
      likes: post.likes,
      comments: post.comments,
      dataSrc: post.dataSrc,
      url: post.url,
      images: post.images
    };
  });

  x.posts.forEach((post, index) => {
    const imageIndex = index + 1;
    const imageName = `image${imageIndex}.jpg`;
    const imageCaption = `Title: ${post.title}\nTime: ${post.time}\nLikes: ${post.likes}\nComments: ${post.comments}`;

    setTimeout(() => {
      conn.sendFile(m.chat, post.dataSrc, imageName, imageCaption, ftroli);
    }, index * 5000); // Delay 2 seconds (2000 milliseconds) between each image
  });
};

handler.command = ['dou_desu'];
handler.help = ['dou_desu'];
handler.tags = ['main'];
handler.register = true;
export default handler;
*/



import fetch from 'node-fetch';

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;

  m.reply('Tunggu yah agak lama loading nya...ada cloudplare');

  let f = await fetch('https://helper.startgrow.repl.co/igstalk?username=otaku_anime_indonesia');
  let x = await f.json();

  let ftroli = {
    key: {
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      orderMessage: {
        itemCount: 2023,
        status: 404,
        surface: 404,
        message: `${x.fullName}`,
        orderTitle: '',
        thumbnail: await (await fetch(x.profilePhotoUrl)).buffer(), // Gambarnye
        sellerJid: '0@s.whatsapp.net'
      }
    }
  };

  x.posts.forEach((post, index) => {
    post.images.forEach((image, imageIndex) => {
      const imageName = `image${index + 1}_${imageIndex + 1}.jpg`;
      const imageCaption = `Title: ${post.title}\nTime: ${post.time}\nLikes: ${post.likes}\nComments: ${post.comments}`;

      setTimeout(() => {
        conn.sendFile(m.chat, image, imageName, imageCaption, ftroli);
      }, (index * 10000) + (imageIndex * 10000)); // Delay between each image
    });
  });
};

handler.command = ['dou_desu'];
handler.help = ['dou_desu\n[info update doujindesu]'];
handler.tags = ['main'];
handler.owner = true;
export default handler;


