import fetch from 'node-fetch';
import axios from 'axios';
import sharp from 'sharp';
import NekoBocc from 'nekobocc';
const nekobocc = new NekoBocc();

async function fetchImage(url) {
  const response = await axios.get(url, { responseType: 'arraybuffer' });
  const imageBuffer = Buffer.from(response.data, 'binary');
  const image = await sharp(imageBuffer).png().toBuffer();
  return image;
}

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;
  let ftroli = {
    key: {
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      orderMessage: {
        itemCount: 2023,
        status: 404,
        surface: 404,
        message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`,
        orderTitle: '',
        thumbnail: await (await fetch('https://helper--startgrow.repl.co/buffer?url=https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
        sellerJid: '0@s.whatsapp.net'
      }
    }
  };

  if (!text) {
    m.reply("Tunggu sebentar, sedang memuat...");

    try {
      let result = await nekobocc.release()
      //let result = await f.json();

      const messages = result.map(item => {
        const title = item.title;
        const image = item.img;
        const link = item.url;

        const message = `
          Title: ${title}
          Thumbnail: ${image}
          Link: ${link}
        `;

        return message;
      });

      const combinedMessage = messages.join('\n*----------------------------------*');

      conn.reply(m.chat, '*NekoPoi Terbaru*\n' + combinedMessage, ftroli);
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat memuat NekoPoi terbaru', m);
    }
  } else if (text.startsWith("https://nekopoi.care/")) {
    const url = text.trim();

    m.reply("Tunggu sebentar, sedang mengambil detail...");

    try {
      let result = await nekobocc.get(url)
      //let result = await f.json();

      const thumb = result.img;
      const title = result.title;
      //const genres = result.genre.join(', ');
      //const genres = result.genres.split(', ').map(genre => genre.trim());
      const genresArray = result.genre.split(', ');
      const genres = genresArray.join(', ');
      const producer = result.producer;
      const duration = result.duration;
      const synopsis = result.synopsis;
      const LinkDownload = result.download.map((download, index) => `Download ${index + 1}: ${download}`).join('\n\n');

      const message = `
            *DETAIL NekoPoi*\n\n
        Title: ${title}
        Genres: ${genres}
        Producer: ${producer}
        Duration: ${duration}
        Synopsis: ${synopsis}
        
        *Link Download*
        ${LinkDownload}
      `;
       
      conn.sendFile(m.chat, await fetchImage(thumb), 'img.jpg', message, ftroli);

      //conn.reply(m.chat, message, ftroli);
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat mengambil detail NekoPoi', m);
    }
  } else {
    const query = text.trim();

    m.reply("Tunggu sebentar, sedang melakukan pencarian...");

    try {
       let result = await nekobocc.search(query)
      //let result = await f.json();

      const messages = result.map(item => {
        const title = item.title;
        const image = item.img;
        const link = item.url;

        const message = `
          Title: ${title}
          Thumbnail: ${image}
          Link: ${link}
        `;

        return message;
      });

      const combinedMessage = messages.join('\n*----------------------------------*');

      conn.reply(m.chat, '*NekoPoi Search*\n' + combinedMessage, ftroli);
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat melakukan pencarian NekoPoi', m);
    }
  }
};

handler.command = ['nekopoi'];
handler.help = ['nekopoi'];
handler.tags = ['main'];
handler.premium = true

export default handler;