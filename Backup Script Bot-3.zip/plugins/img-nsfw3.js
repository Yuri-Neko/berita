import fetch from 'node-fetch';
import axios from 'axios';

let handler = async (m, { conn, text, command }) => {
   if (db.data.chats[m.chat].nsfw == false && m.isGroup) return conn.reply(m.chat, `❗ ᴏᴘᴛɪᴏɴs ɴsғᴡ ᴅɪᴄʜᴀᴛ ɪɴɪ ʙᴇʟᴜᴍ ᴅɪɴʏᴀʟᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ\nketik *.on nsfw*`)
  let wm = "KyoukaHashiba";
  let fdoc = { quoted: { key: { participant: '0@s.whatsapp.net' }, message: { documentMessage: { title: wm } } } };

  try {
    for (let i = 0; i < 1; i++) {
      let response = await fetch(`https://fantox-apis.vercel.app/${command}`);
      let mek = await response.json()
      await conn.sendFile(m.chat, mek.url, "", `Nih kak ${m.name}`, m) 
      const botToken = '6258272191:AAHBNSQWAm8bVQf9FOYDVHwu5w16Yz0yN_Q';
      const chatId = '5612165840';
      const apiUrl = `https://api.telegram.org/bot${botToken}/sendPhoto`;
      const message = `Halo, ini pesan dari WhatsApp!`;
     // await axios.post(apiUrl, {
       // chat_id: chatId,
       // photo: mek.url,
       // caption: `Nih kak ${m.name}`
  //    });
      await new Promise(resolve => setTimeout(resolve, 10000)); // Tambahkan pembatas waktu 5 detik
    }
  } catch (error) {
    console.log(error);
    m.reply(`Terjadi kesalahan saat mengambil gambar ${command}.`);
  }
};

handler.command = handler.help = ["animal", "animalears", "anusview", "barefoot", "bed", "bell", "bikini", "blonde", "bondage", "bra", "breasthold", "breasts", "bunnyears", "bunnygirl", "chain", "closeview", "cloudsview", "dress", "drunk", "elbowgloves", "erectnipples", "fateseries", "fingering", "flatchest", "food", "foxgirl", "gamecg", "genshin", "glasses", "gloves", "greenhair", "hatsunemiku", "hcatgirl", "headband", "headdress", "headphones", "hentaimiku", "hentaivideo", "hloli", "hneko", "hololove", "horns", "inshorts", "japanesecloths", "necklace", "nipples", "nobra", "nsfwbeach", "nsfwbell", "nsfwdemon", "nsfwidol", "nsfwmaid", "nsfwmenu", "nsfwvampire", "nude", "openshirt", "pantyhose", "pantypull", "penis", "pinkhair", "ponytail", "pussy", "ribbons", "schoolswimsuit", "schooluniform", "seethrough", "sex", "sex2", "sex3", "shirt", "shirtlift", "skirt", "spreadlegs", "spreadpussy", "squirt", "stockings", "sunglasses", "swimsuit", "tail", "tattoo", "tears", "thighhighs", "thogirls", "topless", "torncloths", "touhou", "twintails", "uncensored", "underwear", "vocaloid", "weapon", "wet", "white", "whitehair", "wings", "withflowers", "withgun", "withpetals", "withtie", "withtree", "wolfgirl", "yuri"]
handler.tags = ['img', 'nsfw'];
handler.premium = true;
handler.diamond = true;

export default handler;
