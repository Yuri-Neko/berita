import fetch from 'node-fetch';

let handler = async (m, { conn, text, command }) => {
  if (!text) throw 'URL mirrored.to'; // Memeriksa apakah ada argumen URL yang diberikan
  let res = await fetch(`https://web.api-kyouka.my.id/api/other/mirror?apikey=kyouka_admin&url=${text}`);
  let data = await res.json();
  let results = data.result;

  let response = '';
  for (let result of results) {
    let status = result.status ? result.status : 'Not available';
    response += `• ${result.host}: ${result.url ? result.url : 'Not available'} (${status})\n`;
  }

  await m.reply(response); // Mengirim pesan balasan melalui WhatsApp
};

handler.command = ['mirrbyp', 'mb', 'mirroredbypass','mirror'];

export default handler;
