import uploadFile from '../lib/uploadFile.js'
import uploadImage from '../lib/uploadImage.js'
import axios from 'axios'
import { webp2png } from '../lib/webp2mp4.js'

export async function before(m, {
    isAdmin,
    isBotAdmin
}) {
    if (m.isBaileys && m.fromMe) return true
    let chat = global.db.data.chats[m.chat]
    let sender = global.db.data.chats[m.sender]
    let isFoto = m.mtype
    let hapus = m.key.participant
    let bang = m.key.id
    if (chat.antiNsfwApi && isFoto) {
        if (isFoto === "imageMessage") {
            let quo = m.quoted ? m.quoted : m
    		let mime = (quo.msg || quo).mimetype || ''
    		let media = await quo.download?.()
  			let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
 			let link = await (isTele ? uploadImage : uploadFile)(media)
    		let apinya = await axios.get(`https://api.kyoukastore.my.id/api/other/tools/nsfw-detect?apikey=${global.apikyo}&url=${link}`)
    		console.log(link)
    		let result = await apinya.data
    		let isNsfwApi = result.whast
            if (result.whast === "is_nsfw") { 
            m.reply(`*Foto Bokep Terdeteksi*\n\nFoto bokep gw hapus`)
                return this.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: bang,
                        participant: hapus
                    }
                })     
            }
            console.log(isNsfwApi)
            return true
        } else if (isFoto === "stickerMessage") {
            let quo = m.quoted ? m.quoted : m
    		let mime = (quo.msg || quo).mimetype || ''
    		let media = await quo.download?.()
            let out = await webp2png(media).catch(_ => null) || Buffer.alloc(0)
            let base64Result = out.toString('base64');
            console.log(base64Result);
  			//let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime)
 			//let link = await (isTele ? uploadImage : uploadFile)(base64Result)
    		let apinya = await axios.get(`https://api.kyoukastore.my.id/api/other/tools/nsfw-detect?apikey=${global.apikyo}&url=${base64Result}`)
    		//console.log(link)
    		let result = await apinya.data
    		let isNsfwApi = result.whast
            if (result.whast === "is_nsfw") { 
            m.reply(`*Stiker Bokep Terdeteksi*\n\nStiker bokep gw hapus`)
                return this.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: bang,
                        participant: hapus
                    }
                })     
            }
            console.log(isNsfwApi)
            return true
        }
    }
    return true
}