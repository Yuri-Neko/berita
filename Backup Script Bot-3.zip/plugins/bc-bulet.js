let handler = async (m, { conn, text }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw '✳️ Replay video'
  let chats = Object.entries(conn.chats).filter(([_, chat]) => chat.isChats).map(v => v[0])
  conn.reply(m.chat, `✅ *Total:* ${chats.length} chats`, m)
  for (let id of chats) {
    await new Promise(resolve => setTimeout(resolve, 30000)); // Delay of 30 Second (30 Detik)
    await conn.relayMessage(id, { ptvMessage : m.quoted }, { messageId: m.id })
  }
  
  m.reply('✅ Done, Berhasil Broatcast Video Bulet')
}

handler.help = ['bcb']
handler.tags = ['owner']
handler.command = /^(broadcastbulet|bcb|bcbulet)$/i
handler.owner = true

export default handler
