import fetch from 'node-fetch';
import axios from 'axios';
import sharp from 'sharp';

async function fetchImage(url) {
  const response = await axios.get(url, { responseType: 'arraybuffer' });
  const imageBuffer = Buffer.from(response.data, 'binary');
  const image = await sharp(imageBuffer).png().toBuffer();
  return image;
}

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;
  let ftroli = {
    key: {
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      orderMessage: {
        itemCount: 2023,
        status: 404,
        surface: 404,
        message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`,
        orderTitle: '',
        thumbnail: await (await fetch('https://helper--startgrow.repl.co/buffer?url=https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
        sellerJid: '0@s.whatsapp.net'
      }
    }
  };

  if (!text) {
    m.reply("Tunggu sebentar, sedang memuat...");

try {
  let f = await fetch(`https://web.api-kyouka.my.id/api/nsfw/mirrordesu/latest?apikey=${apikey}`);
  let result = await f.json();
  let popular = result.result.popular;
  let latest = result.result.Latest;

  const latestItems = latest.map((item) => {
    const title = item.title;
    const imageUrl = item.imageUrl;
    const url = item.url;

    const chapters = item.chapters.map((chapter) => {
      const chapterNumber = chapter.chapterNumber;
      const timeAgo = chapter.timeAgo;

      return { chapterNumber, timeAgo };
    });

    return { title, imageUrl, url, chapters };
  });

  const combinedMessage = latestItems.map((item) => {
    const { title, imageUrl, url, chapters } = item;

    const chaptersString = chapters.map((chapter) => {
      return `*Chapter: ${chapter.chapterNumber}*\n*Time Ago: ${chapter.timeAgo}*`;
    }).join('\n');

    return `*Title*: ${title}\n*Image URL*: ${imageUrl}\n*URL*: ${url}\n${chaptersString}\n\n----------------------------------\n`;
  }).join('\n');

   
   const messages = result.result.Popular.map(item => {
        const title = item.title;
        const chapter = item.chapter;
        const rating = item.rating;
        const image = item.thumbnail;
        const link = item.url;

        const message = `
          Title: ${title}
          Chapter: ${chapter}
          Rating: ${rating}
          Thumbnail: ${image}
          Link: ${link}
        `;

        return message;
      });

      const combinedMessagee = messages.join('\n*----------------------------------*');
    
 await conn.reply(m.chat, '*Latest*\n\n' + combinedMessage, ftroli);
           conn.reply(m.chat, '*Popular*\n' + combinedMessagee, ftroli);
     } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat memuat doujin terbaru', m);
    }
  } else if (text.startsWith("https://mirrordesu.ink/komik/")) {
    const url = text.trim();

    m.reply("Tunggu sebentar, sedang mengambil detail...");

    try {
      let f = await fetch(`https://web.api-kyouka.my.id/api/nsfw/mirrordesu/detail?apikey=${apikey}&url=${encodeURIComponent(url)}`);
      let result = await f.json();

      const thumb = result.result.cover;
      const title = result.result.title;
      //const genres = result.result.genres.join(', ');
      const rating = result.result.rating;
      const status = result.result.status;
      const type = result.result.type;
      const released = result.result.released;
      const author = result.result.postedBy;
      const postedOn = result.result.postedOn;
      const updatedOn = result.result.updatedOn;
      const synopsis = result.result.sinopsis;
      const chapterList = result.result.chapterList.map(chapter => `${chapter.Chapter}: [Link](${chapter.Link})\n- ${chapter.Date}`).join('\n\n');

      const message = `
            *DETAIL DOUJIN*\n\n
        Title: ${title}
        Rating: ${rating}
        Status: ${status}
        Type: ${type}
        Released: ${released}
        Author: ${author}
        Posted On: ${postedOn}
        Updated On: ${updatedOn}
        Synopsis: ${synopsis}
        
        *CHAPTER LIST*
        ${chapterList}
      `;
       
        const messages = result.result.SeriesTerkait.map(item => {
        const title = item.Judul;
        const chapter = item.Chapter;
        const Ratting = item.Ratting;
        const image = item.Thumbnail;
        const link = item.Link;

        const message = `
          Title: ${title}
          Chapter: ${chapter}
          Ratting: ${Ratting}
          Thumbnail: ${image}
          Link: ${link}
        `;

        return message;
      });

      const combinedMessage = messages.join('\n*----------------------------------*');

      
      await conn.sendFile(m.chat, await fetchImage(thumb), 'img.jpg', message, ftroli);
        conn.reply(m.chat, '*SERIES TERKAIT*\n' + combinedMessage, ftroli);

      //conn.reply(m.chat, message, ftroli);
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat mengambil detail doujin', m);
    }
  } else {
    const query = text.trim();

    m.reply("Tunggu sebentar, sedang melakukan pencarian...");

    try {
      let f = await fetch(`https://web.api-kyouka.my.id/api/nsfw/mirrordesu/search?apikey=${apikey}&query=${encodeURIComponent(query)}`);
      let result = await f.json();

      const messages = result.result.map(item => {
        const title = item.title;
        const chapter = item.chapter;
        const rating = item.rating;
        const image = item.thumbnail;
        const link = item.url;

        const message = `
          Title: ${title}
          Chapter: ${chapter}
          Rating: ${rating}
          Thumbnail: ${image}
          Link: ${link}
        `;

        return message;
      });

      const combinedMessage = messages.join('\n*----------------------------------*');

      conn.reply(m.chat, '*HASIL PENCARIAN DOUJIN*\n' + combinedMessage, ftroli);
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat melakukan pencarian doujin', m);
    }
  }
};

handler.command = ['mirrordesu'];
handler.help = ['mirrordesu'];
handler.tags = ['main'];
handler.register = true;

export default handler;