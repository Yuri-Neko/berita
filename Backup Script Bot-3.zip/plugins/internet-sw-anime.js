import cheerio from 'cheerio';
import fetch from 'node-fetch';
import axios from 'axios';

let handler = async (m, { conn, args, usedPrefix, text, command }) => {
  await m.reply("Wait...");

  let resl1 = await animeVideo();

  let cap1 = `📝 *Title (v1):* ${resl1.title}`;

 // const botToken = 'YOUR_BOT_TOKEN'; // Ganti dengan token bot Telegram Anda
  //const chatId = 'YOUR_CHAT_ID'; // Ganti dengan ID chat atau username target Anda
     const botToken = '6258272191:AAHBNSQWAm8bVQf9FOYDVHwu5w16Yz0yN_Q';
      const chatId = '@StoryFypTikTok';
  const apiUrl = `https://api.telegram.org/bot${botToken}/sendVideo`;

  await axios.post(apiUrl, {
    chat_id: chatId,
    video: resl1.source,
    caption: cap1
  });

  await conn.sendFile(m.chat, resl1.source, '', cap1, m);
};

handler.help = ['storyanime'];
handler.tags = ['internet', 'anime'];
handler.command = /^storyanime$/i;

export default handler;

async function animeVideo() {
  const url = 'https://shortstatusvideos.com/anime-video-status-download/';
  const response = await fetch(url);
  const html = await response.text();
  const $ = cheerio.load(html);

  const videos = [];

  $('a.mks_button.mks_button_small.squared').each((index, element) => {
    const href = $(element).attr('href');
    const title = $(element).closest('p').prevAll('p').find('strong').text();
    videos.push({
      title,
      source: href
    });
  });

  const randomIndex = Math.floor(Math.random() * videos.length);
  const randomVideo = videos[randomIndex];

  return randomVideo;
}
