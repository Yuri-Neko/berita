/*import fetch from 'node-fetch'
let handler = async (m, { conn }) => {
  const pesan = await conn.sendMessage(m.chat, { text: '[□□□□□□□□□□] 0%' }, { quoted: m });
  const animation = [
    '[□□□□□□□□□□] 0%',
    '[■□□□□□□□□□] 10%',
    '[■■□□□□□□□□] 20%',
    '[■■■□□□□□□□] 30%',
    '[■■■■□□□□□□] 40%',
    '[■■■■■□□□□□] 50%',
    '[■■■■■■□□□□] 60%',
    '[■■■■■■■□□□] 70%',
    '[■■■■■■■■□□] 80%',
    '[■■■■■■■■■□] 90%',
    '[■■■■■■■■■■] 100%',
  ];

  let progressAnim = 0;
        let res = await fetch('https://api.waifu.pics/sfw/waifu');
        if (!res.ok) throw await res.text();
        let json = await res.json();
  function animate() {
    let saveAnim = animation[progressAnim % animation.length];

    conn.relayMessage(m.chat, {
      protocolMessage: {
        key: pesan.key,
        type: 14,
        editedMessage: {
          conversation: saveAnim
        }
      }
    }, {});

    progressAnim++;

    if (progressAnim <= 10) {
      setTimeout(animate, 500); // Timeout set to 500 milliseconds (0.5 seconds)
    } else {
      setTimeout(async () => {
        // Kirim hasil
        conn.relayMessage(m.chat, {
          protocolMessage: {
            key: pesan.key,
            type: 14,
            editedMessage: {
              conversation: "Media Sedang di kirim"
            }
          }
        }, {});

        // Kirim gambar waifu
        conn.sendFile(m.chat, json.url, 'img.jpg', 'Nih waifu mu', m);
      }, 500); // Timeout set to 500 milliseconds (0.5 seconds)
    }
  }

  animate();
};

handler.help = ['b'];
handler.tags = ['main'];
handler.command = /^(b)$/i;

export default handler;*/
