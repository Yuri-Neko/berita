import uploadImage from '../lib/uploadImage.js'
import { sticker } from '../lib/sticker.js'
import fetch from 'node-fetch'
let handler = async (m, { conn, text, usedPrefix, command }) => {
    let [atas, bawah] = text.split`|`
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    if (!mime) throw `balas gambar dengan perintah\n\n${usedPrefix + command} <${atas ? atas : 'teks atas'}>|<${bawah ? bawah : 'teks bawah'}>`
    if (!/image\/(jpe?g|png)/.test(mime)) throw `_*Mime ${mime} tidak didukung!*_`
    let img = await q.download()
    let url = await uploadImage(img)
    let meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas ? atas : '')}/${encodeURIComponent(bawah ? bawah : '')}.png?background=${url}`
    let stiker = await sticker(false, meme, global.packname, global.author)
    //if (stiker) await conn.sendFile(m.chat, stiker, '', author, m, '', { asSticker: 1 })
    let ftroli = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'
    },
    message: {
    orderMessage: {
    itemCount : 999999,
    status: 404,
    surface : 404,
    message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`, 
    orderTitle: ``,
    thumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(), //Gambarnye
    sellerJid: '0@s.whatsapp.net' 
    }
    }
    }
    if (stiker) return await conn.sendFile(m.chat, stiker, 'sticker.webp', '', m, null, { quoted: ftroli, fileLength: "999999", contextInfo: {
          externalAdReply :{
          showAdAttribution: true,
          mediaUrl: 'https://telegra.ph/file/15b88fbc476d27b298686.jpg',
          mediaType: 1,
          title: '                Sudah jadi sticker nya 🐥\n       🐤STICKER BY : YOSHINO BOT WA', 
          thumbnail: await (await fetch(global.hoppai[Math.floor(Math.random() * global.hoppai.length)])).buffer(),
          renderLargerThumbnail: true,
          sourceUrl: 'https://chat.whatsapp.com/Gqh0DeHyphrES4izhvYnMP'
     }}
  })
}
handler.help = ['smeme <teks atas>|<teks bawah>']
handler.tags = ['sticker']
handler.command = /^(smeme)$/i

handler.limit = true

export default handler