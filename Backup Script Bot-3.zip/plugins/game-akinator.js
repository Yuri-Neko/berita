import { Aki } from 'aki-api'
import fetch from 'node-fetch'
import axios from 'axios'
import { getBuffer, parseResult, resize } from '../lib/tools.js'

let handler = async(m, {conn, args}) => {
		conn.akinator = conn.akinator ? conn.akinator : {}
		const shp = "•"
		//start akinator
		if(args[0] == 'start'){
		//	if(m.mtype != 'listResponseMessage' && m.mtype != "buttonsResponseMessage" && m.mtype != "templateButtonReplyMessage") return
			if(conn.akinator[m.sender]){
				let foundp = '*AKINATOR GAME*\n\n'
				foundp += 'Kamu sudah berada didalam permainan\n'
		        let footer = `${shp} Game Session.\n    > Untuk melihat sesi akinator anda\n`
		        footer += `${shp} Stop\n    >  Stop bermain Akinator`				
        		//await conn.sendButton(m.chat, foundp, footer, null, [['Game Session', '/akinator mysession'], ['Stop', '/akinator stop']], m)
                m.reply(foundp + '\n' + footer)
			}
			else {
				conn.akinator[m.sender] = new Aki({region: 'id', childMode: false, proxy: undefined})
				//await fs.writeFileSync(datapath, JSON.stringify(daki, null, 2))
				await conn.akinator[m.sender].start()
				//await fs.writeFileSync(datapath, JSON.stringify(daki2, null, 2))
				const sections = "Ketik di bawah ini untuk menjawab\n\n*Ya*  .akinator answer 0\n*Tidak*  .akinator answer 1\n*Tidak Tahu*  .akinator answer 2\n*Mungkin*  .akinator answer 3\n*Mungkin Tidak*  .akinator answer 4"
               // conn.sendFile(m.chat, "https://raw.githubusercontent.com/Zynfinity/Kanaeru-Bot/main/media/akinator.jpg", 'img.jpg', `${shp} Step : ${conn.akinator[m.sender].currentStep + 1}\n${shp} Progress : ${conn.akinator[m.sender].progress}\n${shp} Pertanyaan : ${conn.akinator[m.sender].question}\n\n${sections}`, m)
                await conn.sendMessage(m.chat, {
      text: `${shp} Step : ${conn.akinator[m.sender].currentStep + 1}\n${shp} Progress : ${conn.akinator[m.sender].progress}\n${shp} Pertanyaan : ${conn.akinator[m.sender].question}\n\n${sections}`,
      contextInfo: {
        externalAdReply: {
          title: "AKINATOR",
          body: 'APA ITU SENDLIST, ITU MITOS',
          thumbnailUrl: "https://telegra.ph/file/4b0047376a4cf2d8d8b3d.jpg",
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
			}
		}
		//stop akinator
		else if(args[0] == "stop"){
		//	if(m.mtype != 'listResponseMessage' && m.mtype != "buttonsResponseMessage" && mtype != "templateButtonReplyMessage") return
			if(conn.akinator[m.sender] == undefined) return m.reply('Kamu tidak berada didalam permainan!')
			let foundp = '*AKINATOR GAME*\n\n'
			foundp += 'Kamu sudah keluar dari Akinator>\n'
		    let footer = `${shp}  .akinator start.\n    > Untuk mulai bermain Akinator\n`			
           await conn.sendFile(m.chat, "https://raw.githubusercontent.com/Zynfinity/Kanaeru-Bot/main/media/akinator.jpg", 'img.jpg', `${foundp}\n${footer}`, m)
        	//await conn.sendButton(m.chat, foundp, footer, null, [['Start', '.akinator start']], m)
        	delete conn.akinator[m.sender]
        	//await fs.writeFileSync(datapath, JSON.stringify(daki, null, 2))
		}
		//show game session
		else if(args[0] == 'mysession', args[0] == 'sesi'){
			//if(m.mtype != 'listResponseMessage' && m.mtype != "buttonsResponseMessage" && mtype != "templateButtonReplyMessage") return
			if(conn.akinator[m.sender] == undefined) return m.reply('Kamu tidak berada didalam permainan!')
			const sections = "Ketik di bawah ini untuk menjawab\n\n*Ya*  .akinator answer 0\n*Tidak*  .akinator answer 1\n*Tidak Tahu*  .akinator answer 2\n*Mungkin*  .akinator answer 3\n*Mungkin Tidak*  .akinator answer 4"
           // conn.sendFile(m.chat, "https://raw.githubusercontent.com/Zynfinity/Kanaeru-Bot/main/media/akinator.jpg", 'img.jpg', `${shp} Step : ${conn.akinator[m.sender].currentStep + 1}\n${shp} Progress : ${conn.akinator[m.sender].progress}\n${shp} Pertanyaan : ${conn.akinator[m.sender].question}\n\n${sections}`, m)
           await conn.sendMessage(m.chat, {
      text: `${shp} Step : ${conn.akinator[m.sender].currentStep + 1}\n${shp} Progress : ${conn.akinator[m.sender].progress}\n${shp} Pertanyaan : ${conn.akinator[m.sender].question}\n\n${sections}`,
      contextInfo: {
        externalAdReply: {
          title: "AKINATOR",
          body: 'APA ITU SENDLIST, ITU MITOS',
          thumbnailUrl: "https://telegra.ph/file/4b0047376a4cf2d8d8b3d.jpg",
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
            
		}
		//answer section
		else if(args[0] == 'answer', args[0] == 'ans'){
		//	if(m.mtype !== 'listResponseMessage') return
			if(conn.akinator[m.sender] == undefined) return m.reply('Kamu tidak berada didalam permainan!')
			await conn.akinator[m.sender].step(args[1])
		//if progress > 80 && answers length == 1 ? win
			if (conn.akinator[m.sender].progress >= 80 || conn.akinator[m.sender].currentStep >= 78) {
      			await conn.akinator[m.sender].win();
      			if(conn.akinator[m.sender].answers.length == 1){
      			let urlres = conn.akinator[m.sender].answers[0].absolute_picture_path
      				try{
	      				await conn.sendFile(m.chat, await parseResult('AKINATOR GAME RESULT', conn.akinator[m.sender].answers[0], {delete: ['absolute_picture_path', 'picture_path', 'pseudo', 'nsfw']}), 'Ketik .akinator start memulai kembali', await getBuffer(urlres), m)
	      			}catch{
	      				conn.sendFile(m.chat, await getBuffer(urlres), null, await parseResult('AKINATOR GAME RESULT', conn.akinator[m.sender].answers[0], {delete: ['picture_path', 'pseudo', 'nsfw']}), m)
	      			}
	      			return delete conn.akinator[m.sender]
      			}
    		}
            const sections = "Ketik di bawah ini untuk menjawab\n\n*Ya*  .akinator answer 0\n*Tidak*  .akinator answer 1\n*Tidak Tahu*  .akinator answer 2\n*Mungkin*  .akinator answer 3\n*Mungkin Tidak*  .akinator answer 4"
               // conn.sendFile(m.chat, "https://raw.githubusercontent.com/Zynfinity/Kanaeru-Bot/main/media/akinator.jpg", 'img.jpg', `${shp} Step : ${conn.akinator[m.sender].currentStep + 1}\n${shp} Progress : ${conn.akinator[m.sender].progress}\n${shp} Pertanyaan : ${conn.akinator[m.sender].question}\n\n${sections}`, m)
            await conn.sendMessage(m.chat, {
      text: `${shp} Step : ${conn.akinator[m.sender].currentStep + 1}\n${shp} Progress : ${conn.akinator[m.sender].progress}\n${shp} Pertanyaan : ${conn.akinator[m.sender].question}\n\n${sections}`,
      contextInfo: {
        externalAdReply: {
          title: "AKINATOR",
          body: 'APA ITU SENDLIST, ITU MITOS',
          thumbnailUrl: "https://telegra.ph/file/4b0047376a4cf2d8d8b3d.jpg",
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
			//await fs.writeFileSync(datapath, JSON.stringify(daki, null, 2))
		}
		else {
			const img = 'https://raw.githubusercontent.com/Zynfinity/Kanaeru-Bot/main/media/akinator.jpg'
			let akin = `*AKINATOR GAME*\n\n`
			akin += 'Pikirkan seorang karakter fiksi atau nyata.\nBot akan mencoba untuk menebaknya'
			let footer = `${shp} .akinator start.\n    > Untuk mulai bermain Akinator\n`
			footer += `${shp} .akinator stop.\n    > Untuk mulai bermain Akinator\n`
			footer += `${shp} .akinator mysession.\n    > Untuk melihat sesi Akinator kamu\n`
            conn.sendFile(m.chat, img, 'img.jpg', `${akin}\n\n${footer}`, m)
		}
}
handler.help = ['akinator']
handler.tags = ['game']
handler.command = ['akinator','aki']
export default handler