import fetch from 'node-fetch'

let handler = m => m
handler.all = async function (m) {
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? this.user.jid : m.sender
    let pp = await this.profilePictureUrl(who, 'image').catch(_ => 'https://i.imgur.com/whjlJSf.jpg')
    
    // Balasan tautan WhatsApp
    global.rpl = { contextInfo: { externalAdReply: { mediaUrl: dygp, mediaType: 'VIDEO', description: 'Dukung grup', title: packname, body: 'grup dukungan', thumbnailUrl: pp, sourceUrl: dygp }}}
    
    // Balasan tautan PayPal
    global.rpyp = { contextInfo: { externalAdReply: { mediaUrl: fgpyp, mediaType: 'VIDEO', description: 'Donasi', title: 'PayPal', body: 'bantu menjaga bot tetap aktif', thumbnailUrl: pp, sourceUrl: fgpyp }}}
    
    // Balasan tautan YouTube
    global.rpyt = { contextInfo: { externalAdReply: { showAdAttribution: true, mediaUrl: fgyt, mediaType: 'VIDEO', description: 'Subscribe: ' + fgyt, title: 'FG YouTube', body: 'pelajari cara membuat bot Anda sendiri', thumbnailUrl: pp, sourceUrl: fgyt }}}
}

export default handler
