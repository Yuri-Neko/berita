import fs from 'fs'
import fetch from 'node-fetch'
import path, { join } from 'path'
import {
  readdirSync,
  statSync,
  unlinkSync,
  existsSync,
  readFileSync,
  watch
} from 'fs'
const { upload } = (await import('../lib/upload-to-anonfiles.js')).default
let handler = async (m, { conn, args, __dirname }) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''

    if (/image\/jpeg|video\/mp4|application\/pdf/.test(mime)) { // Menggunakan tipe MIME yang telah disebutkan
        await m.reply(wait)
        const file = join(__dirname, '../images/upload' + mime.replace(/.*\//, '.'))

        let media = await q.download()
        await fs.writeFileSync(file, media)
        
        let ous = await upload(file)
        let output = Object.entries(ous.data.file.url).map(([key, value]) => `  ○ *${key.toUpperCase()}:* ${value}`).join('\n')
        await m.reply(output)

        unlinkSync(file)
    } else throw 'Unsupported media type'
}
handler.help = ["uploadanonfiles"]
handler.tags = ["tools"]
handler.command = ["upanonfiles","upanon","uploadanonfiles"]
export default handler