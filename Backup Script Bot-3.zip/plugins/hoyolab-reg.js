import axios from 'axios'
let handler = async function (m, { conn, text, usedPrefix, command }) {
  let user = global.db.data.users[m.sender];
  let name2 = conn.getName(m.sender);
  if (!text) throw '✳️ Masukan Token Hoyolab\n Exaple Feature .regtoken ltoken=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx; ltuid=xxxxxxxxx;*\n Gey Your ltoken & ltuid \nhttps://act.hoyolab.com/bbs/event/signin/hkrpg/index.html?act_id=e202303301540311&hyl_auth_required=true&hyl_presentation_style=fullscreen&utm_source=hoyolab&utm_medium=tools&utm_campaign=checkin&utm_id=6&lang=en-us&bbs_theme=dark&bbs_theme_device=1\n';
user.ltoken = text.trim();  
user.reghoyo = true
 
m.reply(`
┌─「 *SUCCES* 」─
▢ Note : Jika Token Salah Maka Tidak Dapat Claim Reward Hoyolab
└──────────────`)
}

handler.help = ['regtoken'].map(v => v + ' <ltoken & ltuid>');
handler.tags = ['hoyolab'];
handler.command = ['regtoken'];
handler.private = true 
export default handler;