import fetch from "node-fetch"
let handler = async (m, { conn, isPrems }) => { 
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;
  let ftroli = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'
    },
    message: {
    orderMessage: {
    itemCount : 2023,
    status: 404,
    surface : 404,
    message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`, 
    orderTitle: ``,
    thumbnail: await (await fetch('https://demo.kyoukastore.my.id/buffer?url=https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(), //Gambarnye
    sellerJid: '0@s.whatsapp.net' 
    }
    }
    }
  try {
    // Fetch API
    let url = `https://api.kyoukastore.my.id/api/cekapikey?apikey=${apikey}`;
    let response = await fetch(url);
    let data = await response.json();
    if (data.result.limit) {
      await conn.reply(m.chat,"Silakan Cek Di Private Chat", ftroli)
        const email = data.result.email;
        const [username, domain] = email.split("@");
        const sensoredUsername = username[0] + "*".repeat(username.length - 1);
        const sensoredEmail = sensoredUsername + "@" + domain;
      await conn.reply(m.chat, `Your Profile Api\n*- Username:* ${data.result.username}\n*- Email:* ${sensoredEmail}\n*- Limit:* ${data.result.limit}\n*APIKEY CEK DI PRIVATE CHAT* `, ftroli);
        conn.reply(m.sender, data.apikey, ftroli);
    } else {
      throw '⚠️ Gagal memverifikasi API key';
    }
  } catch (error) {
    throw '⚠️ Gagal melakukan cek akun';
  }
};

handler.help = ['account'];
handler.tags = ['econ'];
handler.command = ['account'];
handler.register = true

export default handler;
