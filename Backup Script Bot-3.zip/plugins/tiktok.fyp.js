import fetch from 'node-fetch'
import axios from 'axios'
let handler = async (m, {conn, text}) => { 
let user = global.db.data.users[m.sender];
  let apikey = user.apis;
       let usernam = ["i.love.anime.xxx","ota_576","arnosh_masamune","shiro_wangy","theboys27_","anaimiya","pluralisme._","nontylive09","greyrat74","ocitoc1t","shinq4r","motivasibinsik","tiktoker_kii","ssukasuka12","aa8070857","aguskoplingg","nga.jerit","kutulisi","lucifer99888","maa._0ne","shiita666","geibdkt","glowofthelake","yoiki_mastung","r666stnc","666mawarhitam666","wahyukiku","sm__23.t","mikorhy","tuanbaocosplay","clyfuu","alwasyquran","_rzlmh","liuliubaobei518","sesad_girl03","musicvibesssssss","re____otak","waifueveryday","ly_chn","magenta6262"]
let ftroli = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'
    },
    message: {
    orderMessage: {
    itemCount : 2023,
    status: 404,
    surface : 404,
    message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`, 
    orderTitle: ``,
    thumbnail: await (await fetch('https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(), //Gambarnye
    sellerJid: '0@s.whatsapp.net' 
    }
    }
    }
m.reply("tunggu yah agak lama loading nya...ada cloudplare")
    try {
    for (let i = 0; i < 5; i++) {
        
    let username = usernam[Math.floor(Math.random() * usernam.length)]
    let f = await fetch(`http://demo.kyoukastore.my.id/tiktok/stalk?user=${username}`)
    let x = await f.json()
    let kann = x.result.videos
    let hasil = kann[Math.floor(Math.random() * kann.length)]
    //conn.sendButton(m.chat, `Source : ${x.images[0].source}\nUpload : ${x.images[0].uploaded_at}`, wm, x.images[0].url, [['NEXT', '/kitagawamarin']], m) 
    let tet = `Post : ${hasil.video.post}\n${hasil.video.likes} Like\n${hasil.video.comments} Komen\n${hasil.video.share} Di Bagikan\nDeskripsi Video : ${hasil.video.description}\nUsername : ${hasil.author.username}\n${x.result.followers} Followers\n${x.result.following} Following\n Deskripsi Profile: ${x.result.description}\nUrl: ${hasil.video.url2}
`
 const botToken = '6258272191:AAHBNSQWAm8bVQf9FOYDVHwu5w16Yz0yN_Q';
      const chatId = '@StoryFypTikTok';
      const apiUrl = `https://api.telegram.org/bot${botToken}/sendVideo`;
      //await axios.post(apiUrl, {
        //chat_id: chatId,
        //video: hasil.video.url,
        //caption: tet
      //});
        conn.sendFile(m.chat, hasil.video.url, 'tiktok.mp4', tet, ftroli)
     await new Promise(resolve => setTimeout(resolve, 10000)); //30 detik
    }
  } catch (error) {
    console.log(error);
    m.reply(`Terjadi kesalahan saat mengambil result video.`);
  }
};
handler.command = ['ttfyp','fyp']
handler.help = ['ttfyp']
handler.tags = ['main']

export default handler