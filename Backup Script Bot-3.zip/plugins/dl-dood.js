import axios from 'axios';
import fetch from 'node-fetch';

const handler = async (m, { text, conn }) => {
  if (!text) throw 'apa cuba link nya mana jing  ';
  try {
    const apiUrl = `https://web.api-kyouka.my.id/api/other/doodstream?apikey=kyouka_admin&url=${encodeURIComponent(text)}`;
    let response = await fetch(apiUrl);
    let wtf = await response.json();
    if (/MB/.test(wtf.size) && parseInt(wtf.size) > 100) throw 'kegedean antum mana tahan nonton';
    let axiosConfig = {
      responseType: 'arraybuffer',
      headers: {
        referer: wtf.referer//'https://dood.com/'
      }
    };
    let { data: buffer } = await axios.get(wtf.direct_link, axiosConfig);
    await conn.sendMessage(m.chat, { video: buffer, caption: `${wtf.title}\n\n*Info Video*\n- Durasi: ${wtf.duration}\n- Ukuran: ${wtf.size}\n- Tanggal: ${wtf.date}` }, { quoted: m });
  } catch (e) {
    m.reply("mana gada hoax hoax");
  }
};

handler.help = handler.command = ['dood'];
handler.tags = ['nsfw'];
handler.group = false

export default handler;
