import { sticker } from '../lib/sticker.js'
import fs from 'fs'
import path from 'path'
import fetch from 'node-fetch'
global.sig = "https://instagram.com/admin_kyouka"
let handler = async (m, { conn, command }) => {
global.fkontak = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': wm, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${wm},;;;\nFN:${wm},\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`, 'jpegThumbnail': fs.readFileSync('./thumbnail.jpg'), thumbnail: fs.readFileSync('./thumbnail.jpg'),sendEphemeral: true}}}

//m.reply(`Wait ${command} sedang proses🐦`)
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let pp = await conn.profilePictureUrl(who).catch(_ => hwaifu.getRandom())
let name = await conn.getName(who)

//let stiker = await sticker(null, global.API(`https://telegra.ph/file/d34b2ab2cb233c749776c.png`), global.packname, global.author)
 /*conn.sendFile(m.chat, stiker, 'sticker.webp', '', m, null, { fileLength: 100, contextInfo: {
          externalAdReply :{
          showAdAttribution: true,
    mediaUrl: sig,
    mediaType: 2,
    description: 'DEV KYOUKA HASHIBA', 
    title: `${command} Sedang Di Proses`,
    body: botdate,
    thumbnail: await(await fetch(pp)).buffer(),
    sourceUrl: sig
     }}
  })*/

let sound = [
 "aha.mp3",
  "antabaka.mp3",
  "ara-ara.mp3",
  "arigatou.mp3",
  "baka-kawai.mp3",
  "baka.mp3",
  "beep.mp3",
  "cokoton.mp3",
  "conglaturation.mp3",
  "dattebayo.mp3",
  "deppresion.mp3",
  "fuckyou.mp3",
  "goku.mp3",
  "gomenasai.mp3",
  "good-job.mp3",
  "hunggry.mp3",
  "iyyah.mp3",
  "jutsu.mp3",
  "kawaii.mp3",
  "kimoe.mp3",
  "kirang.mp3",
  "kyaa.mp3",
  "mati.mp3",
  "movment.mp3",
  "nani.mp3",
  "nee-san.mp3",
  "nyaa.mp3",
  "nyaaa.mp3",
  "ohohoho.mp3",
  "okawaicotto.mp3",
  "omaygod.mp3",
  "onii-chan.mp3",
  "onii-san.mp3",
  "owari-da.mp3",
  "rawr.mp3",
  "scared-animegirl.mp3",
  "senpai.mp3",
  "smash-punch.mp3",
  "sugoii.mp3",
  "tehepero.mp3",
  "teleport.mp3",
  "urusai.mp3",
  "yarre-yarre.mp3",
  "yooooooooooo.mp3",
  "yowaiimo-ori.mp3",
  "yowaimo.mp3",
  "zawarudo.mp3"
];

let randomIndex = Math.floor(Math.random() * sound.length);
let randomSound = sound[randomIndex];
  
let audio = `https://github.com/Yuri-Neko/SoundAnime-Api/raw/master/soundanime/${randomSound}`

await conn.sendFile(m.chat, audio, 'error.mp3', null, fkontak, true, {
type: 'audioMessage', 
ptt: false, seconds: 0,contextInfo: {
         externalAdReply: { showAdAttribution: true,
 mediaUrl: 'www.instagram.com/admin_kyouka',
    mediaType: 2, 
    description: 'www.instagram.com/admin_kyouka',
    title: "Now Playing...",
    body: wm,
    thumbnail: await (await fetch('https://i.top4top.io/p_2473iqt431.jpg')).buffer(),
    sourceUrl: 'www.instagram.com/admin_kyouka'
 	  }
     }
    })
}

handler.command = ['animesound']
handler.tags = ['sound']
handler.help = ['animesound']

export default handler 