/*import fetch from 'node-fetch'
let handler = async(m, { conn, usedPrefix, command }) => {
    let Servers = "play.fazorecraft.xyz:19132"
	let f = await fetch(`https://api.mcstatus.io/v2/status/bedrock/${Servers}`)
    let x = await f.json()
    
    let video = "https://telegra.ph/file/d0850c237ca054ae14749.mp4"
    let motdRaw = x.motd.clean
    let motdClean = motdRaw.split("\n")[0].trim();
    let caption = `*==== Status Servers ====*\n *===${motdClean}===*\n *- Player Online : ${x.players.online}/${x.players.max}*\n *-*`
   await conn.sendFile(m.chat, video, 'video.mp4', caption, m)
}
handler.help = ['servers']
handler.tags = ['img']
handler.command = ['servers', 'mcs']
handler.diamond = true

export default handler*/




import axios from 'axios';
import cheerio from 'cheerio';

export async function scrapeServerInfo(url) {
  try {
    const response = await axios.get(url);

    if (response.status === 200) {
      const html = response.data;
      const $ = cheerio.load(html);

      const serverInfo = {};

      const address = $('table tbody tr:nth-child(1) td:nth-child(2) strong').text().trim();
      const [ip, port] = address.split(':'); // Pisahkan IP dan port

      const hostname = $('table tbody tr:nth-child(2) td:nth-child(2) strong').text().trim();
      const status = $('table tbody tr:nth-child(3) td:nth-child(2) button').text().trim();
      const players = $('table tbody tr:nth-child(4) td:nth-child(2) strong').text().trim();
      const location = $('table tbody tr:nth-child(5) td:nth-child(2) a').text().trim();
      const version = $('table tbody tr:nth-child(6) td:nth-child(2) a').text().trim();
      const website = $('table tbody tr:nth-child(7) td:nth-child(2) a').text().trim();
      const registeredBy = $('table tbody tr:nth-child(8) td:nth-child(2)').text().trim();
      const registeredSince = $('table tbody tr:nth-child(9) td:nth-child(2)').text().trim();
      const lastUpdate = $('table tbody tr:nth-child(10) td:nth-child(2)').text().trim();
      const tags = $('table tbody tr:nth-child(11) td:nth-child(2) a').map((i, el) => $(el).text().trim()).get();

      serverInfo.ip = ip;
      serverInfo.port = port;
      serverInfo.hostname = hostname;
      serverInfo.status = status;
      serverInfo.players = players;
      serverInfo.location = location;
      serverInfo.version = version;
      serverInfo.website = website;
      serverInfo.registeredBy = registeredBy;
      serverInfo.registeredSince = registeredSince;
      serverInfo.lastUpdate = lastUpdate;
      serverInfo.tags = tags;

      const videoUrl = $('div.row div.col-12 video source').attr('src');

      serverInfo.videoUrl = videoUrl;

      return serverInfo;
    }
  } catch (error) {
    console.error(error);
    return null;
  }
}

// Example usage
let handler = async (m, { conn, usedPrefix, command }) => {
  const serverUrl = 'https://minecraftpocket-servers.com/server/122503/';
  const serverInfo = await scrapeServerInfo(serverUrl);
  const id = serverUrl.match(/\/(\d+)\//)[1];

  if (serverInfo) {
    const tags = serverInfo.tags.join(', ');
    const caption = `*Status Servers*\n*${serverInfo.hostname}*\n *- Player Online: ${serverInfo.players}*\n *- Status: ${serverInfo.status}*\n *- IP: ${serverInfo.ip}*\n *- Port: ${serverInfo.port}*\n *- Locasi: ${serverInfo.location}*\n *- VersionMc ${serverInfo.version}*\n *- Tags: ${tags}*\n *- Owner Server: ${serverInfo.registeredBy}*`;
   // await conn.sendFile(m.chat, `https://minecraftpocket-servers.com/server/${id}/banners/banner-5.png`, 'video.png', caption, m);
     /* await conn.sendMessage(m.chat, {
      text: caption,
      contextInfo: {
        externalAdReply: {
          title: serverInfo.hostname,
          body: 'bodynya',
          thumbnailUrl: `https://minecraftpocket-servers.com/server/${id}/banners/banner-5.png`,
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });*/
      const media = await conn.sendMessage(m.chat, {
  video: {
    url: `https://minecraftpocket-servers.com/server/${id}/banner-122503-1682957330.mp4`,
  },
  gifPlayback: true,
  gifAttribution: ~~(Math.random() * 2),
  caption: caption,
  contextInfo: {
    externalAdReply: {
      title: serverInfo.hostname,
      body: 'bodynya',
      thumbnailUrl: `https://minecraftpocket-servers.com/server/${id}/banners/banner-5.png`,
      sourceUrl: "",
      mediaType: 1,
      renderLargerThumbnail: true
    }
  }
}, { quoted: m });
  } else {
    console.error('Failed to scrape server info');
  }
};

handler.help = ['servers'];
handler.tags = ['img'];
handler.command = ['servers', 'mcs'];
handler.diamond = true;

export default handler;
