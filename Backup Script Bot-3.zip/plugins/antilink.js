import fg from 'api-dylux';
import axios from 'axios';
import got from 'got';
import cheerio from 'cheerio';
import fetch from 'node-fetch';
let handler = m => m;


handler.before = async function (m) {
    let hapus = m.key.participant
    let bang = m.key.id
    const sender = '120363209132318160@' + '@g.us'
  if (m.text.includes("https://chat.whatsapp.com/")) {
    try {
      let hapus = m.key.participant;
      let pesan = m.key.id;
      conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: pesan, participant: hapus }});
    } catch (error) {
      return conn.sendMessage(m.chat, { delete: m.quoted.vM.key });
    }
  } else  if (m.text.match(/(?<!\S)https?:\/\/vt\.tiktok\.com\/[^\s]+/)) {
    let url = m.text.match(/(?<!\S)https?:\/\/vt\.tiktok\.com\/[^\s]+/)[0];
    let p = await downloadTikTokVideo(url);
    let ftrolitt = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'
    },
    message: {
    orderMessage: {
    itemCount : 999999,
    status: 404,
    surface : 404,
    message: `${p.datatu.username}`, 
    orderTitle: ``,
    thumbnail: await (await fetch(`${p.datatu.pp}`)).buffer(), //Gambarnye
    sellerJid: '0@s.whatsapp.net' 
    }
    }
    }
    let { key } = await conn.sendMessage(m.chat, { text: 'ʟᴏᴀᴅɪɴɢ...',  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Join To My Channel',
       }}})
    var loadingg = [".",". .",". . .",". . . .",".",". .",". . .",". . . .","media sedang di kirim"]
		for (let i = 0; i < loadingg.length; i++) {
		await conn.sendMessage(m.chat, {text: loadingg[i], edit: key });
		}
    if (!p) {
      conn.reply(m.chat, 'Maaf, terjadi kesalahan saat mengambil data TikTok', m);
      return;
    }
    let te = `
┌─⊷ TIKTOK
▢ *Name:* ${p.dataone.user.name || 'undefined'}
▢ *Username:* ${p.datatu.username || 'undefined'}
▢ *Deskripsi:* ${p.datatu.description || 'undefined'}
└───────────`;
      let tet = `
┌─⊷ TIKTOK DOWNLOADER
▢ By Yuika Bot WA
▢ *Name:* ${p.dataone.user.name || 'undefined'}
▢ Username: ${p.datatu.username || 'undefined'}
▢ Deskripsi: ${p.datatu.description || 'undefined'}
└───────────`;
     const botToken = '6258272191:AAHBNSQWAm8bVQf9FOYDVHwu5w16Yz0yN_Q';
      const chatId = '@StoryFypTikTok';
      const apiUrl = `https://api.telegram.org/bot${botToken}/sendVideo`;
    await conn.sendFile(m.chat, p.datatu.video2, 'tiktok.mp4', te, ftrolitt);
    await conn.sendFile(sender, p.datatu.video2, 'tiktok.mp4', te, ftrolitt);
    let notesuaraArray = [];
			for (let i = 0; i < 8; i++) {
  				  notesuaraArray.push(Math.floor(Math.random() * 100) + 1);
			}
    let suara = await conn.sendMessage(m.chat, {audio: {url: p.dataone.audio.url}, ptt:true, waveform: notesuaraArray, mimetype: 'audio/mpeg', viewOnce : false, contextInfo: {
    externalAdReply: { showAdAttribution: true,
 	mediaUrl: '',
    mediaType: 2, 
    description: 'www.instagram.com/admin_kyouka',
    title: "Memutar Voice Note...",
    body: p.datatu.description,
    thumbnail: await (await fetch(p.dataone.thumbnail)).buffer(),
    sourceUrl: 'www.instagram.com/admin_kyouka'
 	  }
     }} )
    await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: bang,
                    participant: hapus
                }
            })
     await conn.sendMessage(m.chat, {text: `Done`, contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Done',
       }} , edit: key });
  } else if (m.text.match(/(?<!\S)https?:\/\/(www\.)?tiktok\.com\/[^\s]+/)) {
    let url = m.text.match(/(?<!\S)https?:\/\/(www\.)?tiktok\.com\/[^\s]+/)[0];
    let p = await downloadTikTokVideo(url);
    let ftrolitt = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'
    },
    message: {
    orderMessage: {
    itemCount : 999999,
    status: 404,
    surface : 404,
    message: `${p.datatu.username}`, 
    orderTitle: ``,
    thumbnail: await (await fetch(`${p.datatu.pp}`)).buffer(), //Gambarnye
    sellerJid: '0@s.whatsapp.net' 
    }
    }
    }
    let { key } = await conn.sendMessage(m.chat, { text: 'ʟᴏᴀᴅɪɴɢ...',  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Join To My Channel',
       }}})
    var loadingg = [".",". .",". . .",". . . .",".",". .",". . .",". . . .","media sedang di kirim"]
		for (let i = 0; i < loadingg.length; i++) {
		await conn.sendMessage(m.chat, {text: loadingg[i], edit: key });
		}
    if (!p) {
      conn.reply(m.chat, 'Maaf, terjadi kesalahan saat mengambil data TikTok', m);
      return;
    }
    let te = `
┌─⊷ TIKTOK
▢ *Name:* ${p.dataone.user.name || 'undefined'}
▢ *Username:* ${p.datatu.username || 'undefined'}
▢ *Deskripsi:* ${p.datatu.description || 'undefined'}
└───────────`;
      let tet = `
┌─⊷ TIKTOK DOWNLOADER
▢ By Yuika Bot WA
▢ *Name:* ${p.dataone.user.name || 'undefined'}
▢ Username: ${p.datatu.username || 'undefined'}
▢ Deskripsi: ${p.datatu.description || 'undefined'}
└───────────`;
     const botToken = '6258272191:AAHBNSQWAm8bVQf9FOYDVHwu5w16Yz0yN_Q';
      const chatId = '@StoryFypTikTok';
      const apiUrl = `https://api.telegram.org/bot${botToken}/sendVideo`;
    await conn.sendFile(m.chat, p.datatu.video2, 'tiktok.mp4', te, ftrolitt);
    await conn.sendFile(sender, p.datatu.video2, 'tiktok.mp4', te, ftrolitt);
    let notesuaraArray = [];
			for (let i = 0; i < 8; i++) {
  				  notesuaraArray.push(Math.floor(Math.random() * 100) + 1);
			}
    let suara = await conn.sendMessage(m.chat, {audio: {url: p.dataone.audio.url}, ptt:true, waveform: notesuaraArray, mimetype: 'audio/mpeg', viewOnce : false, contextInfo: {
    externalAdReply: { showAdAttribution: true,
 	mediaUrl: '',
    mediaType: 2, 
    description: 'www.instagram.com/admin_kyouka',
    title: "Memutar Voice Note...",
    body: p.datatu.description,
    thumbnail: await (await fetch(p.dataone.thumbnail)).buffer(),
    sourceUrl: 'www.instagram.com/admin_kyouka'
 	  }
     }} )
    await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: bang,
                    participant: hapus
                }
            })
     await conn.sendMessage(m.chat, {text: `Done`, contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Done',
       }} , edit: key });
  } else if (m.text.match(/(?<!\S)https?:\/\/v\.douyin\.com\/[^\s]+/)) {
    let url = m.text.match(/(?<!\S)https?:\/\/v\.douyin\.com\/[^\s]+/)[0];
    let p = await DouyinDL(url)
    let { key } = await conn.sendMessage(m.chat, { text: 'ʟᴏᴀᴅɪɴɢ...',  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Join To My Channel',
       }}})
let tet = `
┌─⊷ DOUYIN DOWNLOADER
▢ By Silver Wolf Bot WA
▢ Nama: ${p.title || 'undefined'}
▢ Durasi: ${p.durasi || 'undefined'}
▢ Size: ${p.media_download[1].formattedSize || 'undefined'}
└───────────`;
      
      	var loadingg = [".",". .",". . .",". . . .",".",". .",". . .",". . . .","media sedang di kirim"]
		for (let i = 0; i < loadingg.length; i++) {
		await conn.sendMessage(m.chat, {text: loadingg[i], edit: key });
		}
await conn.sendFile(m.chat, p.media_download[1].url, 'douyin.mp4', tet, m);
      await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: bang,
                    participant: hapus
                }
            })
      await conn.sendMessage(m.chat, {text: `Done`, contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Done',
       }} , edit: key });
  }  else if (m.text.match(/(?<!\S)https?:\/\/sck\.io\/p\/[^\s]+/)) {
    let url = m.text.match(/(?<!\S)https?:\/\/sck\.io\/p\/[^\s]+/)[0];
    let { key } = await conn.sendMessage(m.chat, { text: 'ʟᴏᴀᴅɪɴɢ...',  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Join To My Channel',
       }}})
    var loadingg = [".",". .",". . .",". . . .",".",". .",". . .",". . . .","media sedang di kirim"]
		for (let i = 0; i < loadingg.length; i++) {
		await conn.sendMessage(m.chat, {text: loadingg[i], edit: key });
		}
    let res = await SnackVideo(url);
    await m.reply('Sedang diproses...');
    await conn.sendFile(m.chat, res, 'snackvideo.mp4', 'Done', m);
    await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: bang,
                    participant: hapus
                }
            })
     await conn.sendMessage(m.chat, {text: `Done`, contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Done',
       }} , edit: key });
  } else if (m.text.match(/(?<!\S)https?:\/\/s\.snackvideo\.com\/p\/[^\s]+/)) {
    let url = m.text.match(/(?<!\S)https?:\/\/s\.snackvideo\.com\/p\/[^\s]+/)[0];
    let res = await SnackVideo(url);
    let { key } = await conn.sendMessage(m.chat, { text: 'ʟᴏᴀᴅɪɴɢ...',  contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Join To My Channel',
       }}})
    var loadingg = [".",". .",". . .",". . . .",".",". .",". . .",". . . .","media sedang di kirim"]
		for (let i = 0; i < loadingg.length; i++) {
		await conn.sendMessage(m.chat, {text: loadingg[i], edit: key });
		}
    await conn.sendFile(m.chat, res, 'snackvideo.mp4', 'Done', m);
	await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: bang,
                    participant: hapus
                }
            })
     await conn.sendMessage(m.chat, {text: `Done`, contextInfo: { forwardingScore: 999, isForwarded:true , forwardedNewsletterMessageInfo: {
           newsletterJid: '120363144038483540' + '@newsletter',
           serverMessageId: '120363144038483540' + '@newsletter',
           newsletterName: 'Done',
       }} , edit: key });
  } else if (m.text.match(/(?<!\S)https?:\/\/(www\.)?facebook\.com\/[^\s]+/i) || m.text.match(/(?<!\S)https?:\/\/fb\.watch\/[^\s]+/i)) {
    let url = m.text.match(/(?<!\S)https?:\/\/(www\.)?facebook\.com\/[^\s]+/i) || m.text.match(/(?<!\S)https?:\/\/fb\.watch\/[^\s]+/i)[0];
    let result = await fg.fbdl(url);
    let tex = `
┌─⊷ *FBDL*
▢ *Judul:* ${result.title}
└───────────`;
    conn.sendFile(m.chat, result.videoUrl, 'fb.mp4', tex, m);
    m.react('👌');
  } else if (m.text.match(/(?<!\S)https?:\/\/www\.instagram\.com\/[^\s]+/i)) {
    let url = m.text.match(/(?<!\S)https?:\/\/www\.instagram\.com\/[^\s]+/i)[0];
    try {
        let metadata = await fetchInstagramMeta(url)
        await snapsave(url).then(async p => {
  if (p.status && p.data && Array.isArray(p.data)) {
    for (let ai of p.data) {
      let ftroli = {
        key: {
          remoteJid: 'status@broadcast',
          participant: '0@s.whatsapp.net'
        },
        message: {
          orderMessage: {
            itemCount: 999999,
            status: 404,
            surface: 404,
            message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`,
            orderTitle: '',
            thumbnail: (await fetch(ai.thumbnail)).buffer(), // Ambil thumbnail dan ubah ke buffer
            sellerJid: '0@s.whatsapp.net'
          }
        }
      };
      conn.sendFile(m.chat, ai.url, 'ig.mp4', `${metadata}`, m);
    }
  } else {
    conn.reply(m.chat, 'error: tidak dapat mengirim media silakan coba lagi beberapa menit kemudian', m);
  }
});

        
    } catch (error) {
      conn.reply(m.chat, 'Maaf, terjadi kesalahan saat mengambil data', m);
    }
  }
};

export default handler;

async function DouyinDL(url) {
  const PAYLOAD = { url };
  const BASE_URL = 'https://snapdouyin.app/';
const HEADERS = {
  'Access-Control-Allow-Origin': 'https://snapdouyin.app',
  'Access-Control-Allow-Headers': 'Authorization, X-WP-Nonce, Content-Disposition, Content-MD5, Content-Type',
  'Content-Type': 'application/json; charset=UTF-8',
};

  try {
    const response = await axios.post(`${BASE_URL}wp-json/aio-dl/video-data/`, PAYLOAD, { headers: HEADERS });

    if (response.status === 200) {
      const data = response.data;
      const title = data.title;
      const thumb = data.thumbnail;
      const durasi = data.duration;
      const media_download = data.medias;
      return { title, thumb, durasi, media_download };
    }
  } catch (error) {
    console.error('Error fetching data:', error.message);
    return null;
  }
}

async function SnackVideo(url) {
    const baseUrl = 'https://getsnackvideo.com/id';
    const postUrl = 'https://getsnackvideo.com/results';
    
    const payload = {
        'ic-request': 'true',
        'id': url,
        'locale': 'id',
        'ic-element-id': 'main_page_form',
        'ic-id': '1',
        'ic-target-id': 'active_container',
        'ic-trigger-id': 'main_page_form',
        'ic-current-url': '/id',
        'ic-select-from-response': '#id1',
        '_method': 'POST'
    };
    const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        'Referer': baseUrl,
    };
    try {
        const response = await axios.post(postUrl, payload, { headers });
        const html = response.data;
        const $ = cheerio.load(html);
        const downloadLink = $('.download_link.without_watermark').attr('href');
        return downloadLink; 
    } catch (error) {
        console.error('Error scraping:', error);
        return null;
    }
}

async function fetchInstagramMeta(url) {
  try {
    const response = await axios.get(url);
    const html = response.data;
    const $ = cheerio.load(html);

    // Extract the meta description
    const metaDescription = $('meta[name="description"]').attr('content');
    
    return metaDescription;
  } catch (error) {
    console.error('Error fetching Instagram reel page:', error);
    throw error; // rethrow the error to handle it outside the function
  }
}


async function snapsave(url) {
  return new Promise(async (resolve) => {
    try {
      if (!url.match(/(?:https?:\/\/(web\.|www\.|m\.)?(facebook|fb)\.(com|watch)\S+)?$/) && !url.match(/(https|http):\/\/www.instagram.com\/(p|reel|tv|stories)/gi)) {
        return resolve({ developer: '@Alia Uhuy', status: false, msg: `Link Url not valid` });
      }

      function decodeSnapApp(args) {
        let [h, u, n, t, e, r] = args;

        function decode(d, e, f) {
          const g = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/'.split('');
          let h = g.slice(0, e);
          let i = g.slice(0, f);
          let j = d.split('').reverse().reduce(function (a, b, c) {
            if (h.indexOf(b) !== -1)
              return a += h.indexOf(b) * (Math.pow(e, c));
          }, 0);
          let k = '';
          while (j > 0) {
            k = i[j % f] + k;
            j = (j - (j % f)) / f;
          }
          return k || '0';
        }

        r = '';
        for (let i = 0, len = h.length; i < len; i++) {
          let s = '';
          while (h[i] !== n[e]) {
            s += h[i];
            i++;
          }
          for (let j = 0; j < n.length; j++)
            s = s.replace(new RegExp(n[j], "g"), j.toString());
          r += String.fromCharCode(decode(s, e, 10) - t);
        }
        return decodeURIComponent(encodeURIComponent(r));
      }

      function getEncodedSnapApp(data) {
        return data.split('decodeURIComponent(escape(r))}(')[1]
          .split('))')[0]
          .split(',')
          .map(v => v.replace(/"/g, '').trim());
      }

      function getDecodedSnapSave(data) {
        return data.split('getElementById("download-section").innerHTML = "')[1]
          .split('"; document.getElementById("inputData").remove(); ')[0]
          .replace(/\\(\\)?/g, '');
      }

      function decryptSnapSave(data) {
        return getDecodedSnapSave(decodeSnapApp(getEncodedSnapApp(data)));
      }

      const html = await got.post('https://snapsave.app/action.php?lang=id', {
        headers: {
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
          'content-type': 'application/x-www-form-urlencoded',
          'origin': 'https://snapsave.app',
          'referer': 'https://snapsave.app/id',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36'
        },
        form: { url }
      }).text();

      const decode = decryptSnapSave(html);
      const $ = cheerio.load(decode);
      const results = [];

      if ($('table.table').length || $('article.media > figure').length) {
        const thumbnail = $('article.media > figure').find('img').attr('src');
        $('tbody > tr').each((_, el) => {
          const $el = $(el);
          const $td = $el.find('td');
          const resolution = $td.eq(0).text();
          let _url = $td.eq(2).find('a').attr('href') || $td.eq(2).find('button').attr('onclick');
          const shouldRender = /get_progressApi/ig.test(_url || '');

          if (shouldRender) {
            _url = /get_progressApi\('(.*?)'\)/.exec(_url || '')?.[1] || _url;
          }

          results.push({
            resolution,
            thumbnail,
            url: _url,
            shouldRender
          });
        });
      } else {
        $('div.download-items__thumb').each((_, tod) => {
          const thumbnail = $(tod).find('img').attr('src');
          $('div.download-items__btn').each((_, ol) => {
            let _url = $(ol).find('a').attr('href');

            if (!/https?:\/\//.test(_url || '')) {
              _url = `https://snapsave.app${_url}`;
            }

            results.push({
              thumbnail,
              url: _url
            });
          });
        });
      }

      if (!results.length) {
        return resolve({ developer: '@Alia Uhuy', status: false, msg: `Blank data` });
      }

      return resolve({ developer: '@Alia Uhuy', status: true, data: results });
    } catch (e) {
      return resolve({ developer: '@Alia Uhuy', status: false, msg: e.message });
    }
  });
}

function musically(URL) {
	return new Promise((resolve, reject) => {
		axios.get('https://musicaldown.com/id', {
			headers: {
				'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
			}
		}).then(res => {
			const $ = cheerio.load(res.data)
			const url_name = $("#link_url").attr("name")
			const token_name = $("#submit-form > div").find("div:nth-child(1) > input[type=hidden]:nth-child(2)").attr("name")
			const token_ = $("#submit-form > div").find("div:nth-child(1) > input[type=hidden]:nth-child(2)").attr("value")
			const verify = $("#submit-form > div").find("div:nth-child(1) > input[type=hidden]:nth-child(3)").attr("value")
			let data = {
				[`${url_name}`]: URL,
				[`${token_name}`]: token_,
				verify: verify
			}
			axios.request({
				url: 'https://musicaldown.com/id/download',
				method: 'post',
				data: new URLSearchParams(Object.entries(data)),
				headers: {
					'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
					'cookie': res.headers["set-cookie"]
				}
			}).then(respon => {
				const ch = cheerio.load(respon.data)

				if (!ch('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l4.center-align > div > div > img').attr('src')) {

					let hasil = []
					ch('body > div.welcome.section > div > div:nth-child(3) > div > div.row > div').each(function (a, b) {
						hasil.push({
							url: ch(b).find('img').attr('src'),
							url_download: ch(b).find('a').attr('href')
						})
					})

					let result = {
						audio: ch('body > div.welcome.section > div > div:nth-child(3) > div > a.btn.waves-effect.waves-light.orange.download').attr('href'),
						photo: hasil
					}
					if (!result.photo[0]) {
						resolve()
					} else {
						resolve(result)
					}

				} else {

					axios.request({
						url: 'https://musicaldown.com/id/mp3',
						method: 'post',
						headers: {
							'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
							'cookie': res.headers["set-cookie"]
						}
					}).then(resaudio => {
						const hc = cheerio.load(resaudio.data)
						const result = {
							pp: ch('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l4.center-align > div > div > img').attr('src'),
							username: ch('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l4.center-align > div > h2:nth-child(2) > b').text(),
							description: ch('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l4.center-align > div > h2:nth-child(3)').text(),
							video: ch('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l8 > a:nth-child(3)').attr('href'),
							video2: ch('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l8 > a:nth-child(5)').attr('href'),
							video_HD: ch('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l8 > a:nth-child(7)').attr('href'),
							video_watermark: ch('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l8 > a:nth-child(9)').attr('href'),
							audio: hc('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l8 > a:nth-child(6)').attr('href'),
							audio_Download: hc('body > div.welcome.section > div > div:nth-child(3) > div.col.s12.l8 > a.btn.waves-effect.waves-light.orange.download').attr('href')
						}
						resolve(result)
					})
				}
			})
		})
	})
}

function extractTikTokId(url) {
  var firstFormatMatch = url.match(/\/video\/(\d+)/);
  var secondFormatMatch = url.match(/\/([A-Za-z0-9]+)\//);
  var tiktokId = (firstFormatMatch && firstFormatMatch[1]) || (secondFormatMatch && secondFormatMatch[1]);
  return tiktokId || null;
}

async function downloadTikTokVideo(url) {
  try {
    const tiktokId = extractTikTokId(url);
    if (!tiktokId) {
      console.log("Tidak dapat menemukan ID TikTok.");
      return null;
    }

    // Use await to wait for the resolution of the musically function
    const datatuu = await musically(url);

    if (!datatuu) {
      console.log("Tidak dapat menemukan data.");
      return null;
    }

    const apiUrl = `https://api.twitterpicker.com/tiktok/mediav2?id=${tiktokId}`;
    const response = await axios.get(apiUrl);

    return {
      dataone: response.data,
      datatu: datatuu
    };
  } catch (error) {
    console.error("Error:", error.message);
    return null;
  }
}
