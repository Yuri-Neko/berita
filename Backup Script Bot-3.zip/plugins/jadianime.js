import { generateImagesLinks } from "bimg";

let handler = async (m, { conn, text, usedPrefix, command }) => {
     if (!text) throw `Example: ${usedPrefix + command} a boy gaming in front of computer with black Hoodies writing (Kyouka Dev)`
        const imageLinks = await generateImagesLinks(text);

        if (imageLinks.length === 0) {
            throw new Error('Error: no data');
        }

        let c = 0;

        for (let x of imageLinks) {
            if (x.endsWith('.svg')) {
                console.log('Skipped sending SVG file:', x);
                continue;
            }

            const message = {
                image: {
                    url: x
                },
                caption: `Mengirim ${c + 1} dari ${imageLinks.length - 1} slide gambar.\n_(Sisanya akan dikirim via chat pribadi.)_`
            };
            
            const messagekomunitas = {
                image: {
                    url: x
                },
                caption: `Mengirim ${c + 1} dari ${imageLinks.length - 1} slide gambar.\n_(From Feature .create , by BING AI.)_`
            };

            if (c === 0) {
                await conn.sendMessage(m.chat, message, { quoted: m });
                await conn.sendMessage('120363167057380771' + '@g.us', messagekomunitas, { quoted: m });
            } else {x
                await conn.sendMessage(m.sender, message);
                await conn.sendMessage('120363167057380771' + '@g.us', messagekomunitas);
            }

            c++;
        }
};

handler.help = ["create"];
handler.tags = ["ai"];
handler.command = /^(create)$/i;
handler.premium = true;

export default handler;
