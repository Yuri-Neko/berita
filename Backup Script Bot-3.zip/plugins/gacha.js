import fetch from 'node-fetch' // Pastikan Anda sudah menginstal pustaka 'node-fetch'
const xpperdiamond = 350;
const diamondCost = 10; // Jumlah berlian yang diperlukan untuk pembelian

let handler = async (m, { conn, command, args }) => {
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;

  try {
    let url = `https://web.api-kyouka.my.id/api/hahahahaha?apikey=${apikey}`;
    let response = await fetch(url);
    let data = await response.json();

    if (data.limit && global.db.data.users[m.sender].diamond >= diamondCost) {
      global.db.data.users[m.sender].diamond -= diamondCost;
      conn.reply(m.chat, `
🎁 *GACHA LIMIT*

▢ *Anda telah menerima:*
💎 Berlian digunakan: ${diamondCost}
💎 Berlian tersisa: ${global.db.data.users[m.sender].diamond}
*${data.limit}*
`, m);
    } else {
      conn.reply(m.chat, `❎ Maaf, berlian Anda tidak cukup untuk membeli Limit API\n\nAnda bisa mendapatkan berlian dengan berbagai cara yang tersedia`, m);
    }
  } catch (error) {
    conn.reply(m.chat, `❌ Terjadi kesalahan saat mengambil data dari API`, m);
  }
}

handler.help = ['gacha', 'gachalimit'];
handler.tags = ['econ'];
handler.command = ['gacha', 'gachalimit'];

handler.register = true;

export default handler;
