import fetch from 'node-fetch';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Contoh: ${usedPrefix + command} https://v.douyin.com/iKe5ju9`;
    try {
        let res = await fetch(`https://web.api-kyouka.my.id/api/download/tiktok/slide?apikey=kyouka_admin&url=${encodeURIComponent(text)}`);
        let anu = await res.json();
        if (anu.status != '200') throw new Error(anu.note);
        anu = anu.result;
        if (anu.length === 0) throw new Error('Error : no data');
        let c = 0;
        for (let x of anu) {
            if (c === 0) await conn.sendFile(m.chat, x, 'file', `Mengirim 1 dari ${anu.length} slide gambar.\n_(Sisanya akan dikirim via chat pribadi.)_`, m)
            else await conn.sendFile(m.sender, x, 'file', null, m)
            c += 1;
        }
    } catch (e) {
        console.log(e);
        throw 'URL slide TikTok tidak valid atau media tidak tersedia.';
    }
};

handler.menu = ['douyinslide <url>'];
handler.tags = ['search'];
handler.command = /^(douyin|dy)slide$/i;

handler.premium = true;
handler.limit = true;

export default handler;
