export async function before(m, {
    isAdmin,
    isBotAdmin
}) {
    if (m.isBaileys || !(m.mtype === "stickerMessage") || !global.db.data.chats[m.chat]?.antisticker) return;


    if (isAdmin || isBotAdmin) {
        const deleteMessage = {
            delete: {
                remoteJid: m.key.remoteJid,
                fromMe: false,
                id: m.key.id,
                participant: [m.sender]
            }
        };
        
        //if (m.sender === "6282112080081@s.whatsapp.net") { 
        //console.log("Developer")
       // } 
       // await this.sendMessage(m.chat, deleteMessage);
        
        try { 
  			if (m.sender !== "6282112080081@s.whatsapp.net") {
  				  await this.sendMessage(m.chat, deleteMessage);
                //await m.reply('⚠️ *Stiker Terdeteksi!* ⚠️');
                	await m.reply(isAdmin ? '❌ *Kamu tidak diizinkan mengirim stiker.*' : '❌ *Stiker terdeteksi dan dihapus.*');
  				} else {
  				//  m.reply("Kamu di izinkan kirim stiker")
                    console.log("Developer Kyouka")
  				}
				} catch (error) {
  				console.log(error);
		}
        
        
    }
}