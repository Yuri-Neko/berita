import cheerio from 'cheerio';
import fetch from 'node-fetch';

let optionsData = {};

const waifu = async () => {
  let f = await fetch(`https://api.waifu.im/search?included_tags=waifu`);
  let result = await f.json();
  
  if (result) {
    return result;
  } else {
    return null; // or handle the case where no results are found
  }
};

const getCaption = (obj) => {
    const nsfwMessage = obj.images[0].is_nsfw ? "🚫 Mesum" : "✅ Aman";
    const artistName = obj.images[0].artist?.name ?? "Tidak diketahui";

    return `
    📝 *Artist:* ${artistName} 
    🔗 *Link Source:* ${obj.images[0].source}
    🏷️ *Porn?:* ${nsfwMessage}
    📢 *Upload Date:* ${obj.images[0].uploaded_at}
    👀 *Favorite:* ${obj.images[0].favorites}
    🎞️ *Type:* ${obj.images[0].extension}
    ⛔ *Alert*: Sesi berakhir setelah 60 detik
    `;
};




const handler = async (m, { conn }) => {
  const list = await waifu();
  const teks = list.images.map((obj, index) => `*${index + 1}.*`).join('\n');
  let { key } = await conn.sendFile(m.chat,list.images[0].url, 'waifu.png', getCaption(list) + `\n${teks}` + " `Lanjut`\n*2.* `Stop`" , m);
  optionsData[m.chat] = { list, key, timeout: setTimeout(() => { conn.sendMessage(m.chat, { delete: key }); delete optionsData[m.chat]; }, 60 * 1000), pesan: conn };
};

handler.before = async m => {
  if (!optionsData[m.chat]) return;
  const { list, pesan } = optionsData[m.chat];
  if (m.text.trim() === '2') {
    clearTimeout(optionsData[m.chat].timeout);
    delete optionsData[m.chat];
    conn.reply(m.chat, "Udahan yah :) yauda deh")
    return;
  }
  
  const index = parseInt(m.text.trim());

  if (m.isBaileys || isNaN(index) || index < 1 || index > list.length) return;
  
  delete optionsData[m.chat];
  console.log(list)
  const selectedObj = list.images[index - 1];
  const res = await waifu();
  const teks = res.images.map((obj, index) => `*${index + 1}.*`).join('\n');
 let { key } = await pesan.sendFile(m.chat, res.images[0].url, '', getCaption(res) + `\n${teks}` + " `Lanjut`\n *2.* `Stop`" , m);
  optionsData[m.chat] = { list: res, key, timeout: setTimeout(() => { m.reply("Sesi waipu Berakhir"); delete optionsData[m.chat]; }, 60 * 1000), pesan: conn };
  //await pesan.sendMessage(m.chat, { delete: key });
  //clearTimeout(optionsData[m.chat].timeout);
  //delete optionsData[m.chat];
};

handler.help = ["waipu", "waip"];
handler.tags = ["search"];
handler.command = ["waipu", "waip"];
handler.limit = true;

export default handler;