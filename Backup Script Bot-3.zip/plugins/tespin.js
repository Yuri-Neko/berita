let handler = async (m, { conn, text, command, usedPrefix }) => {
    if (!text) throw `✳️Contoh: ${usedPrefix + command} Kuy Join`;
    
    const pesan = await conn.sendMessage(m.chat, { text: text}, { quoted: m });
    
    await conn.relayMessage(m.chat, {
        PinInChatMessage: {
            key: pesan.key,
            type: 1,
            senderTimestampMs: 86400
        }
    }, { messageId: m.id });
}

handler.help = ['tp'];
handler.tags = ['group'];
handler.command = ['tp'];
handler.group = true;
handler.admin = false;
handler.botAdmin = true;
handler.owner = true;

export default handler;
