import util from 'util';
import path from 'path';
import fetch from 'node-fetch';

const handler = async (m, { conn, noPrefix }) => {
    let domainInfo = {};

    // Tentukan URL, teks, dan prefix berdasarkan command
    switch (m.command) {
        case 'senin':
        case 'kamis':
            domainInfo = {
                url: 'https://telegra.ph/file/ce1fdafc6e81c28c69621.jpg',
                text: 'DOMAIN SENIN & KAMIS',
            };
            break;
        case 'selasa':
        case 'jumat':
            domainInfo = {
                url: 'https://telegra.ph/file/40e26ae891e2c8247ed03.jpg',
                text: 'DOMAIN SELASA & JUM'AT',
            };
            break;
        case 'rabu':
        case 'sabtu':
            domainInfo = {
                url: 'https://telegra.ph/file/7847524c8ed9dcb63980f.jpg',
                text: 'DOMAIN RABU & SABTU',
            };
            break;
        default:
            return; // Tidak ada prefix yang cocok, tidak ada tindakan yang diambil
    }

    // Kirim file dengan URL dan teks yang sesuai
    conn.sendFile(m.chat, domainInfo.url, 'foto.jpg', domainInfo.text, m);
};

handler.command = /^(senin|kamis|selasa|jumat|rabu|sabtu)$/i;
handler.tags = ['domain'];
handler.help = ['senin', 'kamis', 'selasa', 'jumat', 'rabu', 'sabtu'];
handler.register = true;

export default handler;
