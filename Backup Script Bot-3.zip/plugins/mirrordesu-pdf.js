import fetch from 'node-fetch';
import { PDFDocument } from 'pdf-lib';
import axios from 'axios';
import sharp from 'sharp';

async function fetchImage(url) {
  const response = await axios.get(url, { responseType: 'arraybuffer' });
  const imageBuffer = Buffer.from(response.data, 'binary');
  const image = await sharp(imageBuffer).png().toBuffer();
  return image;
}

async function createPdf(images) {
  const pdfDoc = await PDFDocument.create();

  for (const imageUrl of images) {
    const imageBytes = await fetchImage(imageUrl);
    const image = await pdfDoc.embedPng(imageBytes);
    const [imageWidth, imageHeight] = [image.width, image.height];

    const pageWidth = imageWidth;
    const pageHeight = imageHeight;
    const page = pdfDoc.addPage([pageWidth, pageHeight]);

    page.drawImage(image, {
      x: 0,
      y: 0,
      width: pageWidth,
      height: pageHeight,
    });
  }

  const pdfBytes = await pdfDoc.save();
  return pdfBytes;
}

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;

  if (!text) throw '.md https://mirrordesu.pro/komik/komik-karamare-tsuma-no-kyouko/';

  await m.reply('_In progress, please wait..._');

  let { data } = await axios.get(`https://web.api-kyouka.my.id/api/nsfw/mirrordesu/chapter?apikey=${apikey}&url=${encodeURIComponent(text)}`);
  let pages = data.result.imgChapter;
  let imagepdf = await createPdf(pages);

  const pdfBuffer = Buffer.from(imagepdf);

  const messages = data.result.SeriesTerkait.map(item => {
    const title = item.title;
    const chapter = item.chapter;
    const Ratting = item.rating;
    const image = item.imageUrl;
    const link = item.url;

    const message = `
      Title: ${title}
      Chapter: ${chapter}
      Ratting: ${Ratting}
      Thumbnail: ${image}
      Link: ${link}
    `;

    return message;
  });

  const combinedMessage = messages.join('\n*----------------------------------*');

  await conn.sendFile(m.chat, pdfBuffer, data.result.judul + '.pdf', data.result.judul, m, { mimetype: 'application/pdf' });
  conn.reply(m.chat, '*SERIES TERKAIT*\n' + combinedMessage, m);
};

handler.command = /^(md|mirrordesupdf|mirpdf)$/i;
handler.tags = ['nsfw'];
handler.help = ['mirrordesupdf <link>'];
handler.register = true;

export default handler;
