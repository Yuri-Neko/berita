import axios from 'axios';

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `✳️ Masukkan link Douyin\n\n📌 Contoh: ${usedPrefix + command} https://v.douyin.com/UruNCgD/`;
  if (!args[0].match(/douyin/gi)) throw `❎ Pastikan link tersebut adalah link Douyin`;
  
  m.react(rwait);
  
  try {
    let res = (await axios.get(`https://helper.kyoukahashiba.repl.co/douyin?url=${encodeURIComponent(args[0])}`)).data;
    await m.reply('Sedang diproses...');
    await conn.sendFile(m.chat, res.mp4Url, 'douyin.mp4', 'Done', m);
    m.react(done);
  } catch (error) {
    console.error('Error:', error);
    m.reply('Maaf, terjadi kesalahan saat memproses permintaan.');
  }
};

handler.help = ['douyin'];
handler.tags = ['dl'];
handler.command = /^(douyin|dy|douyindl|dydl)$/i;
handler.diamond = true;

export default handler;
