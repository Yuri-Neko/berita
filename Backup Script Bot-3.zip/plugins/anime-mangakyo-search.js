import cheerio from 'cheerio';
import fetch from 'node-fetch';
import axios from 'axios'

let optionsData = {};

const getCaption = (obj) => `
📝 *Title:* ${obj.mangaTitle}
🔗 *Link:* ${obj.mangaUrl}
👀 *Chapter:* ${obj.chapter}
`;

const handler = async (m, { conn ,text}) => {
  if (!text) throw 'query nya apa? contoh  .mangakyosearch osananajimi'
  let res = await axios.get('https://web.api-kyouka.my.id/api/anime/mangakyo/search', {
      params: {
        query: text,
        apikey: 'kyouka_admin',
      },
    });
  const list = await res.data.result;
  const teks = list.map((obj, index) => `*${index + 1}.* ${obj.mangaTitle}`).join('\n');
  const { key } = await conn.reply(m.chat, `🔧 Daftar Manga Mangakyo:\n\n${teks}\n\nBalas pesan ini dengan nomor manga yang ingin ditampilkan.`, m);
  optionsData[m.chat] = { list, key, timeout: setTimeout(() => { conn.sendMessage(m.chat, { delete: key }); /*delete optionsData[m.chat];*/ }, 60 * 1000), pesan: conn };
};

handler.before = async m => {
  if (!optionsData[m.chat]) return;
  const { list, key, pesan } = optionsData[m.chat];
  const index = parseInt(m.text.trim());

  if (m.isBaileys || isNaN(index) || index < 1 || index > list.length) return;
  
  const selectedObj = list[index - 1];
  await pesan.sendMessage(m.chat, { image: { url: selectedObj.thumbnailUrl }, caption: getCaption(selectedObj) }, { quoted: m })
  clearTimeout(optionsData[m.chat].timeout);
  //delete optionsData[m.chat];
};

handler.help = ["mangakyosearch"];
handler.tags = ["search"];
handler.command = ["mangakyosearch","mangakyos","mks"];
handler.limit = true;

export default handler;