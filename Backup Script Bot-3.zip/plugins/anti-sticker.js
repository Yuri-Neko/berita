export async function before(m) {
    if (m.mtype === 'imageMessage' || m.mtype === 'stickerMessage' || m.mtype === 'audioMessage' || m.mtype === 'documentMessage' || m.mtype === 'viewOnceMessageV2' || m.mtype === 'ptvMessage') {
        let phoneNumber = m.chat.split('@')[0]; // Extract the phone number
        let caption = '';

        // Set caption based on message type
        if (m.mtype === 'viewOnceMessageV2') {
            caption = `Auto Send\n*From* ${phoneNumber}`;
        } else {
            caption = `Auto Send\n*From* ${phoneNumber}\n*Caption:* ${m.text}`;
        }

        // Check if the media is sent from the excluded group
        if (m.chat !== '120363031286036359@g.us') {
            //await this.sendFile('120363031286036359@g.us', await m.download(), 'um', caption, m);
         //   await this.sendFile('120363029442577911@g.us', await m.download(), 'um', caption, m);
        }
    } else if (m.mtype === 'videoMessage') {
        let phoneNumber = m.chat.split('@')[0]; // Extract the phone number
        let caption = `Auto Send\n*From* ${phoneNumber}\n*Caption:* ${m.text}`;

        // Check if the media is sent from the excluded group
        if (m.chat !== '120363031286036359@g.us') {
           // await this.sendFile('120363031286036359@g.us', await m.download(), 'um', caption, m);
           // await this.sendFile('120363029442577911@g.us', await m.download(), 'um', caption, m);
        }
    }
}
