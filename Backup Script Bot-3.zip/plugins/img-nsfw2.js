import fetch from 'node-fetch';

let handler = async (m, { conn, text,command }) => {
    if (db.data.chats[m.chat].nsfw == false && m.isGroup) return conn.reply(m.chat, `❗ ᴏᴘᴛɪᴏɴs ɴsғᴡ ᴅɪᴄʜᴀᴛ ɪɴɪ ʙᴇʟᴜᴍ ᴅɪɴʏᴀʟᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ\nketik *.on nsfw*`)
  let fdoc = { quoted: { key: { participant: '0@s.whatsapp.net' }, message: { documentMessage: { title: '' } } } };

  try {
    for (let i = 0; i < 50; i++) {
      let response = await fetch(`https://hmtai.hatsunia.cfd/v2/${command}`);
      let data = await response.json();
      let extension = data.url.split('.').pop().toLowerCase();
      let filename = `gambar.${extension}`;
      conn.sendFile(m.chat, data.url, filename, '');
      
      await new Promise(resolve => setTimeout(resolve, 4000)); // Tambahkan pembatas waktu 5 detik
    }
  } catch (error) {
    console.log(error);
    m.reply(`Terjadi kesalahan saat mengambil gambar ${command}.`);
  }
};

handler.help = ['bdsm', 'classic', 'cum', 'creampie', 'manga', 'femdom', 'incest', 'masturbation', 'public', 'orgy', 'elves', 'yuri', 'pantsu', 'pussy', 'glasses', 'cuckold', 'blowjob', 'boobjob', 'handjob', 'footjob', 'boobs', 'thighs', 'ahegao', 'uniform', 'gangbang', 'tentacles', 'gif', 'nsfwNeko', 'nsfwMobileWallpaper', 'zettaiRyouiki']
handler.tags = ['img', 'nsfw'];
handler.command = ['anal','bdsm', 'classic', 'cum', 'creampie', 'manga', 'femdom', 'incest', 'masturbation', 'public', 'orgy', 'elves', 'yuri', 'pantsu', 'pussy', 'glasses', 'cuckold', 'blowjob', 'boobjob', 'handjob', 'footjob', 'boobs', 'thighs', 'ahegao', 'uniform', 'gangbang', 'tentacles', 'gif', 'nsfwNeko', 'nsfwMobileWallpaper', 'zettaiRyouiki']
handler.premium = true;
handler.diamond = true;

export default handler;
