import axios from "axios"
let handler = async (m, { conn, isPrems }) => {
  let user = global.db.data.users[m.sender];
  let ltoken = user.ltoken;

  try {
      let hoyolabResp = await autoSignFunction(ltoken);
      await m.reply(hoyolabResp)
  } catch (error) {
    throw '⚠️ Gagal melakukan claim. Masukan ltoken dan ltuid token yang bener pada .regtoken';
  }
};

handler.help = ['hsrdaily'];
handler.tags = ['hoyolab'];
handler.command = ['hsrdaily', 'hsrd'];
handler.hoyoreg = true

export default handler;

function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = (hours < 10) ? "0" + hours : hours;
  minutes = (minutes < 10) ? "0" + minutes : minutes;
  seconds = (seconds < 10) ? "0" + seconds : seconds;

  return hours + " Jam " + minutes + " Menit";
}
const genshin = false; //does not work because of human verification
const honkai_star_rail = true;
const honkai_3 = false;
async function autoSignFunction(token) {
  const signurl_gs =
    "https://sg-hk4e-api.hoyolab.com/event/sol/sign?lang=en-us&act_id=e202102251931481";
  const signurl_hsr =
    "https://sg-public-api.hoyolab.com/event/luna/os/sign?lang=en-us&act_id=e202303301540311";
  const signurl_bh3 =
    "https://sg-public-api.hoyolab.com/event/mani/sign?lang=en-us&act_id=e202110291205111";

  const options = {
    headers: {
      Cookie: token,
    },
  };

  let response = "";

  if (genshin === true) {
    let hoyolabResponse_gs = await axios.post(signurl_gs, null, options);
    response += "\n" + hoyolabResponse_gs.data.message;
  }

  if (honkai_star_rail === true) {
    let hoyolabResponse_hsr = await axios.post(signurl_hsr, null, options);
    response += "\n" + hoyolabResponse_hsr.data.message;
  }

  if (honkai_3 === true) {
    let hoyolabResponse_bh3 = await axios.post(signurl_bh3, null, options);
    response += "\n" + hoyolabResponse_bh3.data.message;
  }

  return response;
}
