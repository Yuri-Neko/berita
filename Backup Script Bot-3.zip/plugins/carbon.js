import fetch from 'node-fetch'
let handler = async (m, {
    conn,
    args,
    usedPrefix,
    command,
    text
}) => {
//const inputText = m.quoted ? m.quoted.body : m.text || m.body
        if (text || m.quoted.text === "") {
          return m.reply(`Masukkan pesan:\n${m.prefix + m.command} print("Hello, Dek!!")`);
         }
         let warno = [
          '#ef1a11', '#89cff0', '#660000', '#87a96b', '#e9f6ff', '#ffe7f7', '#ca86b0', '#83a3ee', '#abcc88', '#80bd76',
          '#6a84bd', '#5d8d7f', '#530101', '#863434', '#013337', '#133700', '#2f3641', '#cc4291', '#7c4848', '#8a496b',
          '#722f37', '#0fc163', '#2f3641', '#e7a6cb', '#64c987', '#e6e6fa', '#ffffff', '#00000000'
        ]
        let randomIndex = Math.floor(Math.random() * warno.length);
		let rancolor = warno[randomIndex];
         m.react(`⏳`)
         let Blobs = await fetch("https://carbonara.solopov.dev/api/cook", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
   				code: text || m.quoted.text,
   				backgroundColor: rancolor,
   				dropShadow: true,
   				lineNumbers: true,
   				language: "auto",
                prettify: true,
                windowControls: true,
                windowTheme: "sharp",
            }),

        })
        .then(response => response.blob())
    		let arrayBuffer = await Blobs.arrayBuffer();
    		let buffer = Buffer.from(arrayBuffer);
       	    let a = await m.reply(buffer)
         if (a) {
           m.react(``)
         }
       
}

handler.help = ['cb','carbon']
handler.tags = ['main']
handler.command = /^(cb|carbon)$/i

export default handler