import axios from 'axios';

export async function before(m) {
    let chat = global.db.data.chats[m.chat] || {};
    if (!chat.latestManga) chat.latestManga = [];
    if (chat && chat.updateMangaNews) {
        let latest = chat.latestManga;
        setInterval(async () => {
            this.logger.info(`Checking manga news for "${m.chat}"`);
            let res = await getLatestManga().catch(console.error);

            if (res && res.result && res.result.terbaruPosts) {
                let { terbaruPosts } = res.result;

                let message = "Pembaruan Manga Terbaru:\n";

                for (let manga of terbaruPosts) {
                    if (!manga.thumbnail || manga.thumbnail.trim() === "") {
                        continue;
                    }

                    if (latest.includes(manga.url)) {
                        continue;
                    }

                    latest.push(manga.url);

                    message += `\nTitle: ${manga.title}\nURL: ${manga.url}\nThumbnail: ${manga.thumbnail}\n\n`;
                }

                if (message !== "Pembaruan Manga Terbaru:\n") {
                    this.logger.info(`Sending manga news to "${m.chat}"`);
                    await this.sendMessage(m.chat, message);
                }

                if (latest.length > 10) {
                    latest.shift();
                }
            }
        }, 60 * 1000); // 1 minute
    }
}

export const disabled = false;

function getLatestManga() {
    return new Promise((resolve, reject) => {
        axios.get('https://web.api-kyouka.my.id/api/nsfw/pinattsuki/latest?apikey=kyouka_admin')
            .then((res) => {
                resolve(res.data);
            })
            .catch(reject);
    });
}
