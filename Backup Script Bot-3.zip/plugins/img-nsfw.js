import fetch from 'node-fetch';

let handler = async (m, { conn, text, command }) => {
  if (db.data.chats[m.chat].nsfw == false && m.isGroup) return conn.reply(m.chat, `❗ ᴏᴘᴛɪᴏɴs ɴsғᴡ ᴅɪᴄʜᴀᴛ ɪɴɪ ʙᴇʟᴜᴍ ᴅɪɴʏᴀʟᴀᴋᴀɴ ᴏʟᴇʜ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ\nketik *.on nsfw*`)
  let wm = "KyoukaHashiba";
  let fdoc = { quoted: { key: { participant: '0@s.whatsapp.net' }, message: { documentMessage: { title: wm } } } };

  try {
    for (let i = 0; i < 50; i++) {
      let response = await fetch(`https://api.waifu.im/search/?included_tags=${command}`);
      let data = await response.json();

      let image = data.images[0]; // Ambil elemen pertama dari array images

      let tags = image.tags.map(tag => `*${tag.name}*: ${tag.description}`).join('\n'); // Mendapatkan semua deskripsi tags

      let description = image.tags[1].description; // Mendapatkan deskripsi dari tag kedua
      let isNsfw = image.tags[1].is_nsfw ? "NSFW" : "SFW"; // Menentukan status NSFW atau SFW

      let caption = `Source: ${image.source}\nFavorite: ${image.favorites}\n\nTags:\n${tags}\n\nType: ${isNsfw}`;

      conn.sendFile(m.chat, image.url, 'gambar.jpg', caption);
      
      await new Promise(resolve => setTimeout(resolve, 10000)); // Tambahkan pembatas waktu 5 detik
    }
  } catch (error) {
    console.log(error);
    m.reply(`Terjadi kesalahan saat mengambil gambar ${command}.`);
  }
};

handler.help = ['paizuri', 'ass', 'milf', 'oral', 'ero', 'ecchi', 'maid', 'marin-kitagawa', 'mori-calliope', 'raiden-shogun', 'oppai', 'selfies', 'uniform'];
handler.tags = ['img', 'nsfw'];
handler.command = ['paizuri', 'ass', 'milf', 'oral', 'ero', 'ecchi', 'maid', 'marin-kitagawa', 'mori-calliope', 'raiden-shogun', 'oppai', 'selfies', 'uniform'];
handler.premium = true;
handler.diamond = true;
handler.nsfw = true

export default handler;
