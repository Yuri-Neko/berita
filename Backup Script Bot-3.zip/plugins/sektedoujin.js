import fetch from 'node-fetch';
import axios from 'axios';
import sharp from 'sharp';

async function fetchImage(url) {
  const response = await axios.get(url, { responseType: 'arraybuffer' });
  const imageBuffer = Buffer.from(response.data, 'binary');
  const image = await sharp(imageBuffer).png().toBuffer();
  return image;
}

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender];
  let apikey = user.apis;
  let ftroli = {
    key: {
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      orderMessage: {
        itemCount: 2023,
        status: 404,
        surface: 404,
        message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`,
        orderTitle: '',
        thumbnail: await (await fetch('https://demo.kyoukastore.my.id/buffer?url=https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(),
        sellerJid: '0@s.whatsapp.net'
      }
    }
  };

  if (!text) {
    m.reply("Tunggu sebentar, sedang memuat...");

    try {
  let f = await fetch(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/latest?apikey=${apikey}`);
  let result = await f.json();

  const messages = result.map(item => {
    const title = item.title;
    const chapter = item.chapter;
    const date = item.date;
    const image = item.thumbnail;
    const link = item.url;

    const message = `
      Title: ${title || "data kosong"}
      Chapter: ${chapter || "data kosong"}
      Date: ${date || "data kosong"}
      Thumbnail: ${image || "data kosong"}
      Link: ${link || "data kosong"}
    `;

    return message;
  });

  const combinedMessage = messages.join('\n*----------------------------------*');

  conn.reply(m.chat, '*LATEST DOUJIN*\n' + combinedMessage, ftroli);
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat memuat doujin terbaru', m);
    }
  } else if (text.startsWith("https://sektedoujin.cc/manga/")) {
    const url = text.trim();

    m.reply("Tunggu sebentar, sedang mengambil detail...");

    try {
      let f = await fetch(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/detail?apikey=${apikey}&url=${encodeURIComponent(url)}`);
      let result = await f.json();

      const thumb = result.thumb;
      const title = result.title;
      const genres = result.genres.join(', ');
      const rating = result.ratingValue;
      const status = result.status;
      const type = result.type;
      const released = result.released;
      const author = result.author;
      const artist = result.artist;
      const serialization = result.serialization;
      const synopsis = result.synopsis;
      const chapterList = result.chapterList.map(chapter => `Chapter ${chapter.chapterNum}: [Link](${chapter.chapterUrl})\n- ${chapter.chapterDate}`).join('\n\n');

      const message = `
            *DETAIL DOUJIN*\n\n
        Title: ${title}
        Genres: ${genres}
        Rating: ${rating}
        Status: ${status}
        Type: ${type}
        Released: ${released}
        Author: ${author}
        Artist: ${artist}
        Serialization: ${serialization}
        Synopsis: ${synopsis}
        
        *CHAPTER LIST*
        ${chapterList}
      `;
       
      conn.sendFile(m.chat, await fetchImage(thumb), 'img.jpg', message, ftroli);

      //conn.reply(m.chat, message, ftroli);
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat mengambil detail doujin', m);
    }
  } else {
    const query = text.trim();

    m.reply("Tunggu sebentar, sedang melakukan pencarian...");

    try {
      let f = await fetch(`https://api.kyoukastore.my.id/api/nsfw/sektedoujin/search?apikey=${apikey}&query=${encodeURIComponent(query)}`);
      let result = await f.json();

      const messages = result.map(item => {
        const title = item.title;
        const chapter = item.chapter;
        const rating = item.rating;
        const image = item.thumbnail;
        const link = item.url;

        const message = `
          Title: ${title}
          Chapter: ${chapter}
          Rating: ${rating}
          Thumbnail: ${image}
          Link: ${link}
        `;

        return message;
      });

      const combinedMessage = messages.join('\n*----------------------------------*');

      conn.reply(m.chat, '*HASIL PENCARIAN DOUJIN*\n' + combinedMessage, ftroli);
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat melakukan pencarian doujin', m);
    }
  }
};

handler.command = ['sektedoujin'];
handler.help = ['sektedoujin'];
handler.tags = ['main'];
handler.register = true;

export default handler;