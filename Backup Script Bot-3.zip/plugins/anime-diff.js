import axios from "axios";
import uploadImage from "../lib/uploadImage.js";

let handler = async (m, { conn, usedPrefix, text: prompt, command }) => {
  if (!prompt) {
    return m.reply(`Example: ${usedPrefix + command} 1girl, solo, ponytail, blush.`);
  }

  const negativePrompt = ["furry"];
  if (negativePrompt.some(word => prompt.toLowerCase().includes(word.toLowerCase()))) {
    return m.reply("Sorry, NSFW prompts are not allowed.");
  }

  conn.animedif = conn.animedif ? conn.animedif : {};
  if (m.sender in conn.animedif) {
    return m.reply("You have undone job, please wait...");
  }

  conn.animedif[m.sender] = true;
  m.reply("_Progress..._");

  let url;
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || q.mediaType || "";
  if (/image\/(jpe?g|png)/.test(mime)) {
    url = await uploadImage(await q.download?.());
  }

  try {
    const sampler = "Euler a";
    const steps = 40;
    const style = "ACG";
    const ratio = "9:16";
    const controlNet = url ? "scribble" : "none";
    const cfg = 7;
    const image_num = 1;
    const init_image = url ? "True" : "None";

    const { data } = await axios.request({
      baseURL: "https://api.itsrose.site",
      url: "/image/anime/diffusion",
      method: "GET",
      params: {
        prompt,
        style,
        ratio,
        sampler,
        ...(url ? { init_image: url } : {}),
        cfg,
        controlNet,
        image_num,
        apikey: "Rs-KuroYami"
      },
    }).catch((e) => e?.response);

    const { status, message, result } = data;

    if (!status) {
      delete conn.animedif[m.sender];
      return m.reply(message);
    }

    if (!result || !result.images) {
      delete conn.animedif[m.sender];
      return m.reply("Failed to get images from the API response.");
    }

    const { images } = result;

    const caption =
      `Style: ${style}
Ratio: ${ratio}
ControlNet: ${controlNet}
Steps: ${steps}
CFG: ${cfg}
Sampler: ${sampler}
Init Image: ${init_image}
\n` +
      "Prompt: ```" +
      prompt +
      "```";

    for (const [index, url] of images.entries()) {
  await conn.sendMessage(
    m.chat,
    {
      image: Buffer.from(url, "base64"),
      caption,
    },
    { quoted: m }
  );
}
  } catch (e) {
    console.log(e);
    m.reply("Failed :(");
  } finally {
    delete conn.animedif[m.sender];
  }
};

handler.help = ["animedif"];
handler.tags = ["ai"];
handler.command = ["animedif", "diffusion"];
handler.group = true;
handler.diamond = 15;
handler.register = true;

export default handler;