import fetch from "node-fetch"
let handler = async (m, { conn, isPrems,text }) => {

  try {
    // Fetch API
    let url = `https://web.api-kyouka.my.id/api/broadcast?subject=Admin&message=${text}`;
    let response = await fetch(url);
    let data = await response.json();

    if (data.message) {
     m.reply("Berhasil Broatcast Pada user rest api")
    } else {
      throw '⚠️ Broatcast Pada user rest api';
    }
  } catch (error) {
    throw '⚠️ Gagal melakukan Broatcast Pada user rest api.';
  }
};

handler.help = ['bca','broatcastapi','bcapi'];
handler.tags = ['owner'];
handler.command = ['bca','broatcastapi','bcapi'];
handler.owner = true

export default handler;
