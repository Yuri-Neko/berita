/*import {
	generateWAMessageFromContent
} from "@adiwajshing/baileys"
import moment from "moment-timezone"

let handler = async (m, {
	conn,
	groupMetadata,
	usedPrefix,
	command
}) => {
	//await conn.sendReact(m.chat, "⏳", m.key)
    await m.react('⏳');
	var soun = ["aku-ngakak",
		"anjay",
		"ara-ara2",
		"ara-ara-cowok",
		"ara-ara",
		"arigatou",
		"assalamualaikum",
		"asu",
		"ayank",
		"bacot",
		"bahagia-aku",
		"baka",
		"bansos",
		"beat-box2",
		"beat-box",
		"biasalah",
		"bidadari",
		"bot",
		"buka-pintu",
		"canda-anjing",
		"cepetan",
		"china",
		"cuekin-terus",
		"daisuki-dayo",
		"daisuki",
		"dengan-mu",
		"Donasiku",
		"gaboleh-gitu",
		"gak-lucu",
		"gamau",
		"gay",
		"gelay",
		"gitar",
		"gomenasai",
		"hai-bot",
		"hampa",
		"hayo",
		"hp-iphone",
		"ih-wibu",
		"i-like-you",
		"india",
		"karna-lo-wibu",
		"kiss",
		"kontol",
		"ku-coba",
		"maju-wibu",
		"makasih",
		"mastah",
		"menuasli",
		"menuku",
		"menu",
		"MenuYuki",
		"nande-nande",
		"nani",
		"ngadi-ngadi",
		"nikah",
		"nuina",
		"onichan",
		"ownerku",
		"owner-sange",
		"pak-sapardi",
		"pale",
		"pantek",
		"pasi-pasi",
		"punten",
		"sayang",
		"siapa-sih",
		"sudah-biasa",
		"summertime",
		"tanya-bapak-lu",
		"to-the-bone",
		"wajib",
		"waku",
		"woi",
		"yamete",
		"yowaimo",
		"yoyowaimo"
	].getRandom()
	var vn = "https://raw.githubusercontent.com/AyGemuy/HAORI-API/main/audio/" + soun + ".mp3"

	const caption = `*👋 Selamat datang di dashboard bot kami*!\n\n - Kami berharap Anda akan menikmati pengalaman berinteraksi dengan bot kami yang ramah dan intuitif.${readMore}\n\n - Kami telah menyertakan berbagai fitur yang dapat membantu Anda mengelola dan meningkatkan kinerja bot Anda.\n\n - Kami berharap Anda akan menikmati menggunakan dashboard bot kami dan semoga Anda mendapatkan manfaat dari fitur-fitur yang kami tawarkan.\n\n\n*[ LIST MENU ]*\n  - ${usedPrefix}menulist\n  - ${usedPrefix}allmenu\n\n`;

	await conn.sendFile(m.chat, Buffer.alloc(0), "D A S H B O A R D", caption, fakes, null, {
	mimetype: [dpptx, ddocx, dxlsx, dpdf, drtf].getRandom(),
	fileLength: fsizedoc,
	pageCount: fpagedoc,
	jpegThumbnail: await conn.resize([thumbdoc, thumb].getRandom(), 300, 150),
	contextInfo: {
		mentionedJid: [m.sender],
		externalAdReply: {
			body: bottime,
			containsAutoReply: true,
			mediaType: 1,
			mediaUrl: null,
			renderLargerThumbnail: true,
			thumbnail: await conn.resize([thumbdoc, thumb].getRandom(), 350, 200),
			thumbnailUrl: [thumbdoc, thumb].getRandom(),
			title: `${ucapan()} ${m.name}`
		},
        ForwardedNewsletterMessageInfo: {
            newsletterJid: '120363144038483540' + '@newsletter',
            serverMessageId: '120363144038483540' + '@newsletter',
            newsletterName:null,
            contentType:null,
            accessibilityText:null
        }
	}
})
	await conn.sendPresenceUpdate('recording', m.chat);
	await conn.sendFile(m.chat, vn, '', null, m, true, {
		ptt: true
	});
	m.react('✅');

}
handler.help = ["help2"]
handler.tags = ["main"]
handler.command = /^(\??)$/i

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function getRandom(array) {
  const randomIndex = Math.floor(Math.random() * array.length);
  return array[randomIndex];
}

function ucapan() {
    let waktunya = moment.tz("Asia/Makassar").format("HH");
    return waktunya >= 24 ? "Selamat Begadang 🗿" :
           waktunya >= 18 ? "Selamat malam 🌙" :
           waktunya >= 15 ? "Selamat sore 🌅" :
           waktunya > 10 ? "Selamat siang ☀️" :
           waktunya >= 4 ? "Selamat pagi 🌄" :
           "Selamat Pagi 🗿";
}*/

import fetch from "node-fetch";
import uploadFile from '../lib/uploadFile.js'
import uploadImage from '../lib/uploadImage.js'

const commandList = ["upsw"];

const mimeAudio = 'audio/mpeg';
const mimeVideo = 'video/mp4';
const mimeImage = 'image/jpeg';

let handler = async (m, {
    conn,
    command,
    args
}) => {
    let teks
    if (args.length >= 1) {
        teks = args.slice(0).join(" ")
    } else if (m.quoted && m.quoted.text) {
        teks = m.quoted.text
    }

    if (m.quoted && m.quoted.mtype) {
        const mtype = m.quoted.mtype;
        let type;

        if (mtype === 'audioMessage') {
            type = 'vn';
        } else if (mtype === 'videoMessage') {
            type = 'vid';
        } else if (mtype === 'imageMessage') {
            type = 'img';
        } else if (mtype === 'extendedTextMessage') {
            type = 'txt';
        } else {
            throw "❌ Media type tidak valid!";
        }

        const doc = {};

        if (type === 'vn') {
            const link = await (type === 'img' ? uploadImage : uploadFile)(await m.quoted.download());
            doc.mimetype = mimeAudio;
            doc.audio = {
                url: link
            } ? {
                url: link
            } : generateVoice("id-ID", "id-ID-ArdiNeural", teks);
        } else if (type === 'vid') {
            const link = await (type === 'img' ? uploadImage : uploadFile)(await m.quoted.download());
            doc.mimetype = mimeVideo;
            doc.caption = teks;
            doc.video = {
                url: link
            } ? {
                url: link
            } : {
                url: giflogo
            };
        } else if (type === 'img') {
            const link = await (type === 'img' ? uploadImage : uploadFile)(await m.quoted.download());
            doc.mimetype = mimeImage;
            doc.caption = teks;
            doc.image = {
                url: link
            } ? {
                url: link
            } : {
                url: logo
            };
        } else if (type === 'txt') {
            doc.text = teks;
        }

        await conn.sendMessage('status@broadcast', doc, {
            backgroundColor: getRandomHexColor(),
            font: Math.floor(Math.random() * 9),
            statusJidList: global.db.data.newsw
        }).then((res) => {
            conn.reply(m.chat, `Sukses upload ${type}`, res);
        }).catch(() => {
            conn.reply(m.chat, `Gagal upload ${type}`, m);
        });
    } else {
        throw "❌ Tidak ada media yang diberikan!";
    }
};

handler.help = commandList;
handler.tags = ["main"];
handler.owner = true;
handler.rowner = true
handler.command = new RegExp(`^(${commandList.join('|')})$`, 'i');

export default handler;

async function generateVoice(Locale = "id-ID", Voice = "id-ID-ArdiNeural", Query) {
    const formData = new FormData();
    formData.append("locale", Locale);
    formData.append("content", `<voice name="${Voice}">${Query}</voice>`);
    formData.append("ip", '46.161.194.33');
    const response = await fetch('https://app.micmonster.com/restapi/create', {
        method: 'POST',
        body: formData
    });
    return Buffer.from(('data:audio/mpeg;base64,' + await response.text()).split(',')[1], 'base64');
}

function getRandomHexColor() {
    return "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0");
}