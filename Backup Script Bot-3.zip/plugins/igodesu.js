import fetch from 'node-fetch'
let handler = async (m, {conn, text}) => { 
let user = global.db.data.users[m.sender];
  let apikey = user.apis;
let ftroli = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'
    },
    message: {
    orderMessage: {
    itemCount : 2023,
    status: 404,
    surface : 404,
    message: `𝙹𝙰𝙽𝙶𝙰𝙽 𝚂𝙿𝙰𝙼(•ˋ _ ˊ•)`, 
    orderTitle: ``,
    thumbnail: await (await fetch('https://helper--startgrow.repl.co/buffer?url=https://telegra.ph/file/5f028205d010a090a21fb.jpg')).buffer(), //Gambarnye
    sellerJid: '0@s.whatsapp.net' 
    }
    }
    }
m.reply("tunggu yah agak lama loading nya...ada cloudplare")
    let f = await fetch(`https://web.api-kyouka.my.id/api/nsfw/igodesu/latest?apikey=${apikey}`)
    let x = await f.json()
    const result = x.result;

const messages = result.map(item => {
  const title = item.title;
  const image = item.image;
  const duration = item.duration;
  const views = item.views;
  const link = item.link;

  const message = `
    Title: ${title}
    Image: ${image}
    Duration: ${duration}
    Views: ${views}
    Link: ${link}
  `;

  return message;
});

// Menggabungkan semua pesan menjadi satu string
const tet = messages.join('\n');

conn.reply(m.chat, tet, ftroli);

//conn.sendButton(m.chat, tet, wm, hasil.video.url , [['Next', '.ttfyp'],['NO WM', `.tiktok ${hasil.video.url2}`]],m,{quoted: ftroli})
}
handler.command = ['igodesu']
handler.help = ['igodesu']
handler.tags = ['main']
handler.register = true
export default handler