/* Fake adReplyS*/
global.adReplyS = {
    fileLength: SizeDoc(),
    seconds: SizeDoc(),
    contextInfo: {
        mentionedJid: ["0@s.whatsapp.net"],
        groupMentions: [],
        isForwarded: true,
        expiration: global.ephemeral,
        ephemeralSettingTimestamp: {
            low: Date.now(),
            high: 0,
            unsigned: false
        },
        disappearingMode: {
            initiator: 0,
            trigger: 0
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363144038483540@newsletter',
            newsletterName: global.author,
            serverMessageId: -1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: global.nomorown + '@s.whatsapp.net'
        },
        forwardingScore: 127,
        externalAdReply: {
            title: "📍 " + Sapa() + Pagi(),
            body: author,
            mediaUrl: sgc,
            description: "𝑾𝒖𝒅𝒚𝒔𝒐𝒇𝒕",
            previewType: "PHOTO",
            thumbnail: await fs.readFileSync("./thumbnail.jpg"),
            sourceUrl: "https://github.com/AyGemuy",
        }
    }
}
/* Fake adReply */
global.adReply = {
    fileLength: SizeDoc(),
    seconds: SizeDoc(),
    contextInfo: {
        mentionedJid: ["0@s.whatsapp.net"],
        groupMentions: [],
        isForwarded: true,
        expiration: global.ephemeral,
        ephemeralSettingTimestamp: {
            low: Date.now(),
            high: 0,
            unsigned: false
        },
        disappearingMode: {
            initiator: 0,
            trigger: 0
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363144038483540@newsletter',
            newsletterName: global.author,
            serverMessageId: -1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: global.nomorown + '@s.whatsapp.net'
        },
        forwardingScore: 127,
        externalAdReply: {
            body: author,
            containsAutoReply: true,
            mediaType: 1,
            mediaUrl: sgc,
            renderLargerThumbnail: true,
            sourceId: "𝑾𝒖𝒅𝒚𝒔𝒐𝒇𝒕",
            sourceType: "PDF",
            previewType: "PDF",
            sourceUrl: null,
            thumbnail: await fs.readFileSync("./thumbnail.jpg"),
            thumbnailUrl: logo,
            title: "📍 " + Sapa() + Pagi()
        }
    }
}
/* Fake IG */
global.fakeig = {
    contextInfo: {
        mentionedJid: ["0@s.whatsapp.net"],
        groupMentions: [],
        isForwarded: true,
        expiration: global.ephemeral,
        ephemeralSettingTimestamp: {
            low: Date.now(),
            high: 0,
            unsigned: false
        },
        disappearingMode: {
            initiator: 0,
            trigger: 0
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363144038483540@newsletter',
            newsletterName: global.author,
            serverMessageId: -1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: global.nomorown + '@s.whatsapp.net'
        },
        forwardingScore: 127,
        externalAdReply: {
            mediaUrl: sig,
            mediaType: "VIDEO",
            description: "Follow: " + sig,
            title: "📍 " + Sapa() + Pagi(),
            body: author,
            thumbnailUrl: logo,
            sourceUrl: null
        }
    }
}
/* Fake FB */
global.fakefb = {
    contextInfo: {
        mentionedJid: ["0@s.whatsapp.net"],
        groupMentions: [],
        isForwarded: true,
        expiration: global.ephemeral,
        ephemeralSettingTimestamp: {
            low: Date.now(),
            high: 0,
            unsigned: false
        },
        disappearingMode: {
            initiator: 0,
            trigger: 0
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363144038483540@newsletter',
            newsletterName: global.author,
            serverMessageId: -1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: global.nomorown + '@s.whatsapp.net'
        },
        forwardingScore: 127,
        externalAdReply: {
            mediaUrl: sfb,
            mediaType: "VIDEO",
            description: "Follow: " + sig,
            title: "📍 " + Sapa() + Pagi(),
            body: author,
            thumbnailUrl: logo,
            sourceUrl: null
        }
    }
}
/* Fake TT */
global.faketik = {
    contextInfo: {
        mentionedJid: ["0@s.whatsapp.net"],
        groupMentions: [],
        isForwarded: true,
        expiration: global.ephemeral,
        ephemeralSettingTimestamp: {
            low: Date.now(),
            high: 0,
            unsigned: false
        },
        disappearingMode: {
            initiator: 0,
            trigger: 0
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363144038483540@newsletter',
            newsletterName: global.author,
            serverMessageId: -1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: global.nomorown + '@s.whatsapp.net'
        },
        forwardingScore: 127,
        externalAdReply: {
            mediaUrl: snh,
            mediaType: "VIDEO",
            description: "Follow: " + sig,
            title: "📍 " + Sapa() + Pagi(),
            body: author,
            thumbnailUrl: logo,
            sourceUrl: snh
        }
    }
}
/* Fake YT */
global.fakeyt = {
    contextInfo: {
        mentionedJid: ["0@s.whatsapp.net"],
        groupMentions: [],
        isForwarded: true,
        expiration: global.ephemeral,
        ephemeralSettingTimestamp: {
            low: Date.now(),
            high: 0,
            unsigned: false
        },
        disappearingMode: {
            initiator: 0,
            trigger: 0
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363144038483540@newsletter',
            newsletterName: global.author,
            serverMessageId: -1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: global.nomorown + '@s.whatsapp.net'
        },
        forwardingScore: 127,
        externalAdReply: {
            mediaUrl: syt,
            mediaType: "VIDEO",
            description: "Follow: " + sig,
            title: "📍 " + Sapa() + Pagi(),
            body: author,
            thumbnailUrl: logo,
            sourceUrl: syt
        }
    }
}








async function uploadToDiscdn(fileNames, content) {
	try {

		const {
			ext,
			mime
		} = await fileTypeFromBuffer(content) || {};
		const blob = new Blob([content.toArrayBuffer()], {
			type: mime
		});
		const formData = new FormData();
		formData.append('files[0]', blob, fileNames + '.' + ext);

		const res = await (
			await fetch("https://discord.com/api/v9/channels/1180731738176094228/messages", {
				method: "POST",
				headers: {
					Authorization: "Bot MTE4MDcyODk4MjAzNjA0MTczOA.GtqzcS.grSeXjgylvsY_e7YxYi4acHKIrYTabaOnubOx8"
				},
				body: formData,
			})
		).json()
		return res;
	} catch (error) {
		console.error('Error:', error.message);
		throw error;
	}
};



case "cb":
       case "carbon": {
         const inputText = m.quoted ? m.quoted.body : m.text || m.body
        if (inputText === "") {
          return m.reply(`Masukkan pesan:\n${m.prefix + m.command} print("Hello, Dek!!")`);
         }
         let warno = [
          '#ef1a11', '#89cff0', '#660000', '#87a96b', '#e9f6ff', '#ffe7f7', '#ca86b0', '#83a3ee', '#abcc88', '#80bd76',
          '#6a84bd', '#5d8d7f', '#530101', '#863434', '#013337', '#133700', '#2f3641', '#cc4291', '#7c4848', '#8a496b',
          '#722f37', '#0fc163', '#2f3641', '#e7a6cb', '#64c987', '#e6e6fa', '#ffffff', '#00000000'
        ]
         m.react(`⏳`)
         let Blobs = await fetch("https://carbonara.solopov.dev/api/cook", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
   code: inputText,
            }),

        })
        .then(response => response.blob())
    let arrayBuffer = await Blobs.arrayBuffer();
    let buffer = Buffer.from(arrayBuffer);
         let a = await m.reply(buffer)
         if (a) {
           m.react(``)
         }
       }
         break
